import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';
import {
  EON_CITY_W752_MISSION_DEFINITIONS,
  EON_CITY_W752_SCHEMA,
  EON_CITY_W752_VIEW_EVENT,
  createEonCityW752MissionsProgression,
  getEonCityW752Mission,
  projectEonCityW752MissionsProgression,
  validateEonCityW752MissionsProgression
} from '../../assets/js/city/w752/eon-city-w752-missions-progression.js';
import { projectEonCityW751ProductiveStations } from '../../assets/js/city/w751/eon-city-w751-productive-stations.js';
import { readEonCityW659gProgression, recordEonCityW659gVerifiedAction } from '../../assets/js/city/w659g/eon-city-w659g-progression-ledger.js';
import { renderEonCityW752ProgressionPanel } from '../../assets/js/work-surface/eon-city-progression-panel.js';

const read = (relative) => fs.readFileSync(new URL(`../../${relative}`, import.meta.url), 'utf8');
const memoryStorage = () => { const data = new Map(); return { getItem: (key) => data.has(key) ? data.get(key) : null, setItem: (key, value) => data.set(key, String(value)), removeItem: (key) => data.delete(key), dump: () => data }; };
class FakeCustomEvent extends Event { constructor(type, options = {}) { super(type); this.detail = options.detail; } }
const environment = () => { const target = new EventTarget(); target.CustomEvent = FakeCustomEvent; return target; };

function baseStationView() {
  return projectEonCityW751ProductiveStations({ productivePlan: { missions: [] }, missionView: [], activity: { stations: {} } });
}

function withVerifiedStation(stationId, receiptId, kind = 'verified-work') {
  const base = baseStationView();
  return Object.freeze({
    ...base,
    verifiedCount: 1,
    stations: Object.freeze(base.stations.map((station) => station.stationId === stationId ? Object.freeze({
      ...station,
      state: 'verified',
      completionClaimed: true,
      verifiedOutcome: Object.freeze({ kind, receiptId, verifiedAt: 752000, privateContentStored: false })
    }) : station))
  });
}

test('W752 defines ten receipt-backed missions with fixed fair boundaries', () => {
  const view = projectEonCityW752MissionsProgression({ stationView: baseStationView(), progression: readEonCityW659gProgression({ storage: null }) });
  const validation = validateEonCityW752MissionsProgression(view);
  assert.equal(validation.ok, true, validation.errors.join('\n'));
  assert.equal(view.schema, EON_CITY_W752_SCHEMA);
  assert.equal(view.missionCount, 10);
  assert.equal(EON_CITY_W752_MISSION_DEFINITIONS.length, 10);
  assert.equal(new Set(view.missions.map((mission) => mission.stationId)).size, 10);
  assert.equal(new Set(view.missions.map((mission) => mission.title)).size, 10);
  for (const mission of view.missions) {
    assert.equal(mission.xpReward, 120);
    assert.equal(mission.revealProgressReward, 35);
    assert.equal(mission.explicitClaimRequired, true);
    assert.equal(mission.verifiedNativeReceiptRequired, true);
    assert.equal(mission.paidReward, false);
    assert.equal(mission.randomizedReward, false);
    assert.equal(mission.transferableReward, false);
    assert.equal(mission.streakRequired, false);
    assert.equal(mission.publicPostingRequired, false);
  }
  assert.equal(view.lootBox, false);
  assert.equal(view.chanceBased, false);
  assert.equal(view.fakeUrgency, false);
  assert.equal(view.clickFarming, false);
});

test('W752 claims XP only from an explicit genuine native receipt and remains idempotent', () => {
  const storage = memoryStorage();
  const env = environment();
  const stationController = { getView: () => withVerifiedStation('project-atlas', 'project-shell:w752') };
  const controller = createEonCityW752MissionsProgression({ stationController, storage, environment: env, now: () => 752000 });
  assert.equal(controller.claimMission('project-atlas').reason, 'explicit-user-action-required');
  const claimed = controller.claimMission('project-atlas', { explicitUserAction: true });
  assert.equal(claimed.ok, true);
  assert.deepEqual(claimed.awarded, { xp: 120, reveal: 35 });
  assert.equal(controller.getMission('project-atlas').state, 'claimed');
  const duplicate = controller.claimMission('project-atlas', { explicitUserAction: true });
  assert.equal(duplicate.reason, 'already-claimed');
  assert.deepEqual(duplicate.awarded, { xp: 0, reveal: 0 });
  assert.equal(controller.getView().xp, 120);
  assert.equal(controller.getView().revealProgress, 35);
  controller.dispose();
});

test('W752 never treats review, open or return activity as mission completion', () => {
  const storage = memoryStorage();
  const base = baseStationView();
  const returned = Object.freeze({ ...base, stations: Object.freeze(base.stations.map((station) => station.stationId === 'create-forge' ? Object.freeze({ ...station, state: 'returned', completionClaimed: false, verifiedOutcome: null }) : station)) });
  const controller = createEonCityW752MissionsProgression({ stationController: { getView: () => returned }, storage, environment: environment() });
  const mission = controller.getMission('create-forge');
  assert.equal(mission.state, 'in-progress');
  assert.equal(mission.claimable, false);
  assert.equal(controller.claimMission('create-forge', { explicitUserAction: true }).reason, 'verified-native-receipt-required');
  assert.equal(controller.getView().xp, 0);
  controller.dispose();
});

test('W752 Vault Reveals are explicit, deterministic, cosmetic and duplicate-protected', () => {
  const storage = memoryStorage();
  for (const receiptId of ['r1', 'r2', 'r3']) {
    assert.equal(recordEonCityW659gVerifiedAction({ type: 'city.real-work-receipt', receiptId, verified: true }, { storage, now: 752000 }).ok, true);
  }
  const controller = createEonCityW752MissionsProgression({ stationController: { getView: baseStationView }, storage, environment: environment(), now: () => 752100 });
  assert.equal(controller.getView().pendingReveals, 1);
  assert.equal(controller.getView().nextReveal.id, 'signal-mist');
  assert.equal(controller.openVaultReveal().reason, 'explicit-user-action-required');
  const reveal = controller.openVaultReveal({ explicitUserAction: true });
  assert.equal(reveal.ok, true);
  assert.equal(reveal.outcome.kind, 'cosmetic');
  assert.equal(reveal.outcome.rewardId, 'signal-mist');
  assert.equal(reveal.outcome.duplicateProtected, true);
  assert.equal(reveal.deterministic, true);
  assert.equal(reveal.paid, false);
  assert.equal(reveal.chanceBased, false);
  assert.equal(controller.getView().nextReveal.id, 'forge-prism');
  controller.dispose();
  assert.equal(controller.openVaultReveal({ explicitUserAction: true }).reason, 'w752-disposed');
  assert.equal(controller.selectCosmetic('signal-mist', { explicitUserAction: true }).reason, 'w752-disposed');
});


test('W752 defers surplus reveal credits after the finite cosmetic catalog is complete', () => {
  const progression = {
    schema: 'eon.city.w659g.progression.v1', xp: 1000, revealProgress: 20, pendingReveals: 3, openedReveals: 6,
    receipts: {}, dailyCounts: {}, ownedCosmetics: ['signal-mist', 'forge-prism', 'creator-frame', 'transit-pulse', 'portal-echo', 'command-orbit-master'],
    selectedCosmetics: {}, revealHistory: []
  };
  const view = projectEonCityW752MissionsProgression({ stationView: baseStationView(), progression });
  assert.equal(view.revealCatalogComplete, true);
  assert.equal(view.pendingReveals, 0);
  assert.equal(view.deferredRevealCredits, 3);
  assert.equal(view.nextReveal, null);
});

test('W752 builds one bounded private My Realm reflection from claimed missions', () => {
  const storage = memoryStorage();
  recordEonCityW659gVerifiedAction({ type: 'city.real-work-receipt', receiptId: 'project-shell:w752', verified: true }, { storage, now: 752000 });
  const view = projectEonCityW752MissionsProgression({ stationView: withVerifiedStation('project-atlas', 'project-shell:w752'), progression: readEonCityW659gProgression({ storage, now: 752001 }) });
  assert.equal(view.myRealm.facetCount, 5);
  assert.equal(view.myRealm.claimedCount, 1);
  assert.equal(view.myRealm.title, 'Signals Forming');
  assert.equal(view.myRealm.privateReflection, true);
  assert.equal(view.myRealm.publicProfileChanged, false);
  assert.equal(view.myRealm.publicWorldCreated, false);
  assert.equal(view.myRealm.multiplayerEnabled, false);
  assert.equal(view.myRealm.privateContentStored, false);
  assert.doesNotMatch(JSON.stringify(view.myRealm), /prompt|credential|project title|wallet|payment/i);
});

test('W752 emits view changes, fails closed on denied storage and renders accessible truth', () => {
  const denied = { getItem() { throw new Error('denied'); }, setItem() { throw new Error('denied'); } };
  const env = environment();
  const events = [];
  env.addEventListener(EON_CITY_W752_VIEW_EVENT, (event) => events.push(event.detail));
  const controller = createEonCityW752MissionsProgression({ stationController: { getView: () => withVerifiedStation('local-ai-lab', 'local-self-test:w752') }, storage: denied, environment: env });
  const result = controller.claimMission('local-ai-lab', { explicitUserAction: true });
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'storage-unavailable');
  assert.equal(controller.getView().xp, 0);
  assert.ok(events.length >= 1);
  const html = renderEonCityW752ProgressionPanel(controller.getView(), 'my-realm-portal');
  assert.match(html, /W752 · productive mission/);
  assert.match(html, /Private My Realm reflection/);
  assert.match(html, /No streaks, paid randomness, loot boxes/);
  assert.doesNotMatch(html, /api key|raw prompt|payment complete|cash reward/i);
  controller.dispose();
});

test('W752 runtime, shared host, CSS, release and production gates converge', () => {
  const runtime = read('assets/js/city/w731/eon-city-w731-command-hub-runtime.js');
  const host = read('assets/js/work-surface/eon-work-surface-host.js');
  const panel = read('assets/js/work-surface/eon-city-progression-panel.js');
  const css = read('assets/css/eon-work-surface.css');
  const sw = read('sw.js');
  const publicSw = read('public/sw.js');
  const build = read('scripts/build-production.mjs');
  assert.match(runtime, /createEonCityW752MissionsProgression/);
  assert.match(runtime, /claimProductiveMission/);
  assert.match(runtime, /openDeterministicVaultReveal/);
  assert.match(runtime, /getMissionsProgression/);
  assert.match(host, /mountEonCityW752ProgressionPanel/);
  assert.match(host, /data-eon-city-progression-slot/);
  assert.match(panel, /EON_CITY_W752_VIEW_EVENT/);
  assert.match(css, /\.eon-city-progression-panel/);
  assert.match(css, /\.eon-city-my-realm-reflection/);
  assert.match(sw, /RELEASE_ID = 'w765-2026-07-31-release-identity-source-template'/);
  assert.equal(publicSw, sw);
  assert.match(build, /eon\.city\.missions-progression\.w752\.v1/);
});
