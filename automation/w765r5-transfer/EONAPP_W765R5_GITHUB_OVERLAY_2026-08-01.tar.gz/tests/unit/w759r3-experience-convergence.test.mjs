import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';

const read = (relative) => fs.readFileSync(new URL(`../../${relative}`, import.meta.url), 'utf8');

test('W759R3 makes the existing 2D Living Nexus visibly event-linked without inventing activity', () => {
  const adapter = read('assets/js/work-surface/adapters/eon-nexus-panel.js');
  assert.match(adapter, /Real-time Nexus feed/);
  assert.match(adapter, /Actual W749 projected state events/);
  assert.match(adapter, /event\?\.detail\?\.reason \|\| 'source-state'/);
  assert.match(adapter, /activityFeed = \[entry, \.\.\.activityFeed\]\.slice\(0, 5\)/);
  assert.match(adapter, /The feed does not invent activity/);
  assert.doesNotMatch(adapter, /setInterval|setTimeout\([^)]*activity/i);
});

test('W759R3 exposes consent-safe browser voice for the visible Nexus status only', () => {
  const adapter = read('assets/js/work-surface/adapters/eon-nexus-panel.js');
  assert.match(adapter, /data-eon-nexus-speak/);
  assert.match(adapter, /SpeechSynthesisUtterance/);
  assert.match(adapter, /speechSynthesis\.speak\(utterance\)/);
  assert.match(adapter, /Microphone remains off/);
  assert.match(adapter, /spokenStatus\(currentView\)/);
  assert.doesNotMatch(adapter, /getUserMedia|SpeechRecognition|webkitSpeechRecognition/);
});

test('W759R3 gives the skyline layered materials, controlled lights and crowns instead of flat slabs', () => {
  const runtime = read('assets/js/city/w731/eon-city-w731-command-hub-runtime.js');
  assert.match(runtime, /w759r3-skyline-near/);
  assert.match(runtime, /w759r3-skyline-mid/);
  assert.match(runtime, /w759r3-skyline-far/);
  assert.match(runtime, /w759r3-skyline-light-strip-/);
  assert.match(runtime, /w759r3-skyline-crown-/);
  assert.match(runtime, /silhouetteStyle: 'w759r3-layered-crown-and-light'/);
  assert.match(runtime, /tier\.id === 'near' \? materials\.skylineNear/);
});

test('W759R3 reduces central Nexus visual spill while preserving all six truthful rings', () => {
  const nexus = read('assets/js/city/w749/eon-city-w749-living-nexus.js');
  assert.match(nexus, /diameter: 3\.24, segments: 32/);
  assert.match(nexus, /diameter: 1\.86 \+ index \* 0\.25/);
  assert.match(nexus, /EON_CITY_W749_RING_IDS\.forEach/);
  assert.match(nexus, /project|task|approval|systems|mission|results/);
  assert.match(nexus, /ownsRenderLoop: false, ownsState: false/);
});

test('W759R3 provides responsive styling for the event feed and explicit voice controls', () => {
  const css = read('assets/css/eon-work-surface.css');
  assert.match(css, /\.eon-nexus-live-feed\{/);
  assert.match(css, /\.eon-nexus-voice-controls\{/);
  assert.match(css, /max-height:9\.6rem/);
  assert.match(css, /grid-template-columns:auto auto minmax\(0,1fr\)/);
});
