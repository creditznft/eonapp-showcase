/**
 * W731–W734 — one launch runtime for the compact EON City Command Hub.
 *
 * One Engine, one Scene, one render loop and one bounded playable space.
 * Productive work opens through the shared City Dock by default, with an explicit Focus Workspace mode.
 * Old district-belt, Living Nexus realm and Expanse layers are intentionally
 * absent from this import graph.
 */
import { Engine } from '@babylonjs/core/Engines/engine.js';
import { Scene } from '@babylonjs/core/scene.js';
import { ArcRotateCamera } from '@babylonjs/core/Cameras/arcRotateCamera.js';
import { HemisphericLight } from '@babylonjs/core/Lights/hemisphericLight.js';
import { DirectionalLight } from '@babylonjs/core/Lights/directionalLight.js';
import { PointLight } from '@babylonjs/core/Lights/pointLight.js';
import { MeshBuilder } from '@babylonjs/core/Meshes/meshBuilder.js';
import { StandardMaterial } from '@babylonjs/core/Materials/standardMaterial.js';
import { PBRMaterial } from '@babylonjs/core/Materials/PBR/pbrMaterial.js';
import { DynamicTexture } from '@babylonjs/core/Materials/Textures/dynamicTexture.js';
import { TransformNode } from '@babylonjs/core/Meshes/transformNode.js';
import { Color3, Color4 } from '@babylonjs/core/Maths/math.color.js';
import { Matrix, Vector3 } from '@babylonjs/core/Maths/math.vector.js';
import { PointerEventTypes } from '@babylonjs/core/Events/pointerEvents.js';
import '@babylonjs/core/Collisions/collisionCoordinator.js';
import { createEonCityW731MovementRenderRecovery } from './eon-city-w731-movement-render-recovery.js';
import { createEonCityW695LocomotionTruthController } from '../w695/eon-city-w695-character-motion-truth.js';
import { resolveEonCityW719KeyboardCode } from '../w719/eon-city-w719-input-authority.js';
import {
  EON_CITY_W747_ARRIVAL_CORRIDOR,
  EON_CITY_W747_CAMERA_POSES,
  EON_CITY_W747_FIVE_WING_ANCHORS,
  EON_CITY_W747_HERO_ZONE,
  EON_CITY_W747_OPERATIONS_CRESCENT,
  EON_CITY_W747_SPATIAL_SCHEMA,
  createEonCityW747SpatialDiagnostics,
  sanitizeEonCityW747WorldPoint,
  validateEonCityW747SpatialFoundation
} from '../w747/eon-city-w747-spatial-foundation.js';
import {
  createEonCityW748InteractionRegistry,
  getEonCityW748DefaultInteraction,
  getEonCityW748StationInteraction,
  validateEonCityW748InteractionRegistry
} from '../w748/eon-city-w748-interaction-registry.js';
import {
  createEonCityW748WorkspacePresenter,
  validateEonCityW748WorkspacePresenterContract
} from '../w748/eon-city-w748-workspace-presenter.js';
import { createEonNexusEventAdapter } from '../../nexus/eon-nexus-event-adapter.js';
import { readEonNexusContinuitySnapshot } from '../../nexus/eon-nexus-continuity-contract.js';
import {
  EON_CITY_W749_LIVING_NEXUS_SCHEMA,
  EON_CITY_W749_RING_IDS,
  EON_CITY_W749_VIEW_EVENT,
  createEonCityW749LivingNexus,
  validateEonCityW749LivingNexusContract
} from '../w749/eon-city-w749-living-nexus.js';
import {
  createEonCityTruthfulCommandCenterController,
  validateEonCityTruthfulCommandCenterSnapshot
} from '../eon-city-truthful-command-center.js';
import {
  createEonCityGenuineAgentTheatreController,
  validateEonCityGenuineAgentTheatreSnapshot
} from '../eon-city-genuine-agent-theatre.js';
import {
  EON_CITY_W750_COMMAND_CENTRE_SCHEMA,
  EON_CITY_W750_WALL_IDS,
  createEonCityW750CommandCentre,
  validateEonCityW750CommandCentreContract
} from '../w750/eon-city-w750-command-centre.js';
import {
  EON_CITY_W751_PRODUCTIVE_STATIONS_SCHEMA,
  createEonCityW751ProductiveStations,
  validateEonCityW751ProductiveStations
} from '../w751/eon-city-w751-productive-stations.js';
import {
  EON_CITY_W765R5_STATION_MONITOR_SCHEMA,
  createEonCityW765R5StationMonitor,
  projectEonCityW765R5StationMonitor,
  validateEonCityW765R5StationMonitorContract
} from '../w765/eon-city-w765r5-station-monitor.js';
import {
  EON_CITY_W752_SCHEMA,
  createEonCityW752MissionsProgression,
  validateEonCityW752MissionsProgression
} from '../w752/eon-city-w752-missions-progression.js';
import {
  EON_CITY_W756_SCHEMA,
  buildEonCityW756ExperiencePlan,
  createEonCityW756SemanticNavigationController,
  validateEonCityW756ExperiencePlan
} from '../w756/eon-city-w756-onboarding-navigation-accessibility.js';
import {
  EON_CITY_W757_SCHEMA,
  buildEonCityW757ReliabilityPlan,
  createEonCityW757ReliabilityController,
  validateEonCityW757ReliabilityPlan
} from '../w757/eon-city-w757-performance-reliability.js';
import {
  EON_CITY_W755_SCHEMA,
  buildEonCityW755EnvironmentPlan,
  createEonCityW755EnvironmentController,
  resolveEonCityW755LocalTimeProfile,
  validateEonCityW755EnvironmentPlan
} from '../w755/eon-city-w755-environment-art-audio.js';
import {
  EON_CITY_W754_SCHEMA,
  EON_CITY_W754_CAPSULE_ID,
  EON_CITY_W754_CAPSULE_FORWARD_AXIS,
  buildEonCityW754CastPlan,
  buildEonCityW754NpcSchedulePlan,
  createEonCityW754NpcScheduleController,
  createEonCityW754TransitController,
  resolveEonCityW754EonbotSafeTarget,
  validateEonCityW754Contract
} from '../w754/eon-city-w754-cast-eonbot-npc-transit.js';
import {
  EON_CITY_W731_COMMAND_HUB_SCHEMA,
  EON_CITY_W731_RUNTIME_OWNER_SCHEMA,
  EON_CITY_W731_RESUME_KEY,
  EON_CITY_W731_STATIONS,
  EON_CITY_W737_DISCOVERIES,
  EON_CITY_W731_FUTURE_GATEWAYS,
  EON_CITY_W731_WORLD_BOUNDS,
  EON_CITY_W731_SPAWN,
  EON_CITY_W731_EONBOT_DOCK,
  EON_CITY_W743_ARRIVAL_CAMERA,
  clampEonCityW731Position,
  getEonCityW731Station,
  getEonCityW737Discovery,
  resolveEonCityW731NearestStation,
  resolveEonCityW737NearestDiscovery,
  inspectEonCityW743ArrivalCamera,
  validateEonCityW731CommandHubContract
} from './eon-city-w731-command-hub-contract.js';
import {
  EON_CITY_W731_LAUNCH_ASSET_MANIFEST,
  EON_CITY_W757_RUNTIME_PROVENANCE,
  validateEonCityW731LaunchAssetManifest
} from './eon-city-w731-launch-asset-manifest.js';
import {
  EON_CITY_W744_STATION_COMPLETION_SCHEMA,
  EON_CITY_W744_STATION_BLUEPRINTS,
  getEonCityW744StationBlueprint,
  validateEonCityW744StationCompletion
} from './eon-city-w744-station-completion-contract.js';
import {
  EON_CITY_W745_HERO_PRESENTATION_SCHEMA,
  createEonCityW745HeroPresentationDirector,
  getEonCityW745HeroPresentationTruth
} from './eon-city-w745-hero-companion-polish.js';
import {
  EON_CITY_W737_MISSIONS,
  buildEonCityW737MissionView,
  getEonCityW737MissionForStation,
  getEonCityW737MissionForDiscovery,
  writeEonCityW737MissionState,
  validateEonCityW737MissionContract
} from '../w737/eon-city-w737-missions.js';
import {
  EON_CITY_W760_W765_SCHEMA,
  EON_CITY_W760_SCENE_PROFILE,
  EON_CITY_W761_CHARACTER_PROFILE,
  EON_CITY_W763_MENU_ORDER,
  createEonCityW762NexusReactionController,
  createEonCityW764RewardReactionController,
  auditEonCityW763InteractionCompleteness,
  validateEonCityW760W765Convergence
} from '../w760/eon-city-w760-w765-command-core-convergence.js';

// Preserve the maintained W759 runtime identity; W760-W765 capability is
// advertised by EON_CITY_W765_CONVERGENCE_SCHEMA rather than by forking the core runtime.
// Historical W757 source-gate checkpoint: EON_CITY_CORE_RUNTIME_SCHEMA = 'eon.city.command-centre-runtime.w757.v1'
export const EON_CITY_CORE_RUNTIME_SCHEMA = 'eon.city.command-centre-runtime.w759.v1';
export const EON_CITY_BOOT_TRACE_KEY = 'eon:city:boot-trace:w737:v1';
const freeze = (value) => Object.freeze(value);
const TAU = Math.PI * 2;
const STATIONARY_NPC_GESTURES = freeze(['talk', 'wave', 'interact']);
const EON_CITY_W760_CAMERA_POSES = freeze({
  arrival: freeze({ ...EON_CITY_W747_CAMERA_POSES.arrival, ...EON_CITY_W760_SCENE_PROFILE.camera.arrival, id: 'w760-arrival', target: freeze({ ...EON_CITY_W760_SCENE_PROFILE.camera.arrival.target }) }),
  return: freeze({ ...EON_CITY_W747_CAMERA_POSES.return, ...EON_CITY_W760_SCENE_PROFILE.camera.return, id: 'w760-return', target: freeze({ ...EON_CITY_W760_SCENE_PROFILE.camera.return.target }) }),
  nexusFocus: freeze({ ...EON_CITY_W747_CAMERA_POSES.nexusFocus, ...EON_CITY_W760_SCENE_PROFILE.camera.nexusFocus, id: 'w760-nexus-focus', target: freeze({ ...EON_CITY_W760_SCENE_PROFILE.camera.nexusFocus.target }) }),
  commandWall: freeze({
    id: 'w765r4-command-wall-focus', alpha: Math.PI / 2, beta: 1.08, radius: 11.4,
    target: freeze({ x: -13.5, y: 3.37, z: -12.6 }),
    lowerRadiusLimit: 8.5, upperRadiusLimit: 15.5, lowerBetaLimit: 0.72, upperBetaLimit: 1.34
  }),
  follow: EON_CITY_W747_CAMERA_POSES.follow
});

const PALETTES = freeze({
  graphite: freeze({ background: '#070a08', floor: '#111612', surface: '#1a211c', structure: '#313b33', accent: '#9bb29f', accent2: '#c8d5ca', warm: '#d5c6a8', text: '#f1f4f1' }),
  obsidian: freeze({ background: '#020303', floor: '#090a0b', surface: '#111315', structure: '#2c3034', accent: '#d9dde2', accent2: '#aab2bc', warm: '#e6e2d8', text: '#fbfcfd' }),
  ember: freeze({ background: '#0d0806', floor: '#17100c', surface: '#251813', structure: '#513528', accent: '#c77d48', accent2: '#e3b181', warm: '#ffd0a2', text: '#fff6ec' })
});

const KEY_TO_DIRECTION = freeze({
  KeyW: 'forward', ArrowUp: 'forward', KeyS: 'backward', ArrowDown: 'backward',
  KeyA: 'left', ArrowLeft: 'left', KeyD: 'right', ArrowRight: 'right'
});

const LEGACY_LANDMARK_TO_STATION = freeze({
  orientation: 'eonbot-nexus', 'orientation-hall': 'eonbot-nexus', command: 'command-console', 'command-centre': 'command-console',
  creator: 'create-forge', 'creator-atrium': 'create-forge', forge: 'create-forge', 'forge-basilica': 'create-forge',
  archive: 'project-atlas', 'archive-canopy': 'project-atlas', vault: 'library-vault', 'vault-station': 'library-vault',
  trade: 'plans-access', 'trade-dome': 'plans-access', transit: 'share-capture', 'transit-network': 'share-capture',
  agent: 'automation-theatre', 'agent-theatre': 'automation-theatre'
});

function now() {
  return globalThis.performance?.now?.() || Date.now();
}

function safeText(value = '') {
  return String(value || '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
}

function isEonCityW759PresentationReady(loaded) {
  return loaded?.ok === true && loaded?.presentation?.ready === true;
}

function isEonCityW759NodeEnabled(node) {
  if (!node) return false;
  try { return node.isEnabled?.(true) !== false; } catch { return false; }
}

function summarizeEonCityW759LoadedPresentation(loaded) {
  const presentation = loaded?.presentation || null;
  return freeze({
    loaded: loaded?.ok === true,
    ready: isEonCityW759PresentationReady(loaded),
    alias: String(loaded?.entry?.alias || ''),
    role: String(loaded?.entry?.role || ''),
    variantName: String(loaded?.variantName || ''),
    targetHeight: Number(loaded?.entry?.targetHeight || 0),
    actualHeight: presentation?.actualHeight ?? null,
    heightRatio: presentation?.heightRatio ?? null,
    horizontalOffset: presentation?.horizontalOffset ?? null,
    groundOffset: presentation?.groundOffset ?? null,
    worldRadius: presentation?.worldRadius ?? null,
    renderableMeshes: Number(presentation?.renderableMeshes || 0),
    enabledMeshes: Number(presentation?.enabledMeshes || 0),
    visibleMeshes: Number(presentation?.visibleMeshes || 0),
    reasons: presentation?.reasons || freeze([]),
    bounds: loaded?.bounds || null
  });
}

function trace(host, startedAt, stage, detail = '') {
  const record = freeze({ stage, detail: String(detail || '').slice(0, 120), elapsedMs: Math.max(0, Math.round(now() - startedAt)), at: new Date().toISOString() });
  const root = host?.closest?.('[data-eon-city-play-root]') || host?.parentElement;
  if (root?.dataset) {
    root.dataset.eonCityBootStage = stage;
    root.dataset.eonCityBootElapsedMs = String(record.elapsedMs);
  }
  try {
    const prior = JSON.parse(globalThis.sessionStorage?.getItem(EON_CITY_BOOT_TRACE_KEY) || '[]');
    globalThis.sessionStorage?.setItem(EON_CITY_BOOT_TRACE_KEY, JSON.stringify([...(Array.isArray(prior) ? prior : []), record].slice(-32)));
  } catch {}
  try { console.info(`[CITY_W737_${stage}]`, record); } catch {}
  return record;
}

function themePalette(documentRef = globalThis.document) {
  const id = String(documentRef?.documentElement?.dataset?.theme || 'graphite').toLowerCase();
  return PALETTES[id] || PALETTES.graphite;
}

function color(value, fallback = '#ffffff') {
  try { return Color3.FromHexString(String(value || fallback)); } catch { return Color3.FromHexString(fallback); }
}

function makeMaterial(scene, name, { diffuse, emissive = diffuse, emissiveIntensity = 0.12, alpha = 1, specular = '#080808' } = {}) {
  const material = new StandardMaterial(name, scene);
  material.diffuseColor = color(diffuse, '#111111');
  material.emissiveColor = color(emissive, diffuse || '#111111').scale(Math.max(0, Number(emissiveIntensity || 0)));
  material.specularColor = color(specular, '#080808');
  material.alpha = Math.max(0.04, Math.min(1, Number(alpha || 1)));
  material.backFaceCulling = material.alpha > 0.96;
  return material;
}

function makePbrMaterial(scene, name, { base = '#111111', emissive = '#000000', emissiveIntensity = 0, metallic = 0.45, roughness = 0.48, alpha = 1 } = {}) {
  const material = new PBRMaterial(name, scene);
  material.albedoColor = color(base, '#111111');
  material.emissiveColor = color(emissive, '#000000').scale(Math.max(0, Number(emissiveIntensity || 0)));
  material.metallic = Math.max(0, Math.min(1, Number(metallic || 0)));
  material.roughness = Math.max(0.04, Math.min(1, Number(roughness || 0.48)));
  material.alpha = Math.max(0.04, Math.min(1, Number(alpha || 1)));
  material.backFaceCulling = material.alpha > 0.96;
  return material;
}

function applyW755EnvironmentPlan({ scene, hemisphere, direction, world, plan }) {
  if (!scene || !plan) return freeze({ ok: false, reason: 'environment-unavailable' });
  scene.clearColor = new Color4(...color(plan.lighting.clearColor).asArray(), 1);
  scene.ambientColor = color(plan.lighting.ambientColor);
  scene.fogColor = color(plan.lighting.fogColor);
  scene.fogDensity = Number(plan.lighting.fogDensity || 0.0052);
  if (scene.imageProcessingConfiguration) {
    scene.imageProcessingConfiguration.exposure = Number(plan.lighting.exposure || 1);
    scene.imageProcessingConfiguration.contrast = Number(plan.lighting.contrast || 1.08);
  }
  if (hemisphere) {
    hemisphere.diffuse = color(plan.lighting.hemisphereColor);
    hemisphere.groundColor = color(plan.lighting.groundColor);
    hemisphere.intensity = plan.quality === 'lite' ? 0.78 : 0.92;
  }
  if (direction) {
    direction.diffuse = color(plan.lighting.keyColor);
    direction.intensity = Number(plan.lighting.keyIntensity || 0.62);
  }
  const weather = world?.environment?.weather;
  if (weather?.rainRoot) weather.rainRoot.setEnabled?.(plan.weather.particleCount > 0);
  if (weather?.mistRoot) weather.mistRoot.setEnabled?.(plan.weatherProfile === 'mist');
  if (Array.isArray(weather?.puddles)) {
    weather.puddles.forEach((mesh, index) => mesh?.setEnabled?.(index < Number(plan.weather.puddleCueCount || 0)));
  }
  return freeze({ ok: true, schema: EON_CITY_W755_SCHEMA, timeProfile: plan.timeProfile, weatherProfile: plan.weatherProfile, visualAmbienceOnly: true, realWeather: false });
}

function stationMetadata(station, extra = {}) {
  const part = extra.interactionRole === 'npc' || extra.part === 'npc'
    ? 'npc'
    : extra.interactionRole === 'terminal' || String(extra.part || '').includes('terminal')
      ? 'terminal'
      : 'structure';
  const interaction = getEonCityW748StationInteraction(station.id, part);
  return freeze({
    kind: 'w748-command-hub-interaction', stationId: station.id, surface: station.surface, label: station.label,
    interactionId: interaction?.id || `station:${station.id}`, interactionPart: part,
    accessibilityLabel: interaction?.accessibilityLabel || `Open ${station.label}`,
    truthBoundary: interaction?.truthBoundary || '', primaryAction: interaction?.primaryAction || null,
    interactive: true, explicitUserActionRequired: true, automaticExecution: false, automaticNavigation: false,
    privateDataRead: false, checkoutAutomatic: false, ...extra
  });
}

function createPath(scene, parent, from, to, material, id) {
  const dx = to.x - from.x;
  const dz = to.z - from.z;
  const length = Math.max(0.5, Math.hypot(dx, dz));
  const path = MeshBuilder.CreateBox(`w731-path-${id}`, { width: 1.65, height: 0.05, depth: length }, scene);
  path.parent = parent;
  path.position.set((from.x + to.x) / 2, 0.05, (from.z + to.z) / 2);
  path.rotation.y = Math.atan2(dx, dz);
  path.material = material;
  path.isPickable = false;
  path.metadata = freeze({ kind: 'w731-safe-walking-lane', id, localOnly: true });
  return path;
}

function createProceduralPerson(scene, parent, id, materials, { accent = false, style = 0 } = {}) {
  const root = new TransformNode(`w731-person-${id}`, scene);
  root.parent = parent;
  const proceduralStyles = [
    { ...EON_CITY_W761_CHARACTER_PROFILE.proceduralCitizenStyles[0], body: materials.cyan, limbs: materials.structure, skin: materials.skin },
    { ...EON_CITY_W761_CHARACTER_PROFILE.proceduralCitizenStyles[1], body: materials.violet, limbs: materials.secondaryBase, skin: materials.skinWarm },
    { ...EON_CITY_W761_CHARACTER_PROFILE.proceduralCitizenStyles[2], body: materials.amber, limbs: materials.structure, skin: materials.skinDeep },
    { ...EON_CITY_W761_CHARACTER_PROFILE.proceduralCitizenStyles[3], body: materials.magenta, limbs: materials.secondaryBase, skin: materials.skinLight }
  ];
  // W759R2 baseline checkpoint: head.material = materials.skin; W761 extends this to bounded finished skin variants.
  const selectedStyle = proceduralStyles[Math.abs(Number(style || 0)) % proceduralStyles.length];
  root.metadata = freeze({ kind: 'w761-finished-procedural-citizen', citizenId: id, styleId: selectedStyle.id, untextured: false, animated: true });
  const bodyMaterial = accent ? selectedStyle.body : materials.structure;
  const limbMaterial = accent ? selectedStyle.limbs : materials.secondaryBase;
  const body = MeshBuilder.CreateCapsule(`w731-person-${id}-body`, { height: 1.05, radius: 0.25, tessellation: 10, subdivisions: 2 }, scene);
  body.parent = root;
  body.position.y = 1;
  body.material = bodyMaterial;
  body.isPickable = false;
  const head = MeshBuilder.CreateSphere(`w731-person-${id}-head`, { diameter: 0.42, segments: 12 }, scene);
  head.parent = root;
  head.position.y = 1.68;
  head.material = selectedStyle.skin;
  head.isPickable = false;
  const chest = MeshBuilder.CreateBox(`w731-person-${id}-chest`, { width: 0.24, height: 0.05, depth: 0.06 }, scene);
  chest.parent = root;
  chest.position.set(0, 1.13, -0.24);
  chest.material = materials.signal;
  chest.isPickable = false;

  const makeLimb = (kind, side, x, y, height, radius) => {
    const pivot = new TransformNode(`w731-person-${id}-${side}-${kind}-pivot`, scene);
    pivot.parent = root;
    pivot.position.set(x, y, 0);
    const mesh = MeshBuilder.CreateCapsule(`w731-person-${id}-${side}-${kind}`, { height, radius, tessellation: 8, subdivisions: 1 }, scene);
    mesh.parent = pivot;
    mesh.position.y = -(height * 0.43);
    mesh.material = limbMaterial;
    mesh.isPickable = false;
    return freeze({ pivot, mesh });
  };
  const leftArm = makeLimb('arm', 'left', -0.32, 1.28, 0.65, 0.085);
  const rightArm = makeLimb('arm', 'right', 0.32, 1.28, 0.65, 0.085);
  const leftLeg = makeLimb('leg', 'left', -0.14, 0.58, 0.72, 0.105);
  const rightLeg = makeLimb('leg', 'right', 0.14, 0.58, 0.72, 0.105);
  leftArm.pivot.rotation.z = -0.08;
  rightArm.pivot.rotation.z = 0.08;
  return freeze({
    root,
    nodes: freeze([body, head, chest, leftArm.mesh, rightArm.mesh, leftLeg.mesh, rightLeg.mesh]),
    rig: freeze({ body, head, chest, leftArm: leftArm.pivot, rightArm: rightArm.pivot, leftLeg: leftLeg.pivot, rightLeg: rightLeg.pivot })
  });
}

function stationAccentMaterial(station, materials) {
  const map = {
    'living-nexus': materials.cyan,
    forge: materials.amber,
    atlas: materials.cyan,
    vault: materials.mint,
    signal: materials.magenta,
    console: materials.warm,
    theatre: materials.amber,
    lab: materials.cyan,
    portal: materials.violet,
    access: materials.warm
  };
  return map[station.visual] || materials.accent;
}

function discoveryMetadata(discovery, extra = {}) {
  const interaction = getEonCityW748DefaultInteraction(`discovery:${discovery.id}`);
  return freeze({
    kind: 'w748-city-discovery-interaction', discoveryId: discovery.id, label: discovery.label,
    interactionId: interaction?.id || `discovery:${discovery.id}`,
    accessibilityLabel: interaction?.accessibilityLabel || `Inspect ${discovery.label}`,
    truthBoundary: interaction?.truthBoundary || '', primaryAction: interaction?.primaryAction || null,
    missionId: discovery.missionId, interactive: true, explicitUserActionRequired: true,
    automaticNavigation: false, privateDataRead: false, ...extra
  });
}

function createStation(scene, parent, station, materials) {
  const blueprint = getEonCityW744StationBlueprint(station.id);
  if (!blueprint) throw new Error(`w744-station-blueprint-missing:${station.id}`);
  const root = new TransformNode(`w744-station-${station.id}`, scene);
  root.parent = parent;
  root.position.set(station.position.x, station.position.y, station.position.z);
  root.metadata = stationMetadata(station, { root: true, zone: station.zone, completionSchema: 'w744' });
  const visualRoot = new TransformNode(`w744-station-visual-${station.id}`, scene);
  visualRoot.parent = root;
  const detailRoot = new TransformNode(`w744-station-details-${station.id}`, scene);
  detailRoot.parent = root;
  const terminalAnchor = new TransformNode(`w744-terminal-anchor-${station.id}`, scene);
  terminalAnchor.parent = root;
  terminalAnchor.position.set(blueprint.terminalOffset.x, blueprint.terminalOffset.y, blueprint.terminalOffset.z);
  terminalAnchor.rotation.y = Math.atan2(-terminalAnchor.position.x, -terminalAnchor.position.z);
  terminalAnchor.metadata = stationMetadata(station, { part: 'terminal-anchor', interactionRole: 'terminal', blueprintAssetId: blueprint.terminalAssetId });
  const terminalVisualRoot = new TransformNode(`w744-terminal-fallback-${station.id}`, scene);
  terminalVisualRoot.parent = terminalAnchor;
  const fallbackVisualNodes = [];
  const terminalFallbackNodes = [];
  const stationDetailNodes = [];
  const animated = [];
  const accentMaterial = stationAccentMaterial(station, materials);
  const add = (mesh, { part = 'structure', material = accentMaterial, position = null, rotation = null, pickable = true } = {}) => {
    mesh.parent = visualRoot;
    if (position) mesh.position.set(position.x || 0, position.y || 0, position.z || 0);
    if (rotation) mesh.rotation.set(rotation.x || 0, rotation.y || 0, rotation.z || 0);
    mesh.material = material;
    mesh.isPickable = pickable;
    mesh.checkCollisions = pickable && !['signal', 'halo', 'light'].includes(part);
    if (pickable) mesh.metadata = stationMetadata(station, { part, interactionRole: 'structure', blueprintAssetId: blueprint.structureAssetId });
    fallbackVisualNodes.push(mesh);
    return mesh;
  };
  const addDetail = (mesh, { part = 'architectural-light', material = accentMaterial, position = null, rotation = null, animatedKind = '' } = {}) => {
    mesh.parent = detailRoot;
    if (position) mesh.position.set(position.x || 0, position.y || 0, position.z || 0);
    if (rotation) mesh.rotation.set(rotation.x || 0, rotation.y || 0, rotation.z || 0);
    mesh.material = material;
    mesh.isPickable = false;
    mesh.checkCollisions = false;
    mesh.metadata = freeze({ kind: 'w744-station-detail', stationId: station.id, part, portalMode: blueprint.portalMode, interactive: false });
    stationDetailNodes.push(mesh);
    if (animatedKind) animated.push({ node: mesh, kind: animatedKind, phase: station.priority * 0.41 });
    return mesh;
  };
  const addTerminal = (mesh, { part = 'terminal', material = materials.structure, position = null, rotation = null } = {}) => {
    mesh.parent = terminalVisualRoot;
    if (position) mesh.position.set(position.x || 0, position.y || 0, position.z || 0);
    if (rotation) mesh.rotation.set(rotation.x || 0, rotation.y || 0, rotation.z || 0);
    mesh.material = material;
    mesh.isPickable = true;
    mesh.checkCollisions = false;
    mesh.metadata = stationMetadata(station, { part, interactionRole: 'terminal', blueprintAssetId: blueprint.terminalAssetId });
    terminalFallbackNodes.push(mesh);
    return mesh;
  };

  const base = add(MeshBuilder.CreateCylinder(`w744-${station.id}-base`, {
    diameter: station.ring === 'inner' ? 3.5 : 3.05, height: 0.24, tessellation: 36
  }, scene), { part: 'structure-base', material: station.ring === 'inner' ? materials.stationBase : materials.secondaryBase, position: { y: 0.12 } });
  const selectionRing = MeshBuilder.CreateTorus(`w748-${station.id}-selection-outline`, {
    diameter: Math.max(3.2, Number(station.footprintRadius || 1.8) * 2.12), thickness: 0.055, tessellation: 64
  }, scene);
  selectionRing.parent = root;
  selectionRing.position.y = 0.2;
  selectionRing.rotation.x = Math.PI / 2;
  selectionRing.material = materials.cyan;
  selectionRing.isPickable = false;
  selectionRing.checkCollisions = false;
  selectionRing.metadata = freeze({ kind: 'w748-contextual-selection-outline', interactionId: `station:${station.id}`, decorativeOnly: true, interactive: false });
  selectionRing.setEnabled(false);

  let focusNode = base;
  if (station.visual === 'living-nexus') {
    add(MeshBuilder.CreateCylinder(`w744-${station.id}-pedestal`, { diameterTop: 1.7, diameterBottom: 2.25, height: 0.7, tessellation: 36 }, scene), { part: 'nexus-pedestal', material: materials.structure, position: { y: 0.48 } });
    const core = add(MeshBuilder.CreatePolyhedron(`w744-${station.id}-core`, { type: 2, size: 0.72 }, scene), { part: 'nexus-core', position: { y: 1.72 } });
    const haloA = add(MeshBuilder.CreateTorus(`w744-${station.id}-halo-a`, { diameter: 1.72, thickness: 0.055, tessellation: 48 }, scene), { part: 'halo', material: materials.cyan, position: { y: 1.72 }, rotation: { x: Math.PI / 2.65 }, pickable: false });
    const haloB = add(MeshBuilder.CreateTorus(`w744-${station.id}-halo-b`, { diameter: 2.05, thickness: 0.035, tessellation: 48 }, scene), { part: 'halo', material: materials.warm, position: { y: 1.72 }, rotation: { z: Math.PI / 2.45 }, pickable: false });
    for (let index = 0; index < 3; index += 1) {
      const angle = (index / 3) * TAU;
      addDetail(MeshBuilder.CreateBox(`w744-${station.id}-status-ribbon-${index}`, { width: 0.92, height: 0.48, depth: 0.055 }, scene), {
        part: 'nexus-status-ribbon', material: index === 1 ? materials.warm : materials.glass,
        position: { x: Math.sin(angle) * 1.52, y: 1.18 + (index % 2) * 0.24, z: Math.cos(angle) * 1.52 },
        rotation: { y: angle + Math.PI }, animatedKind: 'pulse'
      });
    }
    focusNode = core;
    animated.push({ node: core, kind: 'float', baseY: 1.72, phase: 0.2 }, { node: haloA, kind: 'ring-a' }, { node: haloB, kind: 'ring-b' });
  } else if (station.visual === 'forge') {
    const bench = add(MeshBuilder.CreateBox(`w744-${station.id}-bench`, { width: 1.65, height: 0.62, depth: 1.15 }, scene), { part: 'forge-structure', material: materials.structure, position: { y: 0.56 } });
    add(MeshBuilder.CreateBox(`w744-${station.id}-fin-left`, { width: 0.22, height: 1.7, depth: 0.5 }, scene), { part: 'forge-structure', position: { x: -0.72, y: 1.35 }, rotation: { z: -0.24 } });
    add(MeshBuilder.CreateBox(`w744-${station.id}-fin-right`, { width: 0.22, height: 1.7, depth: 0.5 }, scene), { part: 'forge-structure', position: { x: 0.72, y: 1.35 }, rotation: { z: 0.24 } });
    const signal = add(MeshBuilder.CreateCylinder(`w744-${station.id}-forge-signal`, { diameter: 0.42, height: 0.14, tessellation: 24 }, scene), { part: 'signal', material: materials.amber, position: { y: 1.05 }, pickable: false });
    focusNode = bench;
    animated.push({ node: signal, kind: 'pulse', phase: 0.5 });
  } else if (station.visual === 'atlas') {
    const table = add(MeshBuilder.CreateCylinder(`w744-${station.id}-table`, { diameter: 2.15, height: 0.72, tessellation: 40 }, scene), { part: 'atlas-structure', material: materials.structure, position: { y: 0.48 } });
    const map = add(MeshBuilder.CreateCylinder(`w744-${station.id}-map`, { diameter: 1.55, height: 0.055, tessellation: 40 }, scene), { part: 'signal', material: materials.cyan, position: { y: 1.15 }, pickable: false });
    const halo = add(MeshBuilder.CreateTorus(`w744-${station.id}-map-halo`, { diameter: 1.5, thickness: 0.04, tessellation: 44 }, scene), { part: 'halo', material: materials.warm, position: { y: 1.42 }, rotation: { x: Math.PI / 2 }, pickable: false });
    focusNode = table;
    animated.push({ node: map, kind: 'float', baseY: 1.15, phase: 1.1 }, { node: halo, kind: 'ring-a' });
  } else if (station.visual === 'vault') {
    add(MeshBuilder.CreateBox(`w744-${station.id}-pillar-left`, { width: 0.42, height: 2.2, depth: 0.62 }, scene), { part: 'vault-structure', material: materials.structure, position: { x: -0.82, y: 1.22 } });
    add(MeshBuilder.CreateBox(`w744-${station.id}-pillar-right`, { width: 0.42, height: 2.2, depth: 0.62 }, scene), { part: 'vault-structure', material: materials.structure, position: { x: 0.82, y: 1.22 } });
    const crown = add(MeshBuilder.CreateBox(`w744-${station.id}-crown`, { width: 2.05, height: 0.38, depth: 0.72 }, scene), { part: 'vault-structure', material: materials.mint, position: { y: 2.3 } });
    const key = add(MeshBuilder.CreatePolyhedron(`w744-${station.id}-key`, { type: 1, size: 0.42 }, scene), { part: 'signal', material: materials.mint, position: { y: 1.42 }, pickable: false });
    focusNode = crown;
    animated.push({ node: key, kind: 'float', baseY: 1.42, phase: 1.7 });
  } else if (station.visual === 'signal') {
    add(MeshBuilder.CreateBox(`w744-${station.id}-mast-left`, { width: 0.22, height: 2.0, depth: 0.28 }, scene), { part: 'share-structure', material: materials.structure, position: { x: -0.78, y: 1.15 } });
    add(MeshBuilder.CreateBox(`w744-${station.id}-mast-right`, { width: 0.22, height: 2.0, depth: 0.28 }, scene), { part: 'share-structure', material: materials.structure, position: { x: 0.78, y: 1.15 } });
    const frame = add(MeshBuilder.CreateBox(`w744-${station.id}-capture-frame`, { width: 1.35, height: 1.05, depth: 0.08 }, scene), { part: 'share-structure', material: materials.magenta, position: { y: 1.38 } });
    const beacon = add(MeshBuilder.CreateSphere(`w744-${station.id}-beacon`, { diameter: 0.28, segments: 16 }, scene), { part: 'signal', material: materials.warm, position: { y: 2.28 }, pickable: false });
    focusNode = frame;
    animated.push({ node: beacon, kind: 'pulse', phase: 2.2 });
  } else if (station.visual === 'theatre') {
    const stage = add(MeshBuilder.CreateCylinder(`w744-${station.id}-stage`, { diameter: 2.3, height: 0.58, tessellation: 40 }, scene), { part: 'automation-structure', material: materials.structure, position: { y: 0.42 } });
    const crown = add(MeshBuilder.CreateTorus(`w744-${station.id}-open-crown`, { diameter: 2.25, thickness: 0.085, tessellation: 48 }, scene), { part: 'halo', material: materials.amber, position: { y: 1.7 }, rotation: { x: Math.PI / 2 }, pickable: false });
    focusNode = stage;
    animated.push({ node: crown, kind: 'ring-a' });
  } else if (station.visual === 'portal') {
    const portal = add(MeshBuilder.CreateTorus(`w744-${station.id}-portal`, { diameter: 2.65, thickness: 0.16, tessellation: 52 }, scene), { part: 'portal-structure', material: materials.violet, position: { y: 1.55 }, rotation: { y: Math.PI / 2 } });
    add(MeshBuilder.CreateBox(`w744-${station.id}-threshold`, { width: 2.35, height: 0.14, depth: 0.75 }, scene), { part: 'portal-structure', material: materials.warm, position: { y: 0.18 } });
    focusNode = portal;
    animated.push({ node: portal, kind: 'ring-a' });
  } else {
    const pedestal = add(MeshBuilder.CreateBox(`w744-${station.id}-pedestal`, { width: station.visual === 'lab' ? 1.35 : 1.6, height: station.visual === 'lab' ? 1.65 : 1.05, depth: 1.05 }, scene), { part: `${station.visual}-structure`, material: materials.structure, position: { y: station.visual === 'lab' ? 0.95 : 0.68 } });
    const screenCount = station.visual === 'console' ? 3 : 1;
    for (let index = 0; index < screenCount; index += 1) {
      const screen = add(MeshBuilder.CreateBox(`w744-${station.id}-screen-${index}`, { width: screenCount > 1 ? 0.55 : 1.12, height: 0.64, depth: 0.07 }, scene), { part: `${station.visual}-structure`, material: accentMaterial, position: { x: (index - (screenCount - 1) / 2) * 0.62, y: station.visual === 'lab' ? 1.55 : 1.2, z: -0.56 } });
      animated.push({ node: screen, kind: 'pulse', phase: station.priority * 0.32 + index });
    }
    if (station.visual === 'lab') {
      const coil = add(MeshBuilder.CreateTorus(`w744-${station.id}-coil`, { diameter: 1.35, thickness: 0.06, tessellation: 40 }, scene), { part: 'halo', material: materials.cyan, position: { y: 1.95 }, rotation: { x: Math.PI / 2 }, pickable: false });
      animated.push({ node: coil, kind: 'ring-b' });
    }
    focusNode = pedestal;
  }

  // Every station keeps its visual identity after the authored structure loads:
  // a light frame, threshold/portal cue and local beacons remain active.
  if (blueprint.portalMode !== 'none') {
    if (blueprint.portalMode === 'real-portal') {
      addDetail(MeshBuilder.CreateTorus(`w744-${station.id}-detail-portal`, { diameter: 3.05, thickness: 0.055, tessellation: 52 }, scene), {
        part: 'portal-light', material: materials.violet, position: { y: 1.58 }, rotation: { y: Math.PI / 2 }, animatedKind: 'ring-a'
      });
    } else {
      addDetail(MeshBuilder.CreateBox(`w744-${station.id}-threshold-left`, { width: 0.07, height: 2.15, depth: 0.08 }, scene), { part: 'threshold-light', position: { x: -1.3, y: 1.18, z: -0.65 } });
      addDetail(MeshBuilder.CreateBox(`w744-${station.id}-threshold-right`, { width: 0.07, height: 2.15, depth: 0.08 }, scene), { part: 'threshold-light', position: { x: 1.3, y: 1.18, z: -0.65 } });
      addDetail(MeshBuilder.CreateBox(`w744-${station.id}-threshold-crown`, { width: 2.67, height: 0.07, depth: 0.08 }, scene), { part: 'threshold-light', position: { y: 2.25, z: -0.65 } });
    }
  }
  const beaconCount = Math.max(2, Number(blueprint.lighting.beacons || 2));
  for (let index = 0; index < beaconCount; index += 1) {
    const angle = (index / beaconCount) * TAU + station.priority * 0.17;
    const radius = station.ring === 'inner' ? 1.72 : 1.5;
    addDetail(MeshBuilder.CreateCylinder(`w744-${station.id}-beacon-post-${index}`, { diameter: 0.06, height: 0.72, tessellation: 10 }, scene), {
      part: 'beacon-post', material: materials.structure, position: { x: Math.sin(angle) * radius, y: 0.46, z: Math.cos(angle) * radius }
    });
    addDetail(MeshBuilder.CreateSphere(`w744-${station.id}-beacon-light-${index}`, { diameter: 0.13, segments: 8 }, scene), {
      part: 'beacon-light', material: accentMaterial, position: { x: Math.sin(angle) * radius, y: 0.84, z: Math.cos(angle) * radius }, animatedKind: 'pulse'
    });
  }

  // Dedicated usable terminal fallback. Authored terminal assets replace this
  // mesh set independently from the station building.
  addTerminal(MeshBuilder.CreateBox(`w744-${station.id}-terminal-body`, { width: 0.92, height: 0.86, depth: 0.72 }, scene), { position: { y: 0.48 } });
  addTerminal(MeshBuilder.CreateBox(`w744-${station.id}-terminal-screen`, { width: 0.78, height: 0.48, depth: 0.055 }, scene), { material: accentMaterial, position: { y: 1.08, z: -0.31 }, rotation: { x: -0.16 } });
  addTerminal(MeshBuilder.CreateBox(`w744-${station.id}-terminal-strip`, { width: 0.58, height: 0.055, depth: 0.08 }, scene), { part: 'terminal-control', material: materials.warm, position: { y: 0.83, z: -0.39 } });

  const npcAnchor = new TransformNode(`w744-npc-anchor-${station.id}`, scene);
  npcAnchor.parent = root;
  const home = new Vector3(station.ring === 'inner' ? 1.75 : 1.55, 0, station.ring === 'inner' ? 0.42 : 0.25);
  npcAnchor.position.copyFrom(home);
  npcAnchor.rotation.y = Math.atan2(-npcAnchor.position.x, -npcAnchor.position.z);
  npcAnchor.metadata = freeze({
    kind: 'w744-role-npc', stationId: station.id, ...station.npc, npcAlias: blueprint.npcAlias,
    zone: station.zone, motionPolicy: blueprint.npcRoute.enabled ? 'bounded-station-route' : 'nexus-companion',
    locomotionAllowed: blueprint.npcRoute.enabled, routeRadius: blueprint.npcRoute.radius,
    interactive: true, fakeWork: false, walkingInPlaceAllowed: false
  });
  const fallbackNpc = createProceduralPerson(scene, npcAnchor, station.npc.id, materials, { accent: station.ring === 'inner' });
  // Production rule: an NPC is an authored 3D character or it is not shown.
  // Procedural figures remain disabled as an internal recovery object only.
  fallbackNpc.root.setEnabled(false);
  const npcHitTarget = MeshBuilder.CreateCapsule(`w744-${station.id}-npc-interaction`, { height: 1.95, radius: 0.42, tessellation: 8, subdivisions: 1 }, scene);
  npcHitTarget.parent = npcAnchor;
  npcHitTarget.position.y = 0.95;
  npcHitTarget.material = materials.glass;
  npcHitTarget.visibility = 0.012;
  npcHitTarget.isPickable = true;
  npcHitTarget.checkCollisions = false;
  npcHitTarget.metadata = stationMetadata(station, { part: 'npc', interactionRole: 'npc', npcName: station.npc.name, npcAlias: blueprint.npcAlias });
  // Do not expose an invisible or procedural NPC interaction before the real
  // authored character has loaded. The terminal remains the station fallback.
  npcHitTarget.setEnabled(false);

  const toTerminal = new Vector3(blueprint.terminalOffset.x, 0, blueprint.terminalOffset.z).subtract(home);
  const distance = Math.max(0.001, toTerminal.length());
  const terminalPosition = home.add(toTerminal.scale(Math.min(blueprint.npcRoute.radius || 0, distance) / distance));
  const routeEnabled = blueprint.npcRoute.enabled && terminalPosition.subtract(home).length() > 0.2;
  const routeState = {
    enabled: routeEnabled,
    radius: blueprint.npcRoute.radius,
    speed: blueprint.npcRoute.speed,
    dwellMs: blueprint.npcRoute.dwellMs,
    terminalDwellMs: blueprint.npcRoute.terminalDwellMs,
    home: home.clone(), terminal: terminalPosition.clone(), phase: 'dwell-home', phaseUntil: 3_000 + station.priority * 430,
    lastAt: 0, moving: false, animationState: 'idle', suspendedUntil: 0, actualDistanceTravelled: 0
  };

  return {
    station, blueprint, root, visualRoot, detailRoot, terminalAnchor, terminalVisualRoot,
    base, selectionRing, focusNode, npcAnchor, fallbackNpc, npcHitTarget,
    fallbackVisualNodes: freeze(fallbackVisualNodes), terminalFallbackNodes: freeze(terminalFallbackNodes),
    stationDetailNodes: freeze(stationDetailNodes), animated: freeze(animated), npcRoute: routeState,
    activationPulseUntil: 0, loadedNpc: null, loadedWorld: null, loadedTerminal: null,
    npcGestureState: 'idle', npcGestureUntil: 0, nextNpcGestureAt: 3_500 + station.priority * 1_150
  };
}

function createDiscovery(scene, parent, discovery, materials) {
  const root = new TransformNode(`w737-discovery-${discovery.id}`, scene);
  root.parent = parent;
  root.position.set(discovery.position.x, discovery.position.y, discovery.position.z);
  root.metadata = discoveryMetadata(discovery, { root: true });
  const visualRoot = new TransformNode(`w737-discovery-visual-${discovery.id}`, scene);
  visualRoot.parent = root;
  const selectionRing = MeshBuilder.CreateTorus(`w748-${discovery.id}-selection-outline`, { diameter: 3.7, thickness: 0.05, tessellation: 56 }, scene);
  selectionRing.parent = root;
  selectionRing.position.y = 0.18;
  selectionRing.rotation.x = Math.PI / 2;
  selectionRing.material = materials.warm;
  selectionRing.isPickable = false;
  selectionRing.checkCollisions = false;
  selectionRing.metadata = freeze({ kind: 'w748-contextual-selection-outline', interactionId: `discovery:${discovery.id}`, decorativeOnly: true, interactive: false });
  selectionRing.setEnabled(false);
  const nodes = [];
  const add = (mesh, material, position = {}, rotation = {}) => {
    mesh.parent = visualRoot;
    mesh.position.set(position.x || 0, position.y || 0, position.z || 0);
    mesh.rotation.set(rotation.x || 0, rotation.y || 0, rotation.z || 0);
    mesh.material = material;
    mesh.isPickable = true;
    mesh.checkCollisions = true;
    mesh.metadata = discoveryMetadata(discovery, { part: 'landmark' });
    nodes.push(mesh);
    return mesh;
  };
  add(MeshBuilder.CreateCylinder(`w737-${discovery.id}-base`, { diameter: 3.1, height: 0.22, tessellation: 36 }, scene), materials.secondaryBase, { y: 0.11 });
  let focusNode;
  if (discovery.id === 'expanse-overlook') {
    focusNode = add(MeshBuilder.CreateTorus(`w737-${discovery.id}-gate`, { diameter: 3.5, thickness: 0.18, tessellation: 56 }, scene), materials.violet, { y: 1.85 }, { y: Math.PI / 2 });
    add(MeshBuilder.CreateBox(`w737-${discovery.id}-seal`, { width: 2.75, height: 2.8, depth: 0.08 }, scene), materials.glass, { y: 1.55 });
  } else {
    focusNode = add(MeshBuilder.CreateCylinder(`w737-${discovery.id}-beacon`, { diameterTop: 0.32, diameterBottom: 0.7, height: 2.55, tessellation: 28 }, scene), discovery.id === 'forge-overlook' ? materials.amber : materials.cyan, { y: 1.38 });
    const ring = add(MeshBuilder.CreateTorus(`w737-${discovery.id}-ring`, { diameter: 1.55, thickness: 0.055, tessellation: 40 }, scene), materials.warm, { y: 2.2 }, { x: Math.PI / 2 });
    ring.checkCollisions = false;
  }
  return { discovery, root, visualRoot, selectionRing, focusNode, fallbackVisualNodes: freeze(nodes), loadedWorld: null };
}

function createCommandCentreArchitecture(scene, parent, materials) {
  const root = new TransformNode('w744-command-centre-architecture', scene);
  root.parent = parent;
  const centralFloor = MeshBuilder.CreateCylinder('w744-command-centre-floor', { diameter: EON_CITY_W731_WORLD_BOUNDS.commandCentreRadius * 2, height: 0.18, tessellation: 72 }, scene);
  centralFloor.parent = root; centralFloor.position.y = 0.01; centralFloor.material = materials.stationBase; centralFloor.isPickable = false;
  centralFloor.metadata = freeze({ kind: 'w744-command-centre-floor', designed: true, interactive: false });

  // Microchip/circuit floor language: concentric buses, radial traces and chip
  // nodes visually bind every station to the Living Nexus without adding a
  // second runtime or decorative fake work.
  const circuitRoot = new TransformNode('w744-command-centre-circuit-floor', scene);
  circuitRoot.parent = root;
  const circuitNodes = [];
  const circuitPulses = [];
  const addCircuit = (mesh, material = materials.cyan) => {
    mesh.parent = circuitRoot;
    mesh.material = material;
    mesh.isPickable = false;
    mesh.checkCollisions = false;
    mesh.metadata = freeze({ kind: 'w744-command-centre-circuit-floor', interactive: false, decorativeOnly: true });
    circuitNodes.push(mesh);
    return mesh;
  };
  for (const diameter of [5.7, 12.6, 20.8]) {
    const ring = addCircuit(MeshBuilder.CreateTorus(`w744-circuit-ring-${diameter}`, { diameter, thickness: diameter < 8 ? 0.055 : 0.035, tessellation: 72 }, scene), diameter < 8 ? materials.warm : materials.cyan);
    ring.position.y = 0.125;
    ring.rotation.x = Math.PI / 2;
  }
  for (const station of EON_CITY_W731_STATIONS.filter((entry) => entry.id !== 'eonbot-nexus')) {
    const dx = station.position.x;
    const dz = station.position.z + 1.3;
    const length = Math.max(1, Math.hypot(dx, dz) - 1.5);
    const trace = addCircuit(MeshBuilder.CreateBox(`w744-circuit-trace-${station.id}`, { width: (station.ring === 'inner' ? 0.1 : 0.065) * EON_CITY_W760_SCENE_PROFILE.floor.traceWidthMultiplier, height: 0.025, depth: length }, scene), stationAccentMaterial(station, materials));
    const scale = length / Math.max(0.001, Math.hypot(dx, dz));
    trace.position.set(dx * scale * 0.5, 0.135, 1.3 + dz * scale * 0.5);
    trace.rotation.y = Math.atan2(dx, dz);
    for (const fraction of [0.34, 0.7]) {
      const pad = addCircuit(MeshBuilder.CreateBox(`w744-circuit-node-${station.id}-${fraction}`, { width: 0.28, height: 0.035, depth: 0.28 }, scene), fraction < 0.5 ? materials.warm : stationAccentMaterial(station, materials));
      pad.position.set(dx * scale * fraction, 0.145, 1.3 + dz * scale * fraction);
      pad.rotation.y = trace.rotation.y;
    }
    const pulse = MeshBuilder.CreateSphere(`w745-circuit-data-pulse-${station.id}`, { diameter: station.ring === 'inner' ? 0.14 : 0.11, segments: 8 }, scene);
    pulse.parent = circuitRoot;
    pulse.material = stationAccentMaterial(station, materials);
    pulse.isPickable = false;
    pulse.checkCollisions = false;
    pulse.metadata = freeze({ kind: 'w745-command-centre-data-pulse', stationId: station.id, decorativeOnly: true, interactive: false });
    circuitPulses.push(freeze({
      node: pulse,
      from: freeze({ x: 0, y: 0.19, z: 1.3 }),
      to: freeze({ x: dx * scale, y: 0.19, z: 1.3 + dz * scale }),
      phase: station.priority * 0.113,
      speed: (station.ring === 'inner' ? 0.16 : 0.11) * EON_CITY_W760_SCENE_PROFILE.floor.pulseSpeedMultiplier
    }));
  }
  for (let index = 0; index < 12; index += 1) {
    const angle = (index / 12) * TAU;
    const chip = addCircuit(MeshBuilder.CreateBox(`w744-nexus-chip-pad-${index}`, { width: index % 3 === 0 ? 0.48 : 0.28, height: 0.035, depth: 0.18 }, scene), index % 3 === 0 ? materials.warm : materials.signal);
    chip.position.set(Math.sin(angle) * 3.42, 0.15, 1.2 + Math.cos(angle) * 3.42);
    chip.rotation.y = angle;
  }

  const canopy = MeshBuilder.CreateTorus('w744-command-centre-canopy', { diameter: EON_CITY_W747_OPERATIONS_CRESCENT.canopy.radius * 2, thickness: 0.22, tessellation: 72 }, scene);
  canopy.parent = root; canopy.position.y = EON_CITY_W747_OPERATIONS_CRESCENT.canopy.height; canopy.rotation.x = Math.PI / 2; canopy.material = materials.structure; canopy.isPickable = false;
  for (let index = 0; index < 8; index += 1) {
    const angle = (index / 8) * TAU + EON_CITY_W747_OPERATIONS_CRESCENT.canopy.columnAngleOffset;
    const column = MeshBuilder.CreateBox(`w744-command-column-${index}`, { width: 0.55, height: 4.5, depth: 0.65 }, scene);
    column.parent = root;
    column.position.set(Math.sin(angle) * EON_CITY_W747_OPERATIONS_CRESCENT.canopy.columnRadius, 2.25, Math.cos(angle) * EON_CITY_W747_OPERATIONS_CRESCENT.canopy.columnRadius);
    column.rotation.y = angle;
    column.material = index % 2 ? materials.structure : materials.secondaryBase;
    column.isPickable = false;
    column.checkCollisions = true;
  }
  const commandTable = MeshBuilder.CreateCylinder('w744-master-command-table', { diameter: 3.2, height: 0.68, tessellation: 48 }, scene);
  const commandTableMetadata = stationMetadata(getEonCityW731Station('command-console'), {
    part: 'command-wall:work', interactionRole: 'structure', commandWallId: 'work', authored: false,
    accessibilityLabel: 'Open the live Work command monitor'
  });
  commandTable.parent = root; commandTable.position.set(EON_CITY_W747_OPERATIONS_CRESCENT.commandTable.position.x, EON_CITY_W747_OPERATIONS_CRESCENT.commandTable.position.y, EON_CITY_W747_OPERATIONS_CRESCENT.commandTable.position.z); commandTable.material = materials.structure; commandTable.isPickable = true; commandTable.metadata = commandTableMetadata;
  const tableGlass = MeshBuilder.CreateCylinder('w744-master-command-table-glass', { diameter: 2.72, height: 0.055, tessellation: 48 }, scene);
  tableGlass.parent = root; tableGlass.position.set(EON_CITY_W747_OPERATIONS_CRESCENT.commandTable.position.x, EON_CITY_W747_OPERATIONS_CRESCENT.commandTable.position.y + 0.38, EON_CITY_W747_OPERATIONS_CRESCENT.commandTable.position.z); tableGlass.material = materials.glass; tableGlass.isPickable = true; tableGlass.metadata = commandTableMetadata;

  // Four bounded real lights provide readable faces and silhouettes while the
  // per-station emissive beacons carry identity without a costly light per prop.
  const commandLights = [];
  for (let index = 0; index < 4; index += 1) {
    const angle = (index / 4) * TAU + Math.PI / 4;
    const light = new PointLight(`w744-command-light-${index}`, new Vector3(Math.sin(angle) * 6.8, 3.7, Math.cos(angle) * 6.8), scene);
    light.parent = root;
    light.diffuse = index % 2 ? color('#e7bd78') : color('#79dfd4');
    light.specular = color('#20231f');
    light.intensity = 0.34;
    light.range = 11.5;
    commandLights.push(light);
    const fixture = MeshBuilder.CreateSphere(`w744-command-light-fixture-${index}`, { diameter: 0.24, segments: 10 }, scene);
    fixture.parent = root; fixture.position.copyFrom(light.position); fixture.material = index % 2 ? materials.warm : materials.cyan; fixture.isPickable = false;
  }

  const environmentAnchors = new Map();
  const anchor = (id, x, y, z, rotationY = 0) => {
    const node = new TransformNode(`w744-environment-anchor-${id}`, scene);
    node.parent = root; node.position.set(x, y, z); node.rotation.y = rotationY; environmentAnchors.set(id, node); return node;
  };
  anchor('command-seat', EON_CITY_W747_OPERATIONS_CRESCENT.commandSeat.position.x, EON_CITY_W747_OPERATIONS_CRESCENT.commandSeat.position.y, EON_CITY_W747_OPERATIONS_CRESCENT.commandSeat.position.z, EON_CITY_W747_OPERATIONS_CRESCENT.commandSeat.rotationY);
  anchor('district-hologram', EON_CITY_W747_OPERATIONS_CRESCENT.districtHologram.position.x, EON_CITY_W747_OPERATIONS_CRESCENT.districtHologram.position.y, EON_CITY_W747_OPERATIONS_CRESCENT.districtHologram.position.z, EON_CITY_W747_OPERATIONS_CRESCENT.districtHologram.rotationY);
  anchor('eonbot-dock', EON_CITY_W731_EONBOT_DOCK.x, EON_CITY_W731_EONBOT_DOCK.y, EON_CITY_W731_EONBOT_DOCK.z, EON_CITY_W747_OPERATIONS_CRESCENT.eonbotDock.rotationY);
  return { root, commandTable, tableGlass, canopy, columns: freeze([...root.getChildMeshes(false)].filter((mesh) => mesh.name.startsWith('w744-command-column-'))), environmentAnchors, circuitRoot, circuitNodeCount: circuitNodes.length, circuitPulses: freeze(circuitPulses), commandLights };
}

function createExteriorMap(scene, parent, materials) {
  const root = new TransformNode('w737-command-horizon-exterior-map', scene);
  root.parent = parent;
  const ring = MeshBuilder.CreateTorus('w737-exterior-discovery-ring', { diameter: 41.5, thickness: 0.72, tessellation: 96 }, scene);
  ring.parent = root; ring.position.y = 0.04; ring.rotation.x = Math.PI / 2; ring.material = materials.lane; ring.isPickable = false;
  const streetLampAnchors = [];
  const proceduralLampPosts = [];
  const lampGlows = [];
  for (let index = 0; index < 16; index += 1) {
    const angle = (index / 16) * TAU;
    const x = Math.sin(angle) * 20.5;
    const z = Math.cos(angle) * 20.5;
    const anchor = new TransformNode(`w744-authored-street-lamp-anchor-${index}`, scene);
    anchor.parent = root;
    anchor.position.set(x, 0, z);
    anchor.rotation.y = angle + Math.PI;
    anchor.metadata = freeze({ kind: 'w744-authored-street-lamp-anchor', index, ambientOnly: true, interactive: false });
    streetLampAnchors.push(anchor);
    const lamp = MeshBuilder.CreateCylinder(`w737-exterior-light-${index}`, { diameter: 0.16, height: 1.85, tessellation: 12 }, scene);
    lamp.parent = root; lamp.position.set(x, 0.95, z); lamp.material = materials.structure; lamp.isPickable = false;
    proceduralLampPosts.push(lamp);
    const glow = MeshBuilder.CreateSphere(`w737-exterior-light-glow-${index}`, { diameter: 0.22, segments: 10 }, scene);
    glow.parent = root; glow.position.set(x, 1.86, z); glow.material = index % 4 === 0 ? materials.warm : materials.cyan; glow.isPickable = false;
    lampGlows.push(glow);
  }
  return {
    root,
    streetLampAnchors: freeze(streetLampAnchors),
    proceduralLampPosts: freeze(proceduralLampPosts),
    lampGlows: freeze(lampGlows),
    authoredStreetLamp: null,
    authoredStreetLampClones: []
  };
}

function createExteriorAmbientCitizens(scene, parent) {
  const root = new TransformNode('w742-exterior-ambient-citizens', scene);
  root.parent = parent;
  // Every roaming citizen uses one of the authored, animated character GLBs.
  // When a quality budget or load failure prevents that asset from resolving,
  // the anchor remains empty: no stick-figure or capsule substitute is shown.
  const profiles = [
    { id: 'citizen-north', assetAlias: 'ambient-citizen-north', radius: 18.2, startAngle: 0.18, direction: 1, speed: 1.15, motion: 'walk' },
    { id: 'citizen-east', assetAlias: 'ambient-citizen-east', radius: 20.4, startAngle: 1.62, direction: -1, speed: 1.38, motion: 'walk' },
    { id: 'citizen-south', assetAlias: 'ambient-citizen-south', radius: 18.9, startAngle: 3.2, direction: 1, speed: 2.35, motion: 'run' },
    { id: 'citizen-west', assetAlias: 'ambient-citizen-west', radius: 21.2, startAngle: 4.72, direction: -1, speed: 1.05, motion: 'walk' }
  ];
  return freeze(profiles.map((profile, index) => {
    const anchor = new TransformNode(`w742-exterior-citizen-anchor-${profile.id}`, scene);
    anchor.parent = root;
    anchor.metadata = freeze({
      kind: 'w765r4-authored-exterior-citizen-anchor',
      citizenId: profile.id,
      assetAlias: profile.assetAlias,
      zone: 'exterior',
      motion: profile.motion,
      locomotionAllowed: true,
      authoredCharacterRequired: true,
      noProceduralFallback: true,
      ambientOnly: true,
      interactive: false,
      fakeWork: false
    });
    return { ...profile, anchor, loaded: null, phase: index * 1.7, animationState: '' };
  }));
}

function createW744AmbientActors(scene, parent, materials) {
  const root = new TransformNode('w744-authored-ambient-actors', scene);
  root.parent = parent;

  const transitAnchor = new TransformNode('w744-transit-capsule-anchor', scene);
  transitAnchor.parent = root;
  transitAnchor.position.set(-18, 2.55, -3.5);
  transitAnchor.metadata = freeze({ kind: 'w754-bounded-transit-capsule', capsuleId: EON_CITY_W754_CAPSULE_ID, forwardAxis: EON_CITY_W754_CAPSULE_FORWARD_AXIS, ambientOnly: false, passengerTravelAutomatic: false, interactive: true, explicitUserActionRequired: true, transitCapsule: true });
  const transitBody = MeshBuilder.CreateCapsule('w744-transit-capsule-fallback', { height: 2.8, radius: 0.56, tessellation: 16, subdivisions: 2 }, scene);
  transitBody.parent = transitAnchor; transitBody.rotation.z = Math.PI / 2; transitBody.material = materials.structure; transitBody.isPickable = true; transitBody.metadata = transitAnchor.metadata;
  const transitRing = MeshBuilder.CreateTorus('w744-transit-capsule-ring', { diameter: 1.65, thickness: 0.08, tessellation: 32 }, scene);
  transitRing.parent = transitAnchor; transitRing.rotation.y = Math.PI / 2; transitRing.material = materials.cyan; transitRing.isPickable = true; transitRing.metadata = transitAnchor.metadata;
  const transitLight = MeshBuilder.CreateSphere('w744-transit-capsule-light', { diameter: 0.24, segments: 10 }, scene);
  transitLight.parent = transitAnchor; transitLight.position.x = 1.35; transitLight.material = materials.warm; transitLight.isPickable = true; transitLight.metadata = transitAnchor.metadata;

  const maintenanceAnchor = new TransformNode('w744-maintenance-worker-anchor', scene);
  maintenanceAnchor.parent = root;
  maintenanceAnchor.position.set(-17.2, 0, 16.9);
  maintenanceAnchor.metadata = freeze({ kind: 'w744-maintenance-worker', ambientOnly: true, boundedRoute: true, walkingInPlaceAllowed: false, interactive: false });
  const maintenanceFallback = createProceduralPerson(scene, maintenanceAnchor, 'maintenance-worker', materials, { accent: true });
  maintenanceFallback.root.scaling.setAll(0.88);
  // Authored worker or no worker: never expose the procedural maintenance rig.
  maintenanceFallback.root.setEnabled(false);

  return {
    root,
    transit: {
      anchor: transitAnchor, fallbackNodes: freeze([transitBody, transitRing, transitLight]), loaded: null,
      radius: 19.2, startAngle: -1.74, speed: 0.105
    },
    maintenance: {
      anchor: maintenanceAnchor, fallbackPerson: maintenanceFallback, loaded: null,
      home: new Vector3(-17.2, 0, 16.9), terminal: new Vector3(-15.9, 0, 18.25),
      phase: 'walk-terminal', phaseUntil: 0, lastAt: 0, moving: true, animationState: 'walk', speed: 0.48
    }
  };
}

function createFutureGateway(scene, parent, gateway, materials) {
  const radius = EON_CITY_W731_WORLD_BOUNDS.playableRadius - 1.2;
  const x = Math.sin(gateway.angle) * radius;
  const z = Math.cos(gateway.angle) * radius;
  const root = new TransformNode(`w731-future-${gateway.id}`, scene);
  root.parent = parent;
  root.position.set(x, 0, z);
  root.rotation.y = gateway.angle;
  const left = MeshBuilder.CreateBox(`w731-future-${gateway.id}-left`, { width: 0.55, height: 3.3, depth: 0.8 }, scene);
  left.parent = root; left.position.set(-1.5, 1.65, 0); left.material = materials.structure; left.isPickable = false;
  const right = left.clone(`w731-future-${gateway.id}-right`); right.parent = root; right.position.x = 1.5;
  const crown = MeshBuilder.CreateBox(`w731-future-${gateway.id}-crown`, { width: 3.55, height: 0.5, depth: 0.85 }, scene);
  crown.parent = root; crown.position.y = 3.05; crown.material = materials.secondaryBase; crown.isPickable = false;
  const seal = MeshBuilder.CreateBox(`w731-future-${gateway.id}-seal`, { width: 2.55, height: 2.55, depth: 0.12 }, scene);
  seal.parent = root; seal.position.y = 1.38; seal.material = materials.glass; seal.isPickable = false;
  root.metadata = freeze({ kind: 'w731-closed-future-gateway', gatewayId: gateway.id, label: gateway.label, available: false, interactive: false, launchClaim: false });
  return root;
}

function createWorld(scene, palette, environmentPlan) {
  const root = new TransformNode('w737-command-centre-root', scene);
  root.metadata = freeze({ kind: 'w737-command-centre-root', schema: EON_CITY_W731_COMMAND_HUB_SCHEMA, convergenceSchema: EON_CITY_W760_W765_SCHEMA, exteriorMap: true });
  const sceneConvergence = EON_CITY_W760_SCENE_PROFILE;
  const materials = {
    floor: makePbrMaterial(scene, 'w755-floor-pbr', { base: palette.floor, emissive: palette.background, emissiveIntensity: 0.055, metallic: 0.68, roughness: 0.34 }),
    lane: makeMaterial(scene, 'w737-lane', { diffuse: palette.surface, emissive: '#4ea8a0', emissiveIntensity: 0.18 }),
    structure: makeMaterial(scene, 'w737-structure', { diffuse: palette.structure, emissive: palette.accent, emissiveIntensity: 0.035 }),
    stationBase: makePbrMaterial(scene, 'w755-station-base-pbr', { base: palette.surface, emissive: palette.accent, emissiveIntensity: 0.075, metallic: 0.52, roughness: 0.4 }),
    secondaryBase: makeMaterial(scene, 'w737-secondary-base', { diffuse: palette.floor, emissive: palette.accent2, emissiveIntensity: 0.05 }),
    accent: makeMaterial(scene, 'w737-accent', { diffuse: '#5f8779', emissive: '#7bd7c7', emissiveIntensity: 0.42 }),
    accent2: makeMaterial(scene, 'w737-accent2', { diffuse: palette.accent2, emissive: palette.accent2, emissiveIntensity: 0.24 }),
    cyan: makeMaterial(scene, 'w737-cyan', { diffuse: '#2f7774', emissive: '#6ce8de', emissiveIntensity: 0.55 }),
    violet: makeMaterial(scene, 'w737-violet', { diffuse: '#62537a', emissive: '#a995d2', emissiveIntensity: 0.34 }),
    amber: makeMaterial(scene, 'w737-amber', { diffuse: '#805a32', emissive: '#efb868', emissiveIntensity: 0.5 }),
    mint: makeMaterial(scene, 'w737-mint', { diffuse: '#477464', emissive: '#91ddbd', emissiveIntensity: 0.42 }),
    magenta: makeMaterial(scene, 'w737-magenta', { diffuse: '#795369', emissive: '#d991b8', emissiveIntensity: 0.36 }),
    warm: makeMaterial(scene, 'w737-warm', { diffuse: palette.warm, emissive: '#e4bd7d', emissiveIntensity: 0.22 }),
    skin: makeMaterial(scene, 'w759r2-procedural-skin-w761-teal-graphite', { diffuse: '#8b6a55', emissive: '#3b241b', emissiveIntensity: 0.08, specular: '#21130e' }),
    skinWarm: makeMaterial(scene, 'w761-procedural-skin-violet-slate', { diffuse: '#a97961', emissive: '#40281f', emissiveIntensity: 0.075, specular: '#21130e' }),
    skinDeep: makeMaterial(scene, 'w761-procedural-skin-amber-charcoal', { diffuse: '#744f3f', emissive: '#302019', emissiveIntensity: 0.07, specular: '#1a100d' }),
    skinLight: makeMaterial(scene, 'w761-procedural-skin-magenta-graphite', { diffuse: '#bc8a70', emissive: '#4a2f27', emissiveIntensity: 0.075, specular: '#281813' }),
    signal: makeMaterial(scene, 'w737-signal', { diffuse: '#90c7bb', emissive: '#78e6d7', emissiveIntensity: 0.62 }),
    glass: makePbrMaterial(scene, 'w755-glass-pbr', { base: '#223e3a', emissive: '#5aa79b', emissiveIntensity: 0.18, metallic: 0.18, roughness: 0.18, alpha: 0.3 }),
    skylineNear: makePbrMaterial(scene, 'w759r3-skyline-near', { base: '#182520', emissive: '#50796c', emissiveIntensity: 0.15, metallic: 0.46, roughness: 0.46 }),
    skylineMid: makeMaterial(scene, 'w759r3-skyline-mid', { diffuse: '#121d1a', emissive: '#3f6258', emissiveIntensity: 0.105 }),
    skylineFar: makeMaterial(scene, 'w759r3-skyline-far', { diffuse: '#0c1311', emissive: '#263d37', emissiveIntensity: 0.065 }),
    skylineAccent: makeMaterial(scene, 'w759r3-skyline-accent', { diffuse: '#315f58', emissive: '#72d7c5', emissiveIntensity: 0.48 }),
    skylineGlass: makePbrMaterial(scene, 'w760-skyline-glass', { base: '#27423d', emissive: '#78d9ca', emissiveIntensity: 0.24, metallic: 0.2, roughness: 0.16, alpha: 0.72 }),
    skylineRoof: makePbrMaterial(scene, 'w760-skyline-roof', { base: '#28352f', emissive: '#d8b778', emissiveIntensity: 0.22, metallic: 0.62, roughness: 0.31 }),
    rewardPulse: makeMaterial(scene, 'w764-reward-pulse', { diffuse: '#a88445', emissive: '#ffe3a1', emissiveIntensity: 0.82, alpha: 0.86 }),
    windows: makeMaterial(scene, 'w737-windows', { diffuse: '#6d5739', emissive: '#d7a65f', emissiveIntensity: 0.42 })
  };

  const ground = MeshBuilder.CreateCylinder('w737-command-horizon-ground', { diameter: EON_CITY_W731_WORLD_BOUNDS.playableRadius * 2, height: 0.32, tessellation: 96 }, scene);
  ground.parent = root; ground.position.y = -0.16; ground.material = materials.floor; ground.isPickable = false;
  ground.metadata = freeze({ kind: 'w737-playable-ground', bounded: true, exteriorMap: true, interactive: false });
  const underside = MeshBuilder.CreateCylinder('w731-command-hub-world-safety-underlay', { diameter: EON_CITY_W731_WORLD_BOUNDS.playableRadius * 2.08, height: 7.8, tessellation: 72 }, scene);
  underside.parent = root; underside.position.y = -4.18; underside.material = materials.skylineFar; underside.isPickable = false;
  underside.metadata = freeze({ kind: 'w737-world-safety-underlay', hidesWorldUnderside: true, interactive: false });

  const architecture = createCommandCentreArchitecture(scene, root, materials);
  const exteriorMap = createExteriorMap(scene, root, materials);
  const ambientCitizens = createExteriorAmbientCitizens(scene, root);
  const ambientActors = createW744AmbientActors(scene, root, materials);

  const orientationRing = MeshBuilder.CreateTorus('w737-orientation-core-ring', { diameter: 7.1, thickness: 0.075, tessellation: 64 }, scene);
  orientationRing.parent = root; orientationRing.position.y = 0.34; orientationRing.rotation.x = Math.PI / 2; orientationRing.material = materials.signal; orientationRing.isPickable = false;

  const motherboardRoot = new TransformNode('w755-motherboard-floor-root', scene);
  motherboardRoot.parent = root;
  const centralSocket = MeshBuilder.CreateCylinder('w755-living-nexus-processor-socket', { diameter: environmentPlan.floor.centralSocket.radius * 2, height: 0.12, tessellation: 64 }, scene);
  centralSocket.parent = motherboardRoot; centralSocket.position.set(environmentPlan.floor.centralSocket.x, environmentPlan.floor.centralSocket.y, environmentPlan.floor.centralSocket.z); centralSocket.material = materials.secondaryBase; centralSocket.isPickable = false;
  centralSocket.metadata = freeze({ kind: 'w755-central-processor-socket', connectedStationCount: environmentPlan.floor.stationSocketCount, localOnly: true });
  const stationSockets = [];
  const stationSocketHalos = [];
  for (const socket of environmentPlan.floor.sockets) {
    const pad = MeshBuilder.CreateCylinder(`w755-${socket.stationId}-chip-socket`, { diameter: socket.radius * 2, height: 0.09, tessellation: 40 }, scene);
    pad.parent = motherboardRoot; pad.position.set(socket.position.x, socket.position.y, socket.position.z); pad.material = materials.stationBase; pad.isPickable = false;
    pad.metadata = freeze({ kind: 'w755-station-chip-socket', stationId: socket.stationId, address: socket.address, unique: true, interactive: false });
    stationSockets.push(pad);
    const halo = MeshBuilder.CreateTorus(`w760-${socket.stationId}-socket-halo`, { diameter: socket.radius * 2.38, thickness: 0.035, tessellation: 44 }, scene);
    halo.parent = motherboardRoot; halo.position.set(socket.position.x, socket.position.y + 0.065, socket.position.z); halo.rotation.x = Math.PI / 2; halo.material = stationAccentMaterial(getEonCityW731Station(socket.stationId), materials); halo.isPickable = false;
    halo.metadata = freeze({ kind: 'w760-station-socket-halo', stationId: socket.stationId, motherboardConnection: true, interactive: false });
    stationSocketHalos.push(halo);
  }

  for (const station of EON_CITY_W731_STATIONS) createPath(scene, root, { x: 0, z: 1 }, station.position, materials.lane, station.id);
  for (const discovery of EON_CITY_W737_DISCOVERIES) createPath(scene, root, { x: Math.sign(discovery.position.x) * 9, z: Math.sign(discovery.position.z) * 9 }, discovery.position, materials.secondaryBase, `discovery-${discovery.id}`);

  const stations = new Map(EON_CITY_W731_STATIONS.map((station) => [station.id, createStation(scene, root, station, materials)]));
  const discoveries = new Map(EON_CITY_W737_DISCOVERIES.map((entry) => [entry.id, createDiscovery(scene, root, entry, materials)]));
  architecture.environmentAnchors.set('living-nexus-core', stations.get('eonbot-nexus').root);

  const dock = MeshBuilder.CreateCylinder('w737-eonbot-dock-fallback', { diameter: 1.55, height: 0.16, tessellation: 30 }, scene);
  dock.parent = root; dock.position.set(EON_CITY_W731_EONBOT_DOCK.x, 0.09, EON_CITY_W731_EONBOT_DOCK.z); dock.material = materials.glass; dock.isPickable = true;
  dock.metadata = stationMetadata(getEonCityW731Station('eonbot-nexus'), {
    part: 'structure', interactionRole: 'structure', dock: true, authored: false,
    accessibilityLabel: 'Open the Living EONBOT Nexus from its dock'
  });

  for (let index = 0; index < 48; index += 1) {
    const angle = (index / 48) * TAU;
    const radius = EON_CITY_W731_WORLD_BOUNDS.playableRadius - 0.4;
    const segment = MeshBuilder.CreateBox(`w737-boundary-${index}`, { width: 3.15, height: 0.42, depth: 0.32 }, scene);
    segment.parent = root;
    segment.position.set(Math.sin(angle) * radius, 0.21, Math.cos(angle) * radius);
    segment.rotation.y = angle;
    segment.material = index % 6 === 0 ? materials.warm : materials.structure;
    segment.isPickable = false;
    segment.metadata = freeze({ kind: 'w737-complete-playable-boundary', reachableBeyond: false });
  }
  for (const gateway of EON_CITY_W731_FUTURE_GATEWAYS) createFutureGateway(scene, root, gateway, materials);

  const glassWallRoot = new TransformNode('w755-glass-wall-root', scene);
  glassWallRoot.parent = root;
  const glassSegments = [];
  for (let index = 0; index < environmentPlan.materials.glassStructuralSections; index += 1) {
    const angle = (index / environmentPlan.materials.glassStructuralSections) * TAU;
    const segment = MeshBuilder.CreateBox(`w755-glass-wall-${index}`, { width: 5.4, height: 5.2, depth: 0.1 }, scene);
    segment.parent = glassWallRoot; segment.position.set(Math.sin(angle) * 25.6, 3.1, Math.cos(angle) * 25.6); segment.rotation.y = angle; segment.material = materials.glass; segment.isPickable = false;
    segment.metadata = freeze({ kind: 'w755-translucent-structure', openCanopy: true, blocksNavigation: false });
    glassSegments.push(segment);
  }
  const megaScreens = [];
  for (let index = 0; index < environmentPlan.materials.megaScreens; index += 1) {
    const angle = (index / environmentPlan.materials.megaScreens) * TAU + 0.35;
    const screen = MeshBuilder.CreateBox(`w755-mega-screen-${index}`, { width: 4.2, height: 1.8, depth: 0.08 }, scene);
    screen.parent = glassWallRoot; screen.position.set(Math.sin(angle) * 24.8, 4.7, Math.cos(angle) * 24.8); screen.rotation.y = angle; screen.material = index % 2 ? materials.cyan : materials.violet; screen.isPickable = false;
    screen.metadata = freeze({ kind: 'w755-command-mega-screen', privateData: false, decorativeProjection: true });
    megaScreens.push(screen);
  }

  const skylineRoot = new TransformNode('w755-skyline-near-mid-far-root', scene);
  skylineRoot.parent = root;
  const skylineTowers = [];
  const skylineFacadeBands = [];
  const skylineWindowRows = [];
  const skylineCrowns = [];
  for (const tier of environmentPlan.skyline.tiers) {
    for (let index = 0; index < tier.count; index += 1) {
      const fraction = index / Math.max(1, tier.count);
      const angle = fraction * TAU + (tier.id === 'mid' ? 0.037 : tier.id === 'far' ? 0.073 : 0);
      const radiusSpan = tier.radiusMax - tier.radiusMin;
      const radius = tier.radiusMin + ((index * 7) % Math.max(1, tier.count)) / Math.max(1, tier.count - 1) * radiusSpan;
      const height = tier.heightMin + ((index * 5) % 11) / 10 * (tier.heightMax - tier.heightMin);
      const width = tier.id === 'near' ? 2.6 + (index % 4) * 0.55 : tier.id === 'mid' ? 2.1 + (index % 3) * 0.5 : 1.8 + (index % 3) * 0.42;
      const tower = MeshBuilder.CreateBox(`w755-skyline-${tier.id}-${index}`, { width, depth: width, height }, scene);
      const skylineMaterial = tier.id === 'near' ? materials.skylineNear : tier.id === 'mid' ? materials.skylineMid : materials.skylineFar;
      tower.parent = skylineRoot; tower.position.set(Math.sin(angle) * radius, height / 2 - 0.1, Math.cos(angle) * radius); tower.rotation.y = -angle + (index % 2 ? 0.14 : -0.12); tower.material = (index + tier.count) % 7 === 0 ? materials.secondaryBase : skylineMaterial; tower.isPickable = false;
      tower.metadata = freeze({ kind: 'w755-nonplayable-skyline', tier: tier.id, outsidePlayableBoundary: true, sameOriginOnly: true, silhouetteStyle: 'w759r3-layered-crown-and-light' });
      skylineTowers.push(tower);
      const rowCount = tier.id === 'near' ? sceneConvergence.skyline.nearWindowRows : tier.id === 'mid' ? sceneConvergence.skyline.midWindowRows : sceneConvergence.skyline.farWindowRows;
      for (let row = 0; row < rowCount; row += 1) {
        const windowRow = MeshBuilder.CreateBox(`w760-skyline-window-row-${tier.id}-${index}-${row}`, { width: width * (0.54 + (row % 2) * 0.1), height: Math.max(0.12, height * 0.025), depth: 0.045 }, scene);
        windowRow.parent = tower;
        windowRow.position.set((row % 2 ? -1 : 1) * width * 0.055, -height * 0.31 + (row + 1) * (height * 0.62 / (rowCount + 1)), -width / 2 - 0.032);
        windowRow.material = (index + row) % 3 === 0 ? materials.skylineAccent : materials.windows;
        windowRow.isPickable = false;
        windowRow.metadata = freeze({ kind: 'w760-skyline-window-row', tier: tier.id, controlledEmission: true, interactive: false });
        skylineWindowRows.push(freeze({ node: windowRow, phase: index * 0.31 + row * 0.77, tier: tier.id }));
      }
      for (const [bandIndex, fraction] of sceneConvergence.skyline.facadeBandFractions.entries()) {
        if (tier.id === 'far' && bandIndex > 1) break;
        const band = MeshBuilder.CreateBox(`w760-skyline-facade-band-${tier.id}-${index}-${bandIndex}`, { width: width * 1.03, height: 0.055, depth: width * 1.03 }, scene);
        band.parent = tower; band.position.y = -height / 2 + height * fraction; band.material = bandIndex % 2 ? materials.skylineGlass : materials.skylineRoof; band.isPickable = false;
        band.metadata = freeze({ kind: 'w760-layered-facade-band', tier: tier.id, architecturalLayer: bandIndex + 1, interactive: false });
        skylineFacadeBands.push(band);
      }
      if (tier.id !== 'far' && index % 4 === 0) {
        const lightStrip = MeshBuilder.CreateBox(`w759r3-skyline-light-strip-${tier.id}-${index}`, { width: 0.075, height: Math.max(1.15, height * 0.48), depth: 0.045 }, scene);
        lightStrip.parent = tower; lightStrip.position.set(width * 0.29, height * 0.02, -width / 2 - 0.035); lightStrip.material = materials.skylineAccent; lightStrip.isPickable = false;
      }
      if (tier.id === 'near' && index % sceneConvergence.skyline.crownEvery === 0) {
        const crown = MeshBuilder.CreateCylinder(`w759r3-skyline-crown-w760-skyline-crown-${index}`, { diameterTop: width * 0.38, diameterBottom: width * 0.78, height: 0.42 + (index % 3) * 0.1, tessellation: 8 }, scene);
        crown.parent = tower; crown.position.y = height / 2 + 0.21; crown.material = index % 2 ? materials.skylineRoof : materials.skylineAccent; crown.isPickable = false;
        crown.metadata = freeze({ kind: 'w760-architectural-crown', tier: tier.id, silhouette: 'tapered', interactive: false });
        skylineCrowns.push(crown);
      }
      if (tier.id !== 'far' && index % sceneConvergence.skyline.spireEvery === 0) {
        const spire = MeshBuilder.CreateCylinder(`w760-skyline-spire-${tier.id}-${index}`, { diameterTop: 0.025, diameterBottom: 0.13, height: 1.2 + (index % 4) * 0.28, tessellation: 10 }, scene);
        spire.parent = tower; spire.position.y = height / 2 + 0.7; spire.material = materials.skylineAccent; spire.isPickable = false;
        spire.metadata = freeze({ kind: 'w760-architectural-spire', tier: tier.id, interactive: false });
        skylineCrowns.push(spire);
      }
    }
  }

  const skylineTransitRoot = new TransformNode('w760-distant-transit-root', scene);
  skylineTransitRoot.parent = root;
  const skylineTransit = [];
  for (let index = 0; index < sceneConvergence.skyline.transitCount; index += 1) {
    const capsule = MeshBuilder.CreateCapsule(`w760-distant-transit-${index}`, { height: 0.62, radius: 0.09, tessellation: 10, subdivisions: 1 }, scene);
    capsule.parent = skylineTransitRoot; capsule.material = index % 2 ? materials.warm : materials.skylineAccent; capsule.isPickable = false;
    capsule.rotation.z = Math.PI / 2;
    capsule.metadata = freeze({ kind: 'w760-distant-transit', ambientOnly: true, passengerTravel: false, interactive: false });
    skylineTransit.push(freeze({ node: capsule, radius: 29 + index * 5.5, height: 5.6 + index * 1.3, speed: 0.035 + index * 0.009, phase: index * 2.14 }));
  }

  const weatherRoot = new TransformNode('w755-weather-root', scene); weatherRoot.parent = root;
  const rainRoot = new TransformNode('w755-rain-root', scene); rainRoot.parent = weatherRoot;
  const rainDrops = [];
  for (let index = 0; index < environmentPlan.weather.particleCount; index += 1) {
    const drop = MeshBuilder.CreateBox(`w755-rain-${index}`, { width: 0.018, height: 0.65, depth: 0.018 }, scene);
    drop.parent = rainRoot; drop.position.set(((index * 13) % 41) - 20, 2.5 + ((index * 17) % 12), ((index * 19) % 41) - 20); drop.material = materials.cyan; drop.isPickable = false;
    drop.metadata = freeze({ kind: 'w755-local-rain-cue', realWeather: false, readableControls: true });
    rainDrops.push(drop);
  }
  rainRoot.setEnabled(environmentPlan.weather.particleCount > 0);
  const mistRoot = new TransformNode('w755-mist-root', scene); mistRoot.parent = weatherRoot;
  for (let index = 0; index < 5; index += 1) {
    const mist = MeshBuilder.CreateTorus(`w755-mist-band-${index}`, { diameter: 18 + index * 7, thickness: 0.08, tessellation: 72 }, scene);
    mist.parent = mistRoot; mist.position.y = 0.35 + index * 0.12; mist.rotation.x = Math.PI / 2; mist.material = materials.glass; mist.isPickable = false;
  }
  mistRoot.setEnabled(environmentPlan.weatherProfile === 'mist');
  const puddles = [];
  for (let index = 0; index < Math.max(12, environmentPlan.weather.puddleCueCount); index += 1) {
    const angle = (index / 12) * TAU;
    const puddle = MeshBuilder.CreateDisc(`w755-puddle-${index}`, { radius: 0.55 + (index % 3) * 0.14, tessellation: 28 }, scene);
    puddle.parent = weatherRoot; puddle.position.set(Math.sin(angle) * (10 + index % 4), 0.018, Math.cos(angle) * (10 + index % 4)); puddle.rotation.x = Math.PI / 2; puddle.material = materials.glass; puddle.isPickable = false;
    puddle.setEnabled(index < environmentPlan.weather.puddleCueCount); puddles.push(puddle);
  }

  const convergenceReactionRoot = new TransformNode('w762-w764-convergence-reaction-root', scene);
  convergenceReactionRoot.parent = root;
  convergenceReactionRoot.position.set(0, 0.18, 0);
  const nexusReactionRings = [];
  for (let index = 0; index < 3; index += 1) {
    const ring = MeshBuilder.CreateTorus(`w762-nexus-reaction-ring-${index}`, { diameter: 4.1 + index * 0.72, thickness: 0.045 + index * 0.012, tessellation: 72 }, scene);
    ring.parent = convergenceReactionRoot; ring.position.y = 0.12 + index * 0.08; ring.rotation.x = Math.PI / 2; ring.material = index === 1 ? materials.warm : materials.signal; ring.isPickable = false; ring.setEnabled(false);
    ring.metadata = freeze({ kind: 'w762-actual-nexus-state-reaction', index, sourceAuthority: 'w749', inventedActivity: false, interactive: false });
    nexusReactionRings.push(ring);
  }
  const rewardBurstNodes = [];
  for (let index = 0; index < 14; index += 1) {
    const spark = MeshBuilder.CreateSphere(`w764-reward-burst-${index}`, { diameter: 0.11 + (index % 3) * 0.025, segments: 8 }, scene);
    spark.parent = convergenceReactionRoot; spark.position.y = 1.2; spark.material = index % 3 === 0 ? materials.warm : index % 3 === 1 ? materials.signal : materials.rewardPulse; spark.isPickable = false; spark.setEnabled(false);
    spark.metadata = freeze({ kind: 'w764-verified-mission-reward-reaction', index, sourceAuthority: 'w752', deterministic: true, interactive: false });
    rewardBurstNodes.push(spark);
  }

  return freeze({
    root, materials: freeze(materials), stations, discoveries,
    environmentAnchors: architecture.environmentAnchors,
    dock, orientationRing, commandTable: architecture.commandTable, commandTableGlass: architecture.tableGlass, canopy: architecture.canopy, commandColumns: architecture.columns,
    circuitRoot: architecture.circuitRoot, circuitNodeCount: architecture.circuitNodeCount, circuitPulses: architecture.circuitPulses, commandLights: architecture.commandLights,
    ambientCitizens, ambientActors, exteriorMap,
    environment: freeze({ plan: environmentPlan, convergence: sceneConvergence, motherboardRoot, centralSocket, stationSockets: freeze(stationSockets), stationSocketHalos: freeze(stationSocketHalos), glassSegments: freeze(glassSegments), megaScreens: freeze(megaScreens), skylineRoot, skylineTowers: freeze(skylineTowers), skylineFacadeBands: freeze(skylineFacadeBands), skylineWindowRows: freeze(skylineWindowRows), skylineCrowns: freeze(skylineCrowns), skylineTransitRoot, skylineTransit: freeze(skylineTransit), weather: freeze({ weatherRoot, rainRoot, rainDrops: freeze(rainDrops), mistRoot, puddles: freeze(puddles) }), reactions: freeze({ root: convergenceReactionRoot, nexusRings: freeze(nexusReactionRings), rewardBurstNodes: freeze(rewardBurstNodes) }) })
  });
}

function createCommandHubUi(productRoot, stations, discoveries, {
  onOpenStation, onGuideStation, onFocusMonitors, onInspectDiscovery, onGuideDiscovery, onInspectInteraction,
  onResume, onReset, onRestart, onOpenCapture, onOpenShare, onOpenNexus, onClaimMission, onOpenReveal, onMenuOpen, getMissionView, getInteraction
} = {}) {
  const session = productRoot?.querySelector?.('.eon-play-session') || productRoot;
  if (!session?.append) return freeze({ update() {}, setPrompt() {}, updateMissions() {}, showReaction() {}, setPaused() {}, dispose() {} });
  try { session.__eonCityCommandHubUi?.dispose?.(); } catch {}
  session.dataset.eonCityCommandHub = 'w737';
  productRoot.dataset.eonCityRuntimeOwner = EON_CITY_W731_RUNTIME_OWNER_SCHEMA;
  productRoot.dataset.eonCityLaunchModel = 'command-centre-exterior-map';
  productRoot.dataset.eonCityOpenWorld = 'bounded-exterior';

  const labels = document.createElement('div');
  labels.className = 'eon-city-command-labels';
  labels.dataset.eonCityCommandLabels = '1';
  labels.setAttribute('aria-label', 'Command Centre destination markers');
  const labelRecords = [];
  const addLabel = (entity, kind) => {
    const button = document.createElement('button');
    button.type = 'button';
    // Inline fail-safe: global application themes must never turn these
    // spatial labels into native white browser buttons before City CSS loads.
    button.style.setProperty('-webkit-appearance', 'none', 'important');
    button.style.setProperty('appearance', 'none', 'important');
    button.style.setProperty('border', '1px solid rgba(104,235,224,.58)', 'important');
    button.style.setProperty('border-radius', '.7rem', 'important');
    button.style.setProperty('background', 'linear-gradient(145deg,rgba(4,18,28,.96),rgba(10,28,31,.94))', 'important');
    button.style.setProperty('color', '#f2feff', 'important');
    button.style.setProperty('box-shadow', '0 .62rem 1.5rem rgba(0,0,0,.46),inset 0 0 0 1px rgba(255,255,255,.035)', 'important');
    button.dataset.eonCityLabelKind = kind;
    button.dataset.eonCityLabelId = entity.id;
    if (kind === 'station') button.dataset.eonCityStationLabel = entity.id;
    else button.dataset.eonCityDiscoveryLabel = entity.id;
    button.setAttribute('aria-label', kind === 'station' ? `Open ${entity.label}` : `Inspect ${entity.label}`);
    button.innerHTML = `<strong>${safeText(entity.shortLabel || entity.label)}</strong>`;
    button.addEventListener('click', () => kind === 'station' ? onOpenStation?.(entity.id, button) : onInspectDiscovery?.(entity.id, button));
    labels.append(button);
    labelRecords.push({ button, entity, kind });
  };
  for (const station of EON_CITY_W731_STATIONS) addLabel(station, 'station');
  for (const discovery of EON_CITY_W737_DISCOVERIES) addLabel(discovery, 'discovery');

  const prompt = document.createElement('section');
  prompt.className = 'eon-city-command-prompt';
  prompt.dataset.eonCityCommandPrompt = '1';
  prompt.hidden = true;
  prompt.setAttribute('aria-live', 'polite');
  prompt.innerHTML = `<div><p data-eon-city-command-prompt-role></p><strong data-eon-city-command-prompt-title></strong><span data-eon-city-command-prompt-greeting></span></div><div class="eon-city-command-prompt-actions"><button type="button" data-eon-city-command-open></button><button type="button" data-eon-city-command-inspect>Inspect</button><button type="button" data-eon-city-command-capture hidden>Record City</button><kbd>E</kbd></div>`;
  let promptTarget = null;
  prompt.querySelector('[data-eon-city-command-open]')?.addEventListener('click', (event) => {
    if (!promptTarget) return;
    if (promptTarget.kind === 'station') onOpenStation?.(promptTarget.entity.id, event.currentTarget);
    else onInspectDiscovery?.(promptTarget.entity.id, event.currentTarget);
  });
  prompt.querySelector('[data-eon-city-command-inspect]')?.addEventListener('click', (event) => {
    if (!promptTarget) return;
    const interaction = typeof getInteraction === 'function' ? getInteraction(promptTarget) : null;
    onInspectInteraction?.(interaction, promptTarget, event.currentTarget);
  });
  prompt.querySelector('[data-eon-city-command-capture]')?.addEventListener('click', (event) => onOpenCapture?.(event.currentTarget));

  const feedback = document.createElement('section');
  feedback.className = 'eon-city-command-feedback';
  feedback.dataset.eonCityCommandFeedback = '1';
  feedback.hidden = true;
  feedback.setAttribute('role', 'status');
  feedback.setAttribute('aria-live', 'polite');
  feedback.innerHTML = '<small data-eon-city-feedback-kicker>Command Core</small><strong data-eon-city-feedback-title></strong><span data-eon-city-feedback-detail></span>';
  let feedbackTimer = null;
  const showReaction = (reaction = {}) => {
    if (!reaction?.label) return false;
    if (feedbackTimer !== null) globalThis.clearTimeout?.(feedbackTimer);
    feedback.dataset.kind = String(reaction.kind || 'status');
    feedback.querySelector('[data-eon-city-feedback-kicker]').textContent = reaction.kind === 'mission-complete' ? 'Mission verified' : reaction.kind === 'vault-reveal' ? 'Vault Reveal' : 'Living Nexus';
    feedback.querySelector('[data-eon-city-feedback-title]').textContent = String(reaction.label || 'Command Core updated');
    const detail = reaction.awardedXp ? `+${Number(reaction.awardedXp)} City XP${reaction.revealProgress ? ` · +${Number(reaction.revealProgress)} Reveal progress` : ''}` : reaction.ringId ? `${String(reaction.ringId)} ring · actual projected state` : 'Verified local update';
    feedback.querySelector('[data-eon-city-feedback-detail]').textContent = detail;
    feedback.hidden = false;
    feedback.removeAttribute('hidden');
    feedbackTimer = globalThis.setTimeout?.(() => { feedback.hidden = true; feedback.setAttribute('hidden', ''); feedbackTimer = null; }, Math.max(1800, Math.min(6000, Number(reaction.durationMs || 3600)))) ?? null;
    return true;
  };
  const markButtonResponse = (button, label = 'Opening') => {
    if (!button) return;
    button.dataset.eonCityActionState = 'responding';
    button.setAttribute('aria-busy', 'true');
    button.dataset.eonCityActionLabel = String(label || 'Opening').slice(0, 64);
    globalThis.setTimeout?.(() => {
      if (!button?.isConnected) return;
      delete button.dataset.eonCityActionState;
      delete button.dataset.eonCityActionLabel;
      button.removeAttribute('aria-busy');
    }, 520);
  };
  session.append(labels, prompt, feedback);

  const makeLauncher = (label, datasetKey, ariaLabel = label) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset[datasetKey] = '1';
    button.textContent = label;
    button.setAttribute('aria-label', ariaLabel);
    return button;
  };
  const nexusLauncher = makeLauncher('Nexus', 'eonCityNexusOpen', 'Open Living EONBOT Nexus');
  const monitorsLauncher = makeLauncher('Live Monitors', 'eonCityMonitorsOpen', 'Go to the five live Command Centre monitors');
  const menuLauncher = makeLauncher('City Menu', 'eonCityMenuOpen');
  const shareLauncher = makeLauncher('Share', 'eonCityShareOpen', 'Open Share Command Center');
  for (const launcher of [nexusLauncher, monitorsLauncher, menuLauncher, shareLauncher]) launcher.dataset.eonCityRuntimeLauncher = 'w759r2';
  const actions = session.querySelector('.eon-city-reduced-actions,.eon-play-hud-actions');
  actions?.querySelectorAll?.('[data-eon-city-runtime-launcher]')?.forEach?.((node) => node.remove());
  actions?.prepend(nexusLauncher, monitorsLauncher, menuLauncher, shareLauncher);

  // A fixed menu must live under body. Keeping it inside the canvas session
  // allowed ancestor overflow/stacking contexts to swallow real browser clicks.
  document.querySelectorAll('body > [data-eon-city-command-menu]').forEach((node) => node.remove());
  const menu = document.createElement('section');
  menu.className = 'eon-city-command-menu';
  menu.dataset.eonCityCommandMenu = '1';
  menu.dataset.eonCityRuntimeOwner = 'w737';
  menu.hidden = true;
  menu.setAttribute('role', 'dialog');
  menu.setAttribute('aria-modal', 'true');
  menu.setAttribute('aria-hidden', 'true');
  menu.setAttribute('aria-labelledby', 'eon-city-command-menu-title');
  const stationCards = EON_CITY_W731_STATIONS.map((station) => `<article data-eon-city-menu-station="${safeText(station.id)}"><div><small>${station.zone === 'command-centre' ? 'Command Centre' : 'Exterior destination'}</small><strong>${safeText(station.label)}</strong><p>${safeText(station.description)}</p></div><div><button type="button" data-eon-city-menu-guide="${safeText(station.id)}">Go there</button><button type="button" data-eon-city-menu-open-surface="${safeText(station.id)}">Open</button></div></article>`).join('');
  menu.innerHTML = `<div class="eon-city-command-menu-card"><header><div><p>Living Command Centre</p><h2 id="eon-city-command-menu-title">Choose work, a mission or an outside-map discovery</h2><span>One City runtime. Every productive destination opens its maintained EONAPP workspace.</span></div><button type="button" data-eon-city-menu-close aria-label="Close City Menu">×</button></header><nav class="eon-city-command-menu-quick" aria-label="Core City actions" data-eon-city-menu-order="${safeText(EON_CITY_W763_MENU_ORDER.join('|'))}"><button type="button" data-eon-city-quick="nexus">Living Nexus</button><button type="button" data-eon-city-quick="missions">Missions &amp; XP</button><button type="button" data-eon-city-quick="monitors">Live Monitors</button><button type="button" data-eon-city-quick="share">Share Command Center</button><button type="button" data-eon-city-quick="capture">Creator Capture</button><button type="button" data-eon-city-quick="plans">Plans &amp; Access</button><button type="button" data-eon-city-quick="atlas">Atlas</button></nav><section class="eon-city-command-menu-featured" aria-label="Share and membership"><article data-eon-city-featured="share"><div><small>Grow EON City · review first</small><strong>Share Command Center</strong><p>Create a signed invite, QR or social handoff. Creator Capture records gameplay locally and adds the referral-ready City link only after review.</p></div><div><button type="button" data-eon-city-menu-open-share>Open Share Center</button><button type="button" data-eon-city-menu-open-capture>Creator Capture</button></div></article><article data-eon-city-featured="plans" data-eon-city-contextual-promotion="subscription"><div><small>Membership · never an ad</small><strong>Plans &amp; Access</strong><p>Review current server-confirmed access and compare tiers when useful. This card never interrupts gameplay or starts checkout.</p></div><div><button type="button" data-eon-city-menu-open-plans>Review plans</button></div></article></section><div class="eon-city-command-menu-body"><aside class="eon-city-command-missions"><div><small>Productive missions</small><h3>Explore with a real outcome</h3><p data-eon-city-mission-summary></p><button type="button" data-eon-city-menu-open-reveal hidden>Open deterministic Vault Reveal</button></div><div data-eon-city-mission-list></div></aside><div class="eon-city-command-menu-grid">${stationCards}</div></div><footer><button type="button" data-eon-city-menu-resume>Resume location</button><button type="button" data-eon-city-menu-reset>Orientation Core</button><button type="button" data-eon-city-menu-restart>Restart 3D</button><span>The outside map is bounded. Expanse entry remains review-first.</span></footer></div>`;
  document.body.append(menu);

  let lastFocus = null;
  const menuFocusable = () => [...menu.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')];
  const renderMissions = () => {
    const list = menu.querySelector('[data-eon-city-mission-list]');
    const summary = menu.querySelector('[data-eon-city-mission-summary]');
    const revealButton = menu.querySelector('[data-eon-city-menu-open-reveal]');
    if (!list) return;
    const missionView = typeof getMissionView === 'function' ? getMissionView() : {};
    const missions = Array.isArray(missionView?.missions) ? missionView.missions : Array.isArray(missionView) ? missionView : [];
    if (summary) summary.textContent = `${Number(missionView?.xp || 0)} City XP · ${Number(missionView?.claimedCount || 0)} claimed · ${Number(missionView?.claimableCount || 0)} ready · ${Number(missionView?.pendingReveals || 0)} reveals`;
    if (revealButton) {
      revealButton.hidden = !(Number(missionView?.pendingReveals || 0) > 0 && missionView?.nextReveal);
      revealButton.textContent = missionView?.nextReveal ? `Reveal ${missionView.nextReveal.label}` : 'Open deterministic Vault Reveal';
    }
    list.innerHTML = missions.map((mission) => {
      const state = String(mission.state || mission.localState || 'available');
      const stateCopy = state === 'claimed' ? 'Verified mission claimed'
        : state === 'verified-ready' ? 'Genuine native receipt ready for explicit claim'
          : state === 'in-progress' ? 'Continue the maintained work surface and return with its native receipt'
            : state === 'blocked' ? 'Native proof is unavailable or cancelled'
              : 'Available';
      const guideLabel = mission.discoveryId && state === 'available' ? 'Find discovery' : (mission.actionLabel || 'Go to station');
      const claim = mission.claimable
        ? `<button type="button" data-eon-city-mission-claim="${safeText(mission.stationId)}">Claim +${Number(mission.xpReward || 0)} XP</button>`
        : mission.claimed ? '<button type="button" disabled>Claimed</button>' : '';
      return `<article data-eon-city-mission="${safeText(mission.id)}" data-state="${safeText(state)}"><div><span>${safeText(mission.category || 'Productive')}</span><strong>${safeText(mission.title)}</strong><p>${safeText(mission.summary)}</p><small>${safeText(stateCopy)}</small></div><div><button type="button" data-eon-city-mission-guide="${safeText(mission.id)}">${safeText(guideLabel)}</button>${claim}</div></article>`;
    }).join('');
  };
  const openMenu = (trigger = menuLauncher) => {
    if (!menu.isConnected || !menu.hidden) return false;
    lastFocus = trigger;
    renderMissions();
    menu.hidden = false;
    menu.removeAttribute('hidden');
    menu.setAttribute('aria-hidden', 'false');
    menu.style.display = 'grid';
    document.body.classList.add('eon-city-command-menu-body-open');
    session.classList.add('eon-city-command-menu-open');
    onMenuOpen?.();
    labels.hidden = true;
    menuLauncher.setAttribute('aria-expanded', 'true');
    globalThis.requestAnimationFrame?.(() => menu.querySelector('[data-eon-city-menu-close]')?.focus?.({ preventScroll: true }));
    return true;
  };
  const closeMenu = () => {
    if (menu.hidden) return false;
    menu.hidden = true;
    menu.setAttribute('hidden', '');
    menu.setAttribute('aria-hidden', 'true');
    menu.style.display = 'none';
    document.body.classList.remove('eon-city-command-menu-body-open');
    session.classList.remove('eon-city-command-menu-open');
    labels.hidden = false;
    menuLauncher.setAttribute('aria-expanded', 'false');
    if (lastFocus?.isConnected) lastFocus.focus?.({ preventScroll: true });
    else menuLauncher.focus?.({ preventScroll: true });
    lastFocus = null;
    return true;
  };
  menuLauncher.setAttribute('aria-haspopup', 'dialog');
  menuLauncher.setAttribute('aria-expanded', 'false');
  nexusLauncher.addEventListener('click', (event) => { markButtonResponse(event.currentTarget, 'Opening Nexus'); onOpenNexus?.(event.currentTarget); });
  monitorsLauncher.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    markButtonResponse(event.currentTarget, 'Focusing Command Wall');
    onFocusMonitors?.(event.currentTarget);
  });
  menuLauncher.addEventListener('click', (event) => { event.preventDefault(); event.stopPropagation(); markButtonResponse(event.currentTarget, 'Opening City Menu'); openMenu(event.currentTarget); });
  shareLauncher.addEventListener('click', (event) => { markButtonResponse(event.currentTarget, 'Opening Share Center'); onOpenShare?.(event.currentTarget); });
  menu.querySelector('[data-eon-city-menu-close]')?.addEventListener('click', closeMenu);
  menu.querySelector('[data-eon-city-menu-resume]')?.addEventListener('click', () => { closeMenu(); onResume?.(); });
  menu.querySelector('[data-eon-city-menu-reset]')?.addEventListener('click', () => { closeMenu(); onReset?.(); });
  menu.querySelector('[data-eon-city-menu-restart]')?.addEventListener('click', () => { closeMenu(); onRestart?.(); });
  menu.addEventListener('pointerdown', (event) => event.stopPropagation());
  menu.addEventListener('click', (event) => {
    if (event.target === menu) { closeMenu(); return; }
    const actionButton = event.target.closest('button');
    if (actionButton && !actionButton.disabled) markButtonResponse(actionButton, actionButton.textContent || 'Opening');
    const quick = event.target.closest('[data-eon-city-quick]');
    if (quick) {
      const action = String(quick.dataset.eonCityQuick || '');
      if (action === 'missions') { menu.querySelector('.eon-city-command-missions')?.scrollIntoView?.({ block: 'start', behavior: 'smooth' }); return; }
      closeMenu();
      if (action === 'nexus') onOpenNexus?.(quick);
      else if (action === 'monitors') onFocusMonitors?.(quick);
      else if (action === 'share') onOpenShare?.(quick);
      else if (action === 'capture') onOpenCapture?.(quick);
      else if (action === 'plans') onOpenStation?.('plans-access', quick, 'plans');
      else if (action === 'atlas') onOpenStation?.('project-atlas', quick, 'projects');
      return;
    }
    const share = event.target.closest('[data-eon-city-menu-open-share]');
    if (share) { closeMenu(); onOpenShare?.(share); return; }
    const capture = event.target.closest('[data-eon-city-menu-open-capture]');
    if (capture) { closeMenu(); onOpenCapture?.(capture); return; }
    const plans = event.target.closest('[data-eon-city-menu-open-plans]');
    if (plans) { closeMenu(); onOpenStation?.('plans-access', plans, 'plans'); return; }
    const reveal = event.target.closest('[data-eon-city-menu-open-reveal]');
    if (reveal) { onOpenReveal?.(reveal); renderMissions(); return; }
    const claim = event.target.closest('[data-eon-city-mission-claim]');
    if (claim) { onClaimMission?.(String(claim.dataset.eonCityMissionClaim || ''), claim); renderMissions(); return; }
    const guide = event.target.closest('[data-eon-city-menu-guide]');
    if (guide) { closeMenu(); onGuideStation?.(guide.dataset.eonCityMenuGuide, guide); return; }
    const open = event.target.closest('[data-eon-city-menu-open-surface]');
    if (open) { closeMenu(); onOpenStation?.(open.dataset.eonCityMenuOpenSurface, open); return; }
    const mission = event.target.closest('[data-eon-city-mission-guide]');
    if (mission) {
      const missionView = typeof getMissionView === 'function' ? getMissionView() : {};
      const records = Array.isArray(missionView?.missions) ? missionView.missions : Array.isArray(missionView) ? missionView : [];
      const record = records.find((entry) => entry.id === mission.dataset.eonCityMissionGuide);
      if (!record) return;
      closeMenu();
      if (record.discoveryId && String(record.state || record.localState || 'available') === 'available') onGuideDiscovery?.(record.discoveryId, mission);
      else onGuideStation?.(record.stationId, mission);
    }
  });

  const onKeydown = (event) => {
    if (event.key === 'Tab' && !menu.hidden) {
      const focusable = menuFocusable();
      if (focusable.length) {
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    }
    if (event.key === 'Escape' && !menu.hidden) { event.preventDefault(); closeMenu(); }
    if ((event.key === 'm' || event.key === 'M') && menu.hidden && !event.ctrlKey && !event.metaKey && !event.altKey) {
      const tag = String(document.activeElement?.tagName || '').toLowerCase();
      if (!['input', 'textarea', 'select'].includes(tag) && !document.activeElement?.isContentEditable) { event.preventDefault(); openMenu(); }
    }
  };
  globalThis.addEventListener?.('keydown', onKeydown);

  const setPrompt = (target = null) => {
    const station = target?.station || null;
    const discovery = target?.discovery || null;
    const entity = station || discovery;
    promptTarget = entity ? { kind: station ? 'station' : 'discovery', entity } : null;
    prompt.hidden = !entity;
    if (!entity) return;
    const interaction = typeof getInteraction === 'function' ? getInteraction(promptTarget) : null;
    prompt.dataset.eonCityInteractionId = interaction?.id || '';
    prompt.querySelector('[data-eon-city-command-prompt-role]').textContent = `${entity.npc.name} · ${entity.npc.role}`;
    prompt.querySelector('[data-eon-city-command-prompt-title]').textContent = interaction?.label || entity.label;
    prompt.querySelector('[data-eon-city-command-prompt-greeting]').textContent = interaction?.oneLinePurpose || entity.npc.greeting;
    prompt.querySelector('[data-eon-city-command-open]').textContent = interaction?.primaryAction?.label || entity.npc.action || (station ? 'Open' : 'Inspect');
    prompt.querySelector('[data-eon-city-command-inspect]').textContent = interaction?.secondaryAction?.label || 'Inspect';
    const capture = prompt.querySelector('[data-eon-city-command-capture]');
    capture.hidden = station?.id !== 'share-capture';
  };

  let lastLabelProjectionAt = -Infinity;
  let lastLabelNearestTargetId = '';
  const update = (projector, playerPosition, nearestTargetId = '', at = now()) => {
    if (!menu.hidden || session.dataset.eonCityWorkSurfaceOpen === 'true') {
      for (const record of labelRecords) record.button.hidden = true;
      return;
    }
    const timestamp = Number(at) || now();
    // Screen-space station labels are intentionally projected at ~11 Hz.
    // A nearest-target change bypasses the cadence so interaction feedback is
    // immediate, while normal camera/player motion avoids per-frame DOM work.
    if (nearestTargetId === lastLabelNearestTargetId && timestamp - lastLabelProjectionAt < 90) return;
    lastLabelProjectionAt = timestamp;
    lastLabelNearestTargetId = nearestTargetId;
    const width = Math.max(320, session.clientWidth || globalThis.innerWidth || 1280);
    const height = Math.max(240, session.clientHeight || globalThis.innerHeight || 720);
    const candidates = [];
    for (const record of labelRecords) {
      const projected = projector(record.entity, record.kind);
      const distance = Math.hypot(Number(playerPosition?.x || 0) - record.entity.position.x, Number(playerPosition?.z || 0) - record.entity.position.z);
      const representedByPrompt = promptTarget?.entity?.id === record.entity.id;
      if (!representedByPrompt && projected?.visible && distance < (record.kind === 'station' ? 18 : 15)) {
        const priority = record.entity.id === nearestTargetId ? -100 : record.entity.id === 'eonbot-nexus' ? -12 : record.kind === 'discovery' ? 4 : Number(record.entity.priority || 20);
        candidates.push({ ...record, projected, distance, score: priority + distance });
      }
      record.button.hidden = true;
    }
    candidates.sort((a, b) => a.score - b.score || a.projected.depth - b.projected.depth);
    const selected = candidates.slice(0, 8);
    const placed = [];
    const sessionRect = session.getBoundingClientRect?.() || { left: 0, top: 0 };
    const promptRect = prompt.hidden ? null : prompt.getBoundingClientRect?.();
    const blocked = promptRect ? [{
      left: promptRect.left - sessionRect.left - 10,
      right: promptRect.right - sessionRect.left + 10,
      top: promptRect.top - sessionRect.top - 10,
      bottom: promptRect.bottom - sessionRect.top + 10
    }] : [];
    const labelWidth = width <= 760 ? 122 : 156;
    const labelHeight = width <= 760 ? 42 : 50;
    const intersects = (rect, other) => !(rect.right < other.left || rect.left > other.right || rect.bottom < other.top || rect.top > other.bottom);
    const offsets = [[0, 0], [0, -58], [0, 58], [-166, 0], [166, 0], [-166, -58], [166, -58]];
    for (const candidate of selected) {
      if (placed.length >= 3) break;
      const baseX = Math.max(labelWidth / 2 + 10, Math.min(width - labelWidth / 2 - 10, candidate.projected.x));
      const baseY = Math.max(labelHeight + 16, Math.min(height - 78, candidate.projected.y));
      let placement = null;
      for (const [offsetX, offsetY] of offsets) {
        const x = Math.max(labelWidth / 2 + 10, Math.min(width - labelWidth / 2 - 10, baseX + offsetX));
        const y = Math.max(labelHeight + 16, Math.min(height - 78, baseY + offsetY));
        const rect = { left: x - labelWidth / 2, right: x + labelWidth / 2, top: y - labelHeight, bottom: y };
        if (![...placed, ...blocked].some((prior) => intersects(rect, prior))) { placement = { x, y, ...rect }; break; }
      }
      if (!placement) continue;
      candidate.button.hidden = false;
      candidate.button.style.transform = `translate3d(${Math.round(placement.x)}px,${Math.round(placement.y)}px,0) translate(-50%,-100%)`;
      candidate.button.style.setProperty('--eon-city-label-depth', String(candidate.projected.depth || 0));
      candidate.button.dataset.nearest = candidate.entity.id === nearestTargetId ? 'true' : 'false';
      candidate.button.dataset.distanceBand = candidate.distance < 7 ? 'near' : candidate.distance < 12 ? 'mid' : 'far';
      candidate.button.style.setProperty('--eon-city-label-opacity', candidate.entity.id === nearestTargetId ? '1' : candidate.distance < 7 ? '.94' : candidate.distance < 12 ? '.82' : '.68');
      placed.push(placement);
    }
    labels.dataset.visibleCount = String(placed.length);
  };

  const controller = freeze({
    update,
    setPrompt,
    updateMissions: renderMissions,
    showReaction,
    setPaused(paused) { session.dataset.eonCityWorkSurfaceOpen = paused ? 'true' : 'false'; },
    openMenu,
    closeMenu,
    isMenuOpen: () => !menu.hidden,
    getPromptTarget: () => promptTarget,
    dispose() {
      globalThis.removeEventListener?.('keydown', onKeydown);
      nexusLauncher.remove();
      monitorsLauncher.remove();
      menuLauncher.remove();
      shareLauncher.remove();
      if (feedbackTimer !== null) globalThis.clearTimeout?.(feedbackTimer);
      labels.remove();
      prompt.remove();
      feedback.remove();
      menu.remove();
      document.body.classList.remove('eon-city-command-menu-body-open');
      session.classList.remove('eon-city-command-menu-open');
      delete session.dataset.eonCityCommandHub;
      if (session.__eonCityCommandHubUi === controller) delete session.__eonCityCommandHubUi;
    }
  });
  session.__eonCityCommandHubUi = controller;
  return controller;
}

function readResume(storage = globalThis.localStorage) {
  try {
    const value = JSON.parse(storage?.getItem?.(EON_CITY_W731_RESUME_KEY) || 'null');
    if (!value || value.schema !== EON_CITY_W731_COMMAND_HUB_SCHEMA) return null;
    const safe = clampEonCityW731Position(value.player || {});
    return freeze({ player: safe, heading: Number(value.heading || 0), stationId: String(value.stationId || ''), savedAt: String(value.savedAt || '') });
  } catch { return null; }
}

function writeResume(player, heading, stationId = '', storage = globalThis.localStorage) {
  try {
    const safe = clampEonCityW731Position(player || {});
    storage?.setItem?.(EON_CITY_W731_RESUME_KEY, JSON.stringify({
      schema: EON_CITY_W731_COMMAND_HUB_SCHEMA,
      player: { x: safe.x, y: 0, z: safe.z },
      heading: Number(heading || 0), stationId: String(stationId || ''), savedAt: new Date().toISOString()
    }));
    return true;
  } catch { return false; }
}


function getEonCityW747NodeWorldBounds(node) {
  if (!node) return null;
  const candidates = [];
  if (node?.getBoundingInfo) candidates.push(node);
  for (const mesh of node?.getChildMeshes?.(false) || []) {
    if (mesh?.getBoundingInfo) candidates.push(mesh);
  }
  let min = new Vector3(Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY);
  let max = new Vector3(Number.NEGATIVE_INFINITY, Number.NEGATIVE_INFINITY, Number.NEGATIVE_INFINITY);
  for (const mesh of candidates) {
    try {
      mesh.computeWorldMatrix?.(true);
      const box = mesh.getBoundingInfo().boundingBox;
      min = Vector3.Minimize(min, box.minimumWorld);
      max = Vector3.Maximize(max, box.maximumWorld);
    } catch {}
  }
  if (![min.x, min.y, min.z, max.x, max.y, max.z].every(Number.isFinite)) return null;
  return freeze({
    min: freeze({ x: min.x, y: min.y, z: min.z }),
    max: freeze({ x: max.x, y: max.y, z: max.z })
  });
}

function createEonCityW747DiagnosticsOverlay(scene, parent, diagnostics) {
  const root = new TransformNode('w747-spatial-diagnostics-root', scene);
  root.parent = parent;
  root.metadata = freeze({ kind: 'w747-advanced-spatial-diagnostics', advancedOnly: true, ownerVisibleByDefault: false });
  const material = new StandardMaterial('w747-spatial-diagnostics-material', scene);
  material.diffuseColor = color('#5ce1d2');
  material.emissiveColor = color('#5ce1d2').scale(0.7);
  material.alpha = 0.7;
  material.wireframe = true;
  material.disableLighting = true;
  const fixedNodes = [];
  const heroRing = MeshBuilder.CreateTorus('w747-diagnostic-hero-zone', { diameter: EON_CITY_W747_HERO_ZONE.diameter, thickness: 0.08, tessellation: 72 }, scene);
  heroRing.parent = root;
  heroRing.position.y = 0.22;
  heroRing.rotation.x = Math.PI / 2;
  heroRing.material = material;
  heroRing.isPickable = false;
  fixedNodes.push(heroRing);
  const corridorLength = Math.hypot(
    EON_CITY_W747_ARRIVAL_CORRIDOR.to.x - EON_CITY_W747_ARRIVAL_CORRIDOR.from.x,
    EON_CITY_W747_ARRIVAL_CORRIDOR.to.z - EON_CITY_W747_ARRIVAL_CORRIDOR.from.z
  );
  const corridor = MeshBuilder.CreateBox('w747-diagnostic-arrival-corridor', {
    width: EON_CITY_W747_ARRIVAL_CORRIDOR.halfWidth * 2,
    height: 0.08,
    depth: corridorLength
  }, scene);
  corridor.parent = root;
  corridor.position.set(
    (EON_CITY_W747_ARRIVAL_CORRIDOR.from.x + EON_CITY_W747_ARRIVAL_CORRIDOR.to.x) / 2,
    0.18,
    (EON_CITY_W747_ARRIVAL_CORRIDOR.from.z + EON_CITY_W747_ARRIVAL_CORRIDOR.to.z) / 2
  );
  corridor.rotation.y = Math.atan2(
    EON_CITY_W747_ARRIVAL_CORRIDOR.to.x - EON_CITY_W747_ARRIVAL_CORRIDOR.from.x,
    EON_CITY_W747_ARRIVAL_CORRIDOR.to.z - EON_CITY_W747_ARRIVAL_CORRIDOR.from.z
  );
  corridor.material = material;
  corridor.isPickable = false;
  fixedNodes.push(corridor);
  for (const wing of EON_CITY_W747_FIVE_WING_ANCHORS) {
    const marker = MeshBuilder.CreateCylinder(`w747-diagnostic-wing-${wing.id}`, { diameter: 0.7, height: 0.12, tessellation: 20 }, scene);
    marker.parent = root;
    marker.position.set(wing.position.x, 0.24, wing.position.z);
    marker.material = material;
    marker.isPickable = false;
    marker.metadata = freeze({ kind: 'w747-wing-anchor', wingId: wing.id, label: wing.label });
    fixedNodes.push(marker);
  }
  let boundNodes = [];
  const rebuildBounds = () => {
    for (const node of boundNodes) { try { node.dispose?.(false, true); } catch {} }
    boundNodes = [];
    for (const entry of diagnostics.listLoadedBounds()) {
      const size = entry.bounds.size;
      if (![size.x, size.y, size.z].every(Number.isFinite)) continue;
      const box = MeshBuilder.CreateBox(`w747-diagnostic-bound-${entry.id}`, {
        width: Math.max(0.04, size.x), height: Math.max(0.04, size.y), depth: Math.max(0.04, size.z)
      }, scene);
      box.parent = root;
      box.position.set(entry.bounds.center.x, entry.bounds.center.y, entry.bounds.center.z);
      box.material = material;
      box.isPickable = false;
      box.metadata = freeze({ kind: 'w747-loaded-bound', assetId: entry.id, primaryRole: entry.primaryRole });
      boundNodes.push(box);
    }
  };
  root.setEnabled(false);
  return freeze({
    root,
    setVisible(visible) {
      const next = Boolean(visible);
      if (next) rebuildBounds();
      root.setEnabled(next);
      return next;
    },
    dispose() {
      for (const node of boundNodes) { try { node.dispose?.(false, true); } catch {} }
      for (const node of fixedNodes) { try { node.dispose?.(false, true); } catch {} }
      try { material.dispose?.(); } catch {}
      try { root.dispose?.(false, true); } catch {}
    }
  });
}

export function mountBabylonCityProof({
  host,
  quality = 'balanced',
  qualityAuthority = null,
  reducedMotion = false,
  onStatus = null,
  onTelemetry = null,
  onContextLoss = null,
  onContextRestored = null,
  onFirstFrame = null,
  onInitialAssetsReady = null,
  onAssetProgress = null,
  onDetailStage = null,
  onBootStage = null,
  onLandmarkChange = null,
  onInputModeChange = null,
  onPerformanceChange = null
} = {}) {
  const contractValidation = validateEonCityW731CommandHubContract();
  const assetValidation = validateEonCityW731LaunchAssetManifest();
  const missionValidation = validateEonCityW737MissionContract();
  const stationCompletionValidation = validateEonCityW744StationCompletion({ stations: EON_CITY_W731_STATIONS, launchManifest: EON_CITY_W731_LAUNCH_ASSET_MANIFEST });
  const productiveStationsValidation = validateEonCityW751ProductiveStations();
  const missionsProgressionValidation = validateEonCityW752MissionsProgression();
  const castTransitValidation = validateEonCityW754Contract();
  const arrivalCameraValidation = inspectEonCityW743ArrivalCamera();
  const spatialFoundationValidation = validateEonCityW747SpatialFoundation();
  const commandCoreConvergenceValidation = validateEonCityW760W765Convergence();
  if (!contractValidation.ok) throw new Error(`w731-command-hub-contract-invalid:${contractValidation.errors.join(',')}`);
  if (!assetValidation.ok) throw new Error(`w737-launch-assets-invalid:${assetValidation.errors.join(',')}`);
  if (!missionValidation.ok) throw new Error(`w737-missions-invalid:${missionValidation.errors.join(',')}`);
  if (!stationCompletionValidation.ok) throw new Error(`w744-station-completion-invalid:${stationCompletionValidation.errors.join(',')}`);
  if (!productiveStationsValidation.ok) throw new Error(`w751-productive-stations-invalid:${productiveStationsValidation.errors.join(',')}`);
  if (!missionsProgressionValidation.ok) throw new Error(`w752-missions-progression-invalid:${missionsProgressionValidation.errors.join(',')}`);
  if (!castTransitValidation.ok) throw new Error(`w754-cast-eonbot-npc-transit-invalid:${castTransitValidation.errors.join(',')}`);
  if (!arrivalCameraValidation.ok) throw new Error(`w743-arrival-camera-obstructed:${arrivalCameraValidation.blockedStationIds.join(',')}`);
  if (!spatialFoundationValidation.ok) throw new Error(`w747-spatial-foundation-invalid:${spatialFoundationValidation.errors.join(',')}`);
  if (!commandCoreConvergenceValidation.ok) throw new Error(`w760-w765-command-core-convergence-invalid:${commandCoreConvergenceValidation.errors.join(',')}`);
  if (EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame?.authoredEnvironmentRequired !== true) throw new Error('w737-authored-visible-frame-required');
  if (EON_CITY_W731_LAUNCH_ASSET_MANIFEST.cacheVersion !== EON_CITY_W757_RUNTIME_PROVENANCE) throw new Error('w757-city-runtime-provenance-mismatch');
  if (!host || typeof document === 'undefined') throw Object.assign(new Error('City canvas host is unavailable.'), { code: 'CITY_CANVAS_MOUNT_FAILED' });

  const startedAt = now();
  const productRoot = host.closest?.('[data-eon-city-play-root]') || host.parentElement || host;
  const stage = (name, detail = '') => { trace(host, startedAt, name, detail); try { onBootStage?.({ stage: name, detailCode: detail }); } catch {} };
  stage('BABYLON_CORE_IMPORT_FINISHED', EON_CITY_W731_RUNTIME_OWNER_SCHEMA);

  const resolvedQuality = ['lite', 'balanced', 'cinematic'].includes(String(quality || '').toLowerCase()) ? String(quality).toLowerCase() : 'balanced';
  const resolvedQualityAuthority = freeze({
    received: String(quality || ''),
    requested: qualityAuthority?.requested || null,
    effective: resolvedQuality,
    detected: String(qualityAuthority?.detected || resolvedQuality),
    source: String(qualityAuthority?.source || 'automatic'),
    overrideAllowed: qualityAuthority?.overrideAllowed === true,
    overrideAccepted: qualityAuthority?.overrideAccepted === true,
    rejectionReason: qualityAuthority?.rejectionReason || null,
    renderer: String(qualityAuthority?.renderer || '')
  });
  const w754CastPlan = buildEonCityW754CastPlan({ quality: resolvedQuality === 'cinematic' ? 'high' : resolvedQuality });
  const w754NpcSchedulePlan = buildEonCityW754NpcSchedulePlan();
  const w754NpcScheduleController = createEonCityW754NpcScheduleController({ now, plan: w754NpcSchedulePlan });
  const w754TransitController = createEonCityW754TransitController({ now });
  const initialTimeProfile = resolveEonCityW755LocalTimeProfile(new Date());
  const initialEnvironmentPlan = buildEonCityW755EnvironmentPlan({ quality: resolvedQuality, timeProfile: initialTimeProfile, weatherProfile: 'clear', reducedEffects: Boolean(reducedMotion), reducedSensory: Boolean(reducedMotion) });
  const environmentValidation = validateEonCityW755EnvironmentPlan(initialEnvironmentPlan);
  if (!environmentValidation.ok) throw new Error(`w755-environment-art-audio-invalid:${environmentValidation.errors.join(',')}`);
  const environmentController = createEonCityW755EnvironmentController({ quality: resolvedQuality, timeProfile: initialTimeProfile, weatherProfile: 'clear', reducedEffects: Boolean(reducedMotion), reducedSensory: Boolean(reducedMotion), environment: globalThis, onState: (state) => onTelemetry?.(freeze({ type: 'w755-environment', state })) });
  const w756ExperiencePlan = buildEonCityW756ExperiencePlan({ width: Number(globalThis.innerWidth || 1280), height: Number(globalThis.innerHeight || 720), coarsePointer: Boolean(globalThis.matchMedia?.('(pointer: coarse)')?.matches), reducedMotion: Boolean(reducedMotion), highContrast: Boolean(globalThis.matchMedia?.('(forced-colors: active)')?.matches) });
  const w756ExperienceValidation = validateEonCityW756ExperiencePlan(w756ExperiencePlan);
  if (!w756ExperienceValidation.ok) throw new Error(`w756-onboarding-navigation-accessibility-invalid:${w756ExperienceValidation.errors.join(',')}`);
  const w757ReliabilityPlan = buildEonCityW757ReliabilityPlan({ quality: resolvedQuality });
  const w757ReliabilityValidation = validateEonCityW757ReliabilityPlan(w757ReliabilityPlan);
  if (!w757ReliabilityValidation.ok) throw new Error(`w757-performance-reliability-invalid:${w757ReliabilityValidation.errors.join(',')}`);
  const reliabilityController = createEonCityW757ReliabilityController({ quality: resolvedQuality, now, onState: (state) => onTelemetry?.(freeze({ type: 'w757-reliability', state })) });
  reliabilityController.recordStage('route-entered');
  const palette = themePalette(document);
  const canvas = document.createElement('canvas');
  canvas.className = 'eon-play-canvas eon-city-command-hub-canvas';
  canvas.tabIndex = 0;
  canvas.setAttribute('aria-label', 'EON City Command Hub. Use W A S D or arrow keys to move, E to use the nearest station, and M for City Menu.');
  host.replaceChildren(canvas);
  stage('CANVAS_ATTACHED');

  let engine = null;
  let scene = null;
  let currentHardwareScalingLevel = 1;
  let maxHardwareScalingLevel = 1;
  try {
    stage('ENGINE_CREATE_STARTED');
    engine = new Engine(canvas, resolvedQuality !== 'lite', {
      stencil: false,
      preserveDrawingBuffer: false,
      doNotHandleContextLost: false,
      powerPreference: resolvedQuality === 'cinematic' ? 'high-performance' : 'default'
    });
    const targetDpr = resolvedQuality === 'cinematic' ? 1.8 : resolvedQuality === 'balanced' ? 1.35 : 1;
    const browserDpr = Math.max(1, Math.min(3, Number(globalThis.devicePixelRatio || 1)));
    currentHardwareScalingLevel = Math.max(1, browserDpr / targetDpr);
    maxHardwareScalingLevel = Math.max(currentHardwareScalingLevel, resolvedQuality === 'cinematic' ? 1.6 : resolvedQuality === 'balanced' ? 1.75 : 2);
    engine.setHardwareScalingLevel?.(currentHardwareScalingLevel);
    scene = new Scene(engine);
    scene.clearColor = new Color4(...color(initialEnvironmentPlan.lighting.clearColor).asArray(), 1);
    scene.ambientColor = color(initialEnvironmentPlan.lighting.ambientColor);
    scene.fogMode = Scene.FOGMODE_EXP2;
    scene.fogColor = color(initialEnvironmentPlan.lighting.fogColor);
    scene.fogDensity = initialEnvironmentPlan.lighting.fogDensity;
    if (scene.imageProcessingConfiguration) {
      scene.imageProcessingConfiguration.exposure = initialEnvironmentPlan.lighting.exposure;
      scene.imageProcessingConfiguration.contrast = initialEnvironmentPlan.lighting.contrast;
    }
    stage('ENGINE_CREATED');
    reliabilityController.recordStage('engine-created');
  } catch (error) {
    throw Object.assign(error instanceof Error ? error : new Error('City engine creation failed.'), { code: 'CITY_ENGINE_CREATE_FAILED' });
  }

  const playerAnchor = new TransformNode('w737-player-anchor', scene);
  playerAnchor.position.set(EON_CITY_W731_SPAWN.x, EON_CITY_W731_SPAWN.y, EON_CITY_W731_SPAWN.z);
  playerAnchor.rotation.y = EON_CITY_W731_SPAWN.heading;
  playerAnchor.metadata = freeze({ kind: 'w737-main-avatar-anchor', launchReadyAsset: 'pathfinder-prime', proceduralFallback: true });

  const camera = new ArcRotateCamera(
    'w737-command-centre-camera',
    EON_CITY_W743_ARRIVAL_CAMERA.alpha,
    EON_CITY_W743_ARRIVAL_CAMERA.beta,
    EON_CITY_W743_ARRIVAL_CAMERA.radius,
    new Vector3(EON_CITY_W743_ARRIVAL_CAMERA.target.x, EON_CITY_W743_ARRIVAL_CAMERA.target.y, EON_CITY_W743_ARRIVAL_CAMERA.target.z),
    scene
  );
  camera.lowerRadiusLimit = EON_CITY_W743_ARRIVAL_CAMERA.lowerRadiusLimit;
  camera.upperRadiusLimit = EON_CITY_W743_ARRIVAL_CAMERA.upperRadiusLimit;
  camera.lowerBetaLimit = EON_CITY_W743_ARRIVAL_CAMERA.lowerBetaLimit;
  camera.upperBetaLimit = EON_CITY_W743_ARRIVAL_CAMERA.upperBetaLimit;
  // Preserve the certified W743 construction authority, then apply the bounded
  // W760 composition adjustment before the first rendered frame.
  camera.alpha = EON_CITY_W760_CAMERA_POSES.arrival.alpha;
  camera.beta = EON_CITY_W760_CAMERA_POSES.arrival.beta;
  camera.radius = EON_CITY_W760_CAMERA_POSES.arrival.radius;
  camera.setTarget(new Vector3(EON_CITY_W760_CAMERA_POSES.arrival.target.x, EON_CITY_W760_CAMERA_POSES.arrival.target.y, EON_CITY_W760_CAMERA_POSES.arrival.target.z));
  camera.panningSensibility = 0;
  camera.wheelDeltaPercentage = 0.012;
  camera.checkCollisions = true;
  camera.collisionRadius = new Vector3(0.48, 0.55, 0.48);
  scene.collisionsEnabled = true;
  camera.attachControl(canvas, true);

  const hemisphere = new HemisphericLight('w737-hemisphere', new Vector3(0.2, 1, -0.1), scene);
  hemisphere.intensity = resolvedQuality === 'lite' ? 0.78 : 0.92;
  hemisphere.diffuse = color(initialEnvironmentPlan.lighting.hemisphereColor);
  hemisphere.groundColor = color(initialEnvironmentPlan.lighting.groundColor);
  const direction = new DirectionalLight('w737-directional', new Vector3(-0.3, -1, 0.45), scene);
  direction.position.set(14, 24, -16);
  direction.intensity = initialEnvironmentPlan.lighting.keyIntensity;
  direction.diffuse = color(initialEnvironmentPlan.lighting.keyColor);

  const world = createWorld(scene, palette, initialEnvironmentPlan);
  applyW755EnvironmentPlan({ scene, hemisphere, direction, world, plan: initialEnvironmentPlan });
  const fallbackPlayer = createProceduralPerson(scene, playerAnchor, 'pathfinder', world.materials, { accent: true });
  fallbackPlayer.root.scaling.setAll(1.06);
  const eonbotAnchor = new TransformNode('w737-eonbot-anchor', scene);
  eonbotAnchor.position.set(EON_CITY_W731_EONBOT_DOCK.x, 0.85, EON_CITY_W731_EONBOT_DOCK.z);
  eonbotAnchor.metadata = freeze({ kind: 'w737-eonbot-companion', curiousFollow: true, dock: EON_CITY_W731_EONBOT_DOCK });
  const eonbotFallback = MeshBuilder.CreateSphere('w737-eonbot-fallback', { diameter: 0.86, segments: 20 }, scene);
  eonbotFallback.parent = eonbotAnchor; eonbotFallback.material = world.materials.accent; eonbotFallback.isPickable = true;
  eonbotFallback.metadata = stationMetadata(getEonCityW731Station('eonbot-nexus'), { part: 'npc', interactionRole: 'npc', npcName: 'EONBOT', companion: true });
  const eonbotRing = MeshBuilder.CreateTorus('w737-eonbot-fallback-ring', { diameter: 1.25, thickness: 0.055, tessellation: 28 }, scene);
  eonbotRing.parent = eonbotAnchor; eonbotRing.rotation.x = Math.PI / 2; eonbotRing.material = world.materials.signal; eonbotRing.isPickable = false;
  const eonbotScanHalo = MeshBuilder.CreateTorus('w745-eonbot-scan-halo', { diameter: 1.48, thickness: 0.035, tessellation: 36 }, scene);
  eonbotScanHalo.parent = eonbotAnchor; eonbotScanHalo.rotation.x = Math.PI / 2; eonbotScanHalo.position.y = -0.06; eonbotScanHalo.material = world.materials.cyan; eonbotScanHalo.isPickable = false; eonbotScanHalo.setEnabled(false);
  const eonbotScanBeam = MeshBuilder.CreateCylinder('w745-eonbot-scan-beam', { diameterTop: 0.08, diameterBottom: 0.46, height: 1.15, tessellation: 18 }, scene);
  eonbotScanBeam.parent = eonbotAnchor; eonbotScanBeam.position.y = -0.72; eonbotScanBeam.material = world.materials.glass; eonbotScanBeam.isPickable = false; eonbotScanBeam.setEnabled(false);
  const eonbotSparkA = MeshBuilder.CreateSphere('w745-eonbot-spark-a', { diameter: 0.11, segments: 8 }, scene);
  eonbotSparkA.parent = eonbotAnchor; eonbotSparkA.material = world.materials.warm; eonbotSparkA.isPickable = false;
  const eonbotSparkB = MeshBuilder.CreateSphere('w745-eonbot-spark-b', { diameter: 0.085, segments: 8 }, scene);
  eonbotSparkB.parent = eonbotAnchor; eonbotSparkB.material = world.materials.cyan; eonbotSparkB.isPickable = false;

  stage('SCENE_CREATED');
  reliabilityController.recordStage('scene-created');
  const movement = { forward: new Set(), backward: new Set(), left: new Set(), right: new Set() };
  const analog = new Map();
  const heldKeys = new Map();
  let destroyed = false;
  let manualPaused = false;
  let documentHidden = globalThis.document?.visibilityState === 'hidden';
  let contextLost = false;
  let contextLossCount = 0;
  let contextRestoreCount = 0;
  let lowFpsSamples = 0;
  let performanceProtectionLevel = 0;
  let lastPerformanceProtectionAt = 0;
  let firstFrame = false;
  let workSurfaceOpen = false;
  let workSurfaceOpenedAt = 0;
  let lastInputEvent = freeze({ source: 'runtime', direction: '', active: false, accepted: false, reason: 'not-started', at: 0 });
  let keydownEvents = 0;
  let keyupEvents = 0;
  let lastRawKeyboardEvent = freeze({ type: '', key: '', code: '', resolvedCode: '', targetTag: '', targetEditable: false, activeElementTag: '', accepted: false, reason: 'not-started', at: 0 });
  let renderLoopFrames = 0;
  let movementUpdateCalls = 0;
  let lastRenderAt = 0;
  let lastMovementUpdateAt = 0;
  let lastReliabilityRenderDecision = 'not-started';
  let sceneRenderCalls = 0;
  let lastSceneRenderError = '';
  let movementRenderRecovery = null;
  let lastSimulationClockAt = Date.now();
  let simulationAccumulatorSeconds = 0;
  let lastSimulationStepAt = 0;
  let simulationStepCount = 0;
  let simulationSource = 'not-started';
  let fallbackClockHandle = null;
  let fallbackClockGeneration = 0;
  let fallbackClockTickCount = 0;
  let fallbackSimulationStepCount = 0;
  let renderSimulationStepCount = 0;
  let duplicateStepPreventedCount = 0;
  let lastSimulationDeltaSeconds = 0;
  let startMovementSimulationFallback = null;
  let stopMovementSimulationFallback = null;
  let settleMovementBeforeSourceRelease = null;
  let releaseSettlementStepCount = 0;
  let releaseSettlementDistance = 0;
  let lastReleaseSettlement = freeze({ attempted: false, allowed: false, source: '', reason: 'not-started', unprocessedElapsedMs: 0, boundedElapsedMs: 0, fixedStepsApplied: 0, distanceApplied: 0, skippedReason: 'not-started', at: 0 });
  let axisReadCount = 0;
  let activeAxisFrameCount = 0;
  let lastAxis = freeze({ right: 0, forward: 0, active: false });
  let lastBeforePosition = freeze({ x: 0, z: 0 });
  let lastRequestedPosition = freeze({ x: 0, z: 0 });
  let lastClampedPosition = freeze({ x: 0, z: 0 });
  let lastTravelledDistance = 0;
  let lastMovementBlockReason = 'no-input';
  let movementFrameCount = 0;
  let movementDistance = 0;
  let lastMovementAt = 0;
  let nearestStation = null;
  let nearestDiscovery = null;
  let lastNearestId = '';
  let activeMissionId = '';
  let activeStationId = '';
  let lastResumeWrite = 0;
  let lastTelemetry = 0;
  let playerMotion = 'idle';
  let playerPresentationState = 'idle';
  let heroPresentationSnapshot = null;
  const heroPresentationDirector = createEonCityW745HeroPresentationDirector({ now });
  const heroPresentationTruth = getEonCityW745HeroPresentationTruth();
  let lastCharacterMotionSnapshot = null;
  const locomotionTruth = createEonCityW695LocomotionTruthController({
    initialPosition: EON_CITY_W731_SPAWN,
    initialHeading: EON_CITY_W731_SPAWN.heading,
    stopHoldMs: EON_CITY_W761_CHARACTER_PROFILE.locomotion.stopBlendSeconds * 1000,
    headingSmoothing: Math.min(0.72, EON_CITY_W761_CHARACTER_PROFILE.locomotion.turnResponsiveness / 12)
  });
  let localAssetRuntime = null;
  let playerAsset = null;
  let eonbotAsset = null;
  const visibleFrameState = {
    authoredEnvironmentReady: 0,
    authoredHeroCharactersReady: 0,
    gateComplete: false,
    degraded: true
  };
  const npcAssets = new Map();
  let lastFrameAt = now();
  let fpsSampleAt = now();
  let fpsFrames = 0;
  let measuredFps = 0;
  let activationPulse = null;
  let cameraMode = 'arrival';
  let spatialDiagnosticsVisible = false;
  const spatialDiagnostics = createEonCityW747SpatialDiagnostics();

  const stationState = world.stations;
  const discoveryState = world.discoveries;
  const spatialOverlay = createEonCityW747DiagnosticsOverlay(scene, world.root, spatialDiagnostics);
  const registerSpatialNode = (id, node, options = {}) => {
    const bounds = getEonCityW747NodeWorldBounds(node);
    if (!bounds) return freeze({ ok: false, reason: 'node-bounds-unavailable', id });
    return spatialDiagnostics.registerLoadedAsset({ id, bounds, ...options });
  };
  const registerLoadedSpatialAsset = (id, loaded, options = {}) => {
    if (!isEonCityW759PresentationReady(loaded) || !loaded?.bounds) return freeze({ ok: false, reason: 'loaded-presentation-unavailable', id });
    return spatialDiagnostics.registerLoadedAsset({ id, bounds: loaded.bounds, ...options });
  };
  registerSpatialNode('procedural:operations-command-table', world.commandTable, {
    primaryRole: 'operations-command-table', groupId: 'operations-crescent'
  });
  registerSpatialNode('procedural:eonbot-dock', world.dock, {
    primaryRole: 'eonbot-dock', groupId: 'living-nexus-support', allowHeroZone: true, allowArrivalRay: true
  });
  for (const [stationId, record] of stationState) {
    registerSpatialNode(`fallback:station:${stationId}`, record.root, {
      primaryRole: stationId === 'eonbot-nexus' ? 'living-nexus-core' : stationId,
      groupId: stationId,
      allowHeroZone: stationId === 'eonbot-nexus',
      allowArrivalRay: stationId === 'eonbot-nexus'
    });
  }
  for (const [discoveryId, record] of discoveryState) {
    registerSpatialNode(`fallback:discovery:${discoveryId}`, record.root, {
      primaryRole: discoveryId, groupId: discoveryId
    });
  }
  for (const column of world.commandColumns || []) {
    registerSpatialNode(`procedural:${column.name}`, column, { groupId: 'command-canopy' });
  }
  productRoot.dataset.eonCitySpatialAuthority = EON_CITY_W747_SPATIAL_SCHEMA;
  productRoot.dataset.eonCityHeroZoneDiameter = String(EON_CITY_W747_HERO_ZONE.diameter);
  productRoot.dataset.eonCityCastTransitAuthority = EON_CITY_W754_SCHEMA;
  productRoot.dataset.eonCityCapsuleId = EON_CITY_W754_CAPSULE_ID;
  productRoot.dataset.eonCityCommandCoreConvergence = EON_CITY_W760_W765_SCHEMA;
  productRoot.dataset.eonCityNexusAuthority = EON_CITY_W749_LIVING_NEXUS_SCHEMA;
  productRoot.dataset.eonCityMissionAuthority = EON_CITY_W752_SCHEMA;
  const setSpatialDiagnosticsVisible = (visible, { advancedDiagnostics = false } = {}) => {
    if (!advancedDiagnostics) return freeze({ ok: false, reason: 'advanced-diagnostics-required', visible: spatialDiagnosticsVisible });
    spatialDiagnosticsVisible = spatialOverlay.setVisible(Boolean(visible));
    return freeze({ ok: true, visible: spatialDiagnosticsVisible, report: spatialDiagnostics.getReport() });
  };
  const forcePlayerIdle = (reason = 'movement-stopped') => {
    simulationAccumulatorSeconds = 0;
    lastSimulationClockAt = Date.now();
    lastCharacterMotionSnapshot = locomotionTruth.reset({
      position: playerAnchor.position,
      worldHeading: playerAnchor.rotation.y
    });
    playerMotion = 'idle';
    playerPresentationState = 'idle';
    const animations = playerAsset?.animations;
    const accepted = animations?.playStationary?.('idle', { restart: true })
      ?? animations?.play?.('idle', { restart: true });
    animations?.stabilize?.();
    lastMovementBlockReason = String(reason || 'movement-stopped');
    return accepted !== false;
  };
  const setDirection = (directionName, active, source = 'external', { settleBeforeRelease = true, releaseReason = 'input-release' } = {}) => {
    const bucket = movement[directionName];
    if (!bucket) return false;
    const previousAxis = axis();
    const key = String(source || 'external').slice(0, 64);
    if (!active && settleBeforeRelease) settleMovementBeforeSourceRelease?.({ source: key, reason: releaseReason, allowSettlement: true });
    if (active) bucket.add(key); else bucket.delete(key);
    const nextAxis = axis();
    if (!previousAxis.active && nextAxis.active) {
      movementRenderRecovery?.activate({ source: key, reason: 'movement-activated' });
      startMovementSimulationFallback?.(key);
    }
    if (previousAxis.active && !nextAxis.active) {
      movementRenderRecovery?.deactivate('movement-inactive');
      stopMovementSimulationFallback?.('movement-inactive');
      forcePlayerIdle(releaseReason || 'movement-inactive');
    }
    lastInputEvent = freeze({ source: key, direction: directionName, active: Boolean(active), accepted: true, reason: 'direction-updated', at: Date.now() });
    return true;
  };
  const clearInput = (reason = 'clear-input') => {
    for (const bucket of Object.values(movement)) bucket.clear();
    analog.clear();
    heldKeys.clear();
    movementRenderRecovery?.deactivate(reason);
    stopMovementSimulationFallback?.(reason);
    forcePlayerIdle(reason);
    lastInputEvent = freeze({ source: 'runtime', direction: '', active: false, accepted: true, reason: String(reason || 'clear-input'), at: Date.now() });
  };
  const axis = () => {
    let right = (movement.right.size ? 1 : 0) - (movement.left.size ? 1 : 0);
    let forward = (movement.forward.size ? 1 : 0) - (movement.backward.size ? 1 : 0);
    for (const value of analog.values()) { right += Number(value.x || 0); forward += Number(value.z || 0); }
    const magnitude = Math.hypot(right, forward);
    if (magnitude > 1) { right /= magnitude; forward /= magnitude; }
    const value = freeze({ right, forward, active: magnitude > 0.001 });
    axisReadCount += 1;
    lastAxis = value;
    return value;
  };
  const getMovementBlockReason = () => {
    if (destroyed) return 'runtime-destroyed';
    if (documentHidden) return 'document-hidden';
    if (manualPaused) return 'manual-pause';
    if (workSurfaceOpen) return 'work-surface-open';
    if (ui?.isMenuOpen?.()) return 'city-menu-open';
    return '';
  };

  const captureCameraPose = () => freeze({
    alpha: Number(camera.alpha), beta: Number(camera.beta), radius: Number(camera.radius),
    target: freeze({ x: Number(camera.target.x), y: Number(camera.target.y), z: Number(camera.target.z) }),
    mode: cameraMode
  });
  const applyCameraPose = (pose = EON_CITY_W747_CAMERA_POSES.follow, mode = pose.id || 'follow') => {
    camera.alpha = Number(pose.alpha);
    camera.beta = Number(pose.beta);
    camera.radius = Number(pose.radius);
    camera.lowerRadiusLimit = Number(pose.lowerRadiusLimit || EON_CITY_W731_WORLD_BOUNDS.cameraRadiusMin);
    camera.upperRadiusLimit = Number(pose.upperRadiusLimit || EON_CITY_W731_WORLD_BOUNDS.cameraRadiusMax);
    camera.lowerBetaLimit = Number(pose.lowerBetaLimit || EON_CITY_W731_WORLD_BOUNDS.cameraBetaMin);
    camera.upperBetaLimit = Number(pose.upperBetaLimit || EON_CITY_W731_WORLD_BOUNDS.cameraBetaMax);
    camera.setTarget(new Vector3(Number(pose.target.x), Number(pose.target.y), Number(pose.target.z)));
    cameraMode = String(mode || pose.id || 'follow');
    return captureCameraPose();
  };
  const restoreCameraPose = (pose = null) => {
    if (!pose?.target) return applyCameraPose(EON_CITY_W747_CAMERA_POSES.follow, 'follow');
    camera.alpha = Number(pose.alpha);
    camera.beta = Number(pose.beta);
    camera.radius = Number(pose.radius);
    camera.setTarget(new Vector3(Number(pose.target.x), Number(pose.target.y), Number(pose.target.z)));
    cameraMode = String(pose.mode || 'follow');
    return captureCameraPose();
  };
  const focusCameraOnStation = (station) => {
    if (!station) return applyCameraPose(EON_CITY_W760_CAMERA_POSES.return, 'return');
    if (station.id === 'eonbot-nexus') return applyCameraPose(EON_CITY_W760_CAMERA_POSES.nexusFocus, 'nexus-focus');
    const dx = Number(station.focus.x) - Number(station.position.x);
    const dz = Number(station.focus.z) - Number(station.position.z);
    const pose = {
      alpha: Math.atan2(dz, dx), beta: 1.05,
      radius: Math.max(8.6, Math.min(12.2, Number(station.footprintRadius || 2.5) * 3.35)),
      target: { x: station.position.x, y: 1.55, z: station.position.z },
      lowerRadiusLimit: 6.8, upperRadiusLimit: 15.5, lowerBetaLimit: 0.72, upperBetaLimit: 1.36
    };
    return applyCameraPose(pose, 'station-focus');
  };
  const applyPlayerPose = (pose = {}, { stationId = '', save = true, camera = 'follow' } = {}) => {
    const sanitized = sanitizeEonCityW747WorldPoint(pose);
    const safe = clampEonCityW731Position(sanitized);
    playerAnchor.position.set(safe.x, 0, safe.z);
    if (Number.isFinite(Number(pose.heading))) playerAnchor.rotation.y = Number(pose.heading);
    locomotionTruth.reset({ position: playerAnchor.position, worldHeading: playerAnchor.rotation.y });
    lastCharacterMotionSnapshot = locomotionTruth.getSnapshot();
    if (camera === 'arrival') {
      applyCameraPose(EON_CITY_W747_CAMERA_POSES.arrival, 'arrival');
      applyCameraPose(EON_CITY_W760_CAMERA_POSES.arrival, 'arrival');
    }
    else if (camera === 'return') applyCameraPose(EON_CITY_W760_CAMERA_POSES.return, 'return');
    else if (camera === 'follow') {
      cameraMode = 'follow';
      camera.setTarget(new Vector3(playerAnchor.position.x, EON_CITY_W747_CAMERA_POSES.follow.targetHeight, playerAnchor.position.z));
    }
    activeStationId = stationId || activeStationId;
    if (save) writeResume(playerAnchor.position, playerAnchor.rotation.y, activeStationId);
    return freeze({ ...safe, sanitized: sanitized.sanitized });
  };

  const projector = (entity, kind = 'station') => {
    const record = kind === 'discovery' ? discoveryState.get(entity.id) : stationState.get(entity.id);
    const target = record?.focusNode?.getAbsolutePosition?.() || new Vector3(entity.position.x, 2.3, entity.position.z);
    const viewport = camera.viewport.toGlobal(engine.getRenderWidth(), engine.getRenderHeight());
    const projected = Vector3.Project(target, Matrix.IdentityReadOnly, scene.getTransformMatrix(), viewport);
    const cameraSpace = Vector3.TransformCoordinates(target, scene.getViewMatrix());
    const visible = cameraSpace.z > 0 && projected.x > -120 && projected.x < engine.getRenderWidth() + 120 && projected.y > -80 && projected.y < engine.getRenderHeight() + 100;
    return freeze({ x: projected.x, y: projected.y, depth: projected.z, visible });
  };

  const interactionRegistry = createEonCityW748InteractionRegistry();
  let nexusEventAdapter = null;
  try {
    nexusEventAdapter = createEonNexusEventAdapter({
      environment: globalThis,
      document: globalThis.document
    });
  } catch {
    onStatus?.('Living Nexus source adapter is unavailable; bounded guide mode remains active.');
  }
  const nexusStationRecord = stationState.get('eonbot-nexus');
  const livingNexus = createEonCityW749LivingNexus({
    scene,
    stationRecord: nexusStationRecord,
    MeshBuilder,
    TransformNode,
    Vector3,
    materials: world.materials,
    eventAdapter: nexusEventAdapter,
    readContinuity: () => {
      try { return readEonNexusContinuitySnapshot(); }
      catch { return null; }
    },
    getMissions: () => {
      try { return buildEonCityW737MissionView(); }
      catch { return []; }
    },
    environment: globalThis,
    now: Date.now,
    reducedMotion: () => reducedMotion,
    onStatus
  });
  if (livingNexus.ok) {
    for (const node of nexusStationRecord?.fallbackVisualNodes || []) node.setEnabled?.(false);
    for (const node of nexusStationRecord?.stationDetailNodes || []) node.setEnabled?.(false);
    registerSpatialNode('procedural:w749-living-nexus', livingNexus.root, {
      primaryRole: 'living-nexus-hero',
      groupId: 'living-nexus-support',
      allowHeroZone: true,
      allowArrivalRay: true
    });
  }
  const commandStatusController = createEonCityTruthfulCommandCenterController({
    fetchImpl: globalThis.fetch,
    now: Date.now
  });
  const agentTheatreController = createEonCityGenuineAgentTheatreController({ now: Date.now });
  const commandCentreStationRecord = stationState.get('command-console');
  const commandCentre = createEonCityW750CommandCentre({
    scene,
    stationRecord: commandCentreStationRecord,
    MeshBuilder,
    TransformNode,
    Vector3,
    DynamicTexture,
    StandardMaterial,
    materials: world.materials,
    environment: globalThis,
    getNexusView: () => livingNexus.getView?.() || {},
    getCommandSnapshot: () => commandStatusController.getSnapshot(),
    getTheatreSnapshot: () => agentTheatreController.getSnapshot(),
    subscribeCommand: (listener) => commandStatusController.subscribe(listener),
    subscribeTheatre: (listener) => agentTheatreController.subscribe(listener),
    districtCount: 9,
    reducedMotion: () => reducedMotion,
    onStatus
  });
  if (commandCentre.ok) {
    registerSpatialNode('procedural:w750-command-centre-live-walls', commandCentre.root, {
      primaryRole: 'command-centre-live-walls',
      groupId: 'command-console'
    });
  }
  let productiveStationStorage = null;
  try {
    productiveStationStorage = globalThis.localStorage;
  } catch {
    productiveStationStorage = null;
  }
  const productiveStations = createEonCityW751ProductiveStations({
    storage: productiveStationStorage,
    environment: globalThis,
    now: Date.now
  });
  const missionsProgression = createEonCityW752MissionsProgression({
    stationController: productiveStations,
    storage: productiveStationStorage,
    environment: globalThis,
    now: Date.now
  });
  const stationMonitorValidation = validateEonCityW765R5StationMonitorContract();
  const stationMonitors = new Map();
  for (const station of EON_CITY_W731_STATIONS) {
    if (station.id === 'command-console') continue;
    const stationRecord = stationState.get(station.id);
    const monitor = createEonCityW765R5StationMonitor({
      scene,
      station,
      stationRecord,
      MeshBuilder,
      TransformNode,
      DynamicTexture,
      StandardMaterial,
      materials: world.materials,
      interactionMetadata: stationMetadata(station, {
        part: 'terminal',
        interactionRole: 'terminal',
        liveMonitor: true,
        monitorSchema: EON_CITY_W765R5_STATION_MONITOR_SCHEMA
      }),
      projectionProvider: () => projectEonCityW765R5StationMonitor({
        station,
        productiveView: productiveStations.getView?.() || {},
        nexusView: livingNexus.getView?.() || {},
        commandSnapshot: commandStatusController.getSnapshot?.() || {},
        theatreSnapshot: agentTheatreController.getSnapshot?.() || {}
      }),
      openSurface: (stationId, trigger) => openSurfaceForStation(stationId, trigger),
      now
    });
    if (!monitor.ok) continue;
    stationMonitors.set(station.id, monitor);
    registerSpatialNode(`procedural:w765r5-monitor:${station.id}`, monitor.root, {
      primaryRole: station.id === 'eonbot-nexus' ? 'eonbot-hero-monitor' : 'productive-station-monitor',
      groupId: station.id,
      allowHeroZone: station.id === 'eonbot-nexus',
      allowArrivalRay: station.id === 'eonbot-nexus'
    });
  }
  for (const wallId of EON_CITY_W750_WALL_IDS) {
    const wallView = commandCentre.getView?.()?.walls?.find?.((entry) => entry.id === wallId);
    interactionRegistry.register({
      id: `command-wall:${wallId}`,
      objectType: 'command-centre',
      role: 'live-command-wall',
      label: wallView?.label || `${wallId} command wall`,
      oneLinePurpose: wallView?.purpose || 'Inspect bounded Command Centre state.',
      inspectText: wallView?.detail || 'Inspect this truthful bounded wall before opening maintained work.',
      truthBoundary: wallView?.truthBoundary || 'No private content or automatic work is exposed by this wall.',
      stationId: 'command-console',
      position: freeze({ ...getEonCityW731Station('command-console').position }),
      primaryAction: freeze({
        kind: 'open', label: `Inspect ${wallView?.label || wallId}`, surface: 'command-centre', presentationMode: 'dock',
        explicitUserActionRequired: true, automaticNavigation: false, automaticExecution: false
      }),
      secondaryAction: freeze({
        kind: 'inspect', label: 'Read truth boundary', explicitUserActionRequired: true,
        automaticNavigation: false, automaticExecution: false
      }),
      accessibilityLabel: `${wallView?.label || wallId} command wall. Inspect bounded state; no automatic work.`,
      availability: freeze({ state: 'available', truthful: true }),
      explicitUserActionRequired: true,
      autoNavigate: false,
      autoExecute: false
    });
  }
  for (const ringId of EON_CITY_W749_RING_IDS) {
    const ringView = livingNexus.getView?.()?.rings?.find?.((entry) => entry.id === ringId);
    interactionRegistry.register({
      id: `nexus-ring:${ringId}`,
      objectType: 'nexus',
      role: 'living-nexus-ring',
      label: ringView?.label || `${ringId} Nexus ring`,
      oneLinePurpose: ringView?.shortLabel || 'Inspect a bounded privacy-projected Nexus state.',
      inspectText: ringView?.detail || 'Inspect this bounded Nexus projection before opening maintained work.',
      truthBoundary: ringView?.truthBoundary || 'No private content or automatic work is exposed by this City object.',
      stationId: 'eonbot-nexus',
      position: freeze({ ...getEonCityW731Station('eonbot-nexus').position }),
      primaryAction: freeze({
        kind: 'open', label: `Inspect ${ringView?.label || ringId}`, surface: 'nexus', presentationMode: 'dock',
        explicitUserActionRequired: true, automaticNavigation: false, automaticExecution: false
      }),
      secondaryAction: freeze({
        kind: 'inspect', label: 'Read truth boundary', explicitUserActionRequired: true,
        automaticNavigation: false, automaticExecution: false
      }),
      accessibilityLabel: `${ringView?.label || ringId} Nexus ring. Inspect bounded state; no automatic work.`,
      availability: freeze({ state: 'available', truthful: true }),
      explicitUserActionRequired: true,
      autoNavigate: false,
      autoExecute: false
    });
  }
  const interactionCompleteness = auditEonCityW763InteractionCompleteness(interactionRegistry.list({ qualityMode: resolvedQuality, visibleOnly: false }));
  if (!interactionCompleteness.ok) throw new Error(`w763-interaction-completeness-invalid:${[...interactionCompleteness.dead, ...interactionCompleteness.missingCopy, ...interactionCompleteness.missingAccessibility].join(',')}`);
  let workspacePresentationMode = 'world';
  let ui = null;
  let semanticNavigationController = null;
  let nexusReactionController = null;
  let rewardReactionController = null;
  let latestNexusReaction = null;
  let latestRewardReaction = null;
  let onW749ViewChanged = null;

  const inspectInteraction = (interaction = null, target = null) => {
    const entity = target?.entity || null;
    const record = interaction || (target?.kind === 'station'
      ? interactionRegistry.getStation(entity?.id, 'structure')
      : interactionRegistry.get(`discovery:${entity?.id || ''}`));
    if (!record) return freeze({ ok: false, reason: 'interaction-not-found' });
    onStatus?.(`${record.label}: ${record.inspectText} ${record.truthBoundary}`);
    return freeze({ ok: true, interactionId: record.id, action: 'inspect', noAutomaticWork: true });
  };

  const workspacePresenter = createEonCityW748WorkspacePresenter({
    environment: globalThis,
    captureWorldState: () => freeze({
      player: freeze({ x: Number(playerAnchor.position.x), y: 0, z: Number(playerAnchor.position.z), heading: Number(playerAnchor.rotation.y) }),
      camera: captureCameraPose(),
      activeStationId,
      activeMissionId,
      nearestStationId: nearestStation?.station?.id || '',
      nearestDiscoveryId: nearestDiscovery?.discovery?.id || '',
      selectedInteractionId: String(productRoot.dataset.eonCitySelectedInteraction || '')
    }),
    focusWorldObject: ({ station }) => {
      activeStationId = station.id;
      return focusCameraOnStation(station);
    },
    restoreWorldState: (snapshot) => {
      if (!snapshot) return freeze({ ok: false, reason: 'workspace-snapshot-missing' });
      activeStationId = String(snapshot.activeStationId || '');
      applyPlayerPose(snapshot.player || EON_CITY_W731_SPAWN, { stationId: activeStationId, save: false, camera: 'none' });
      const cameraReceipt = restoreCameraPose(snapshot.camera);
      nearestStation = resolveEonCityW731NearestStation(playerAnchor.position, 5.2);
      nearestDiscovery = resolveEonCityW737NearestDiscovery(playerAnchor.position, 5.2);
      const stationDistance = Number(nearestStation?.distance ?? Number.POSITIVE_INFINITY);
      const discoveryDistance = Number(nearestDiscovery?.distance ?? Number.POSITIVE_INFINITY);
      const selectedInteractionId = String(snapshot.selectedInteractionId || '');
      const selectedStationId = selectedInteractionId.startsWith('station:') ? selectedInteractionId.slice('station:'.length) : '';
      const selectedDiscoveryId = selectedInteractionId.startsWith('discovery:') ? selectedInteractionId.slice('discovery:'.length) : '';
      const restoredTarget = selectedStationId && getEonCityW731Station(selectedStationId)
        ? freeze({ station: getEonCityW731Station(selectedStationId), distance: Math.hypot(playerAnchor.position.x - getEonCityW731Station(selectedStationId).position.x, playerAnchor.position.z - getEonCityW731Station(selectedStationId).position.z) })
        : selectedDiscoveryId && getEonCityW737Discovery(selectedDiscoveryId)
          ? freeze({ discovery: getEonCityW737Discovery(selectedDiscoveryId), distance: Math.hypot(playerAnchor.position.x - getEonCityW737Discovery(selectedDiscoveryId).position.x, playerAnchor.position.z - getEonCityW737Discovery(selectedDiscoveryId).position.z) })
          : stationDistance <= discoveryDistance ? nearestStation : nearestDiscovery;
      lastNearestId = restoredTarget?.station?.id || restoredTarget?.discovery?.id || '';
      ui?.setPrompt?.(restoredTarget);
      setContextualSelection(restoredTarget);
      writeResume(playerAnchor.position, playerAnchor.rotation.y, activeStationId);
      return freeze({ ok: true, camera: cameraReceipt, player: snapshot.player });
    },
    setMovementPaused: (shouldPause) => {
      workSurfaceOpen = Boolean(shouldPause);
      workSurfaceOpenedAt = shouldPause ? now() : 0;
      if (shouldPause) clearInput('work-surface-open');
      ui?.setPaused?.(manualPaused || workSurfaceOpen);
    },
    setWorldAudioPaused: (shouldPause) => {
      productRoot.dataset.eonCityAudioPaused = shouldPause ? 'true' : 'false';
    },
    setBackgroundPresentation: (mode) => {
      workspacePresentationMode = String(mode || 'world');
      productRoot.dataset.eonCityWorkspacePresentation = workspacePresentationMode;
      reliabilityController.noteWorkspacePresentation(workspacePresentationMode);
    },
    onStatus,
    onReturn: ({ source } = {}) => {
      const openedStationId = String(source?.stationId || activeStationId || '');
      const restoredStationId = String(source?.snapshot?.activeStationId || '');
      productiveStations.markReturned?.(openedStationId, { explicitUserAction: true });
      if (activeMissionId) writeEonCityW737MissionState(activeMissionId, 'returned');
      activeMissionId = String(source?.snapshot?.activeMissionId || '');
      activeStationId = restoredStationId;
      missionsProgression.refresh?.('workspace-return');
      ui?.updateMissions?.();
      livingNexus.refresh?.('workspace-return');
      const activeNpc = stationState.get(openedStationId);
      activeNpc?.loadedNpc?.animations?.playStationary?.('idle');
      if (activeNpc) {
        activeNpc.npcGestureState = 'idle';
        activeNpc.npcGestureUntil = 0;
        activeNpc.nextNpcGestureAt = now() + 4_500 + activeNpc.station.priority * 530;
        if (activeNpc.npcRoute) {
          activeNpc.npcRoute.suspendedUntil = now() + 1_200;
          activeNpc.npcRoute.animationState = 'idle';
          activeNpc.npcRoute.moving = false;
        }
      }
      canvas.focus?.({ preventScroll: true });
    }
  });

  const openSurfaceForStation = (stationId, trigger = null, overrideSurface = '') => {
    if (workspacePresenter.getState().active || workspacePresenter.getState().pending || workSurfaceOpen) return freeze({ ok: false, reason: 'work-surface-already-opening' });
    const station = getEonCityW731Station(stationId);
    if (!station) return freeze({ ok: false, reason: 'station-not-found' });
    const surface = overrideSurface || (station.id === 'eonbot-nexus' ? 'nexus' : station.id === 'command-console' ? 'command-centre' : station.id === 'automation-theatre' ? 'agent-theatre' : station.surface);
    const rawPart = String(trigger?.interactionPart || trigger?.dataset?.eonCityInteractionPart || (trigger?.nodeType ? 'ui' : 'structure')).slice(0, 80);
    const nexusRingId = String(trigger?.nexusRingId || (rawPart.startsWith('nexus-ring:') ? rawPart.slice('nexus-ring:'.length) : '')).slice(0, 40);
    const commandWallId = String(trigger?.commandWallId || (rawPart.startsWith('command-wall:') ? rawPart.slice('command-wall:'.length) : (station.id === 'automation-theatre' ? 'agent-theatre' : ''))).slice(0, 40);
    const interactionPart = rawPart === 'terminal' ? 'terminal' : rawPart === 'npc' ? 'npc' : nexusRingId ? 'nexus-ring' : commandWallId ? 'command-wall' : 'structure';
    const interactionSource = String(trigger?.interactionSource || (trigger?.nodeType ? 'city-ui' : 'city-3d')).slice(0, 40);
    if (nexusRingId) livingNexus.inspectRing?.(nexusRingId);
    if (commandWallId) commandCentre.inspectWall?.(commandWallId);
    const interaction = (nexusRingId ? interactionRegistry.get(`nexus-ring:${nexusRingId}`) : null)
      || (commandWallId ? interactionRegistry.get(`command-wall:${commandWallId}`) : null)
      || interactionRegistry.getStation(station.id, interactionPart)
      || interactionRegistry.getStation(station.id, 'structure');
    productiveStations.reviewStation?.(station.id, { explicitUserAction: true });
    const stationWorkLoop = productiveStations.getStation?.(station.id) || null;
    const result = workspacePresenter.begin({
      station,
      interaction,
      surface,
      trigger,
      context: freeze({
        type: 'city',
        citySource: 'eon-city-command-hub',
        stationId: station.id,
        stationWorkLoop,
        missionsProgression: missionsProgression.getView?.() || null,
        npcName: station.npc.name,
        npcRole: station.npc.role,
        interactionPart,
        interactionSource,
        nexusRingId,
        commandWallId,
        nexusView: station.id === 'eonbot-nexus' ? livingNexus.getView?.() : null,
        commandCentreView: ['command-console', 'automation-theatre'].includes(station.id) ? commandCentre.getView?.() : null
      })
    });
    if (!result.ok) return result;
    productiveStations.markOpened?.(station.id, { explicitUserAction: true });
    activeStationId = station.id;
    const mission = getEonCityW737MissionForStation(station.id);
    activeMissionId = mission?.id || '';
    if (mission) writeEonCityW737MissionState(mission.id, 'opened');
    missionsProgression.refresh?.('mission-opened');
    ui?.updateMissions?.();
    livingNexus.refresh?.('mission-opened');
    activationPulse = { stationId: station.id, until: now() + (reducedMotion ? 0 : 180) };
    const stationRecord = stationState.get(station.id);
    const interactionAnimation = interactionPart === 'terminal' ? 'interact' : 'talk';
    stationRecord?.loadedNpc?.animations?.playStationary?.(interactionAnimation, { restart: true });
    if (stationRecord) {
      stationRecord.npcGestureState = interactionAnimation;
      stationRecord.npcGestureUntil = now() + 2_400;
      stationRecord.nextNpcGestureAt = stationRecord.npcGestureUntil + 5_500 + stationRecord.station.priority * 420;
      if (stationRecord.npcRoute) {
        stationRecord.npcRoute.moving = false;
        stationRecord.npcRoute.suspendedUntil = stationRecord.npcGestureUntil;
        stationRecord.npcRoute.animationState = stationRecord.npcGestureState;
      }
    }
    writeResume(playerAnchor.position, playerAnchor.rotation.y, station.id);
    return freeze({
      ...result,
      stationId: station.id,
      surface,
      trigger: Boolean(trigger),
      interactionId: interaction?.id || '',
      interactionPart,
      interactionSource,
      nexusRingId,
      commandWallId,
      explicitUserAction: true
    });
  };

  const guideToStation = (stationId) => {
    const station = getEonCityW731Station(stationId);
    if (!station) return freeze({ ok: false, reason: 'station-not-found' });
    clearInput();
    applyPlayerPose({ x: station.focus.x, y: 0, z: station.focus.z, heading: Math.atan2(station.position.x - station.focus.x, station.position.z - station.focus.z) }, { stationId: station.id, camera: 'none' });
    focusCameraOnStation(station);
    nearestStation = resolveEonCityW731NearestStation(playerAnchor.position, 6);
    ui?.setPrompt?.(nearestStation);
    setContextualSelection(nearestStation);
    onStatus?.(`Arrived at ${station.label}. Press E or choose ${station.npc.action}.`);
    onLandmarkChange?.(freeze({ id: station.id, label: station.label, districtId: 'command-hub' }));
    return freeze({ ok: true, stationId: station.id, explicitUserAction: true, teleportedWithinClosedHub: true });
  };


  const inspectDiscovery = (discoveryId, trigger = null) => {
    const discovery = getEonCityW737Discovery(discoveryId);
    if (!discovery) return freeze({ ok: false, reason: 'discovery-not-found' });
    const mission = getEonCityW737MissionForDiscovery(discovery.id);
    if (mission) {
      activeMissionId = mission.id;
      writeEonCityW737MissionState(mission.id, 'reviewed');
      ui?.updateMissions?.();
      livingNexus.refresh?.('mission-reviewed');
    }
    onStatus?.(`${discovery.label} reviewed. ${discovery.npc.greeting}`);
    onLandmarkChange?.(freeze({ id: discovery.id, label: discovery.label, districtId: 'command-horizon', discovery: true }));
    return freeze({ ok: true, discoveryId: discovery.id, missionId: mission?.id || null, trigger: Boolean(trigger), explicitUserAction: true, noAutomaticWork: true });
  };

  const guideToDiscovery = (discoveryId) => {
    const discovery = getEonCityW737Discovery(discoveryId);
    if (!discovery) return freeze({ ok: false, reason: 'discovery-not-found' });
    clearInput();
    applyPlayerPose({ x: discovery.focus.x, y: 0, z: discovery.focus.z, heading: Math.atan2(discovery.position.x - discovery.focus.x, discovery.position.z - discovery.focus.z) }, { stationId: '', save: true, camera: 'follow' });
    nearestDiscovery = resolveEonCityW737NearestDiscovery(playerAnchor.position, 6);
    ui?.setPrompt?.(nearestDiscovery);
    setContextualSelection(nearestDiscovery);
    onStatus?.(`Arrived at ${discovery.label}. Press E or choose ${discovery.npc.action}.`);
    onLandmarkChange?.(freeze({ id: discovery.id, label: discovery.label, districtId: 'command-horizon', discovery: true }));
    return freeze({ ok: true, discoveryId: discovery.id, explicitUserAction: true, teleportedWithinBoundedMap: true });
  };

  const focusCommandWall = (trigger = null) => {
    clearInput('command-wall-focus');
    applyCameraPose(EON_CITY_W760_CAMERA_POSES.commandWall, 'command-wall-focus');
    commandCentre.refresh?.('explicit-command-wall-focus');
    commandCentre.inspectWall?.('work');
    onStatus?.('Five live Command Centre monitors focused. Select a screen to inspect its verified information.');
    return freeze({ ok: true, trigger: Boolean(trigger), explicitUserAction: true, cameraMode: 'command-wall-focus', monitorCount: 5 });
  };

  const resumeLocation = () => {
    const resume = readResume();
    if (!resume) { onStatus?.('No saved City location is available yet.'); return freeze({ ok: false, reason: 'resume-unavailable' }); }
    applyPlayerPose({ ...resume.player, heading: resume.heading }, { stationId: resume.stationId, save: false, camera: 'follow' });
    onStatus?.('Your last Command Hub location is restored on this device.');
    return freeze({ ok: true, resume });
  };

  const resetView = () => {
    clearInput();
    activeStationId = '';
    applyPlayerPose(EON_CITY_W731_SPAWN, { stationId: '', save: true, camera: 'arrival' });
    onStatus?.('Returned to the Living Command Centre arrival point.');
    return freeze({ ok: true });
  };

  const showVerifiedReaction = (reaction = null) => {
    if (!reaction) return false;
    ui?.showReaction?.(reaction);
    onStatus?.(reaction.label || 'Command Core updated.');
    if (['mission-complete', 'vault-reveal'].includes(reaction.kind)) environmentController.cue?.('confirm');
    return true;
  };
  const claimMissionWithReaction = (stationId, { explicitUserAction = true } = {}) => {
    const result = missionsProgression.claimMission?.(stationId, { explicitUserAction }) || freeze({ ok: false, reason: 'missions-progression-unavailable' });
    const receipt = rewardReactionController?.noteMissionClaim?.(result);
    if (receipt?.ok) showVerifiedReaction(receipt.reaction);
    ui?.updateMissions?.();
    livingNexus.refresh?.('mission-claimed');
    return result;
  };
  const openRevealWithReaction = ({ explicitUserAction = true } = {}) => {
    const result = missionsProgression.openVaultReveal?.({ explicitUserAction }) || freeze({ ok: false, reason: 'missions-progression-unavailable' });
    const receipt = rewardReactionController?.noteVaultReveal?.(result);
    if (receipt?.ok) showVerifiedReaction(receipt.reaction);
    ui?.updateMissions?.();
    livingNexus.refresh?.('vault-reveal-opened');
    return result;
  };

  ui = createCommandHubUi(productRoot, stationState, discoveryState, {
    onOpenStation: openSurfaceForStation,
    onGuideStation: guideToStation,
    onFocusMonitors: focusCommandWall,
    onInspectDiscovery: inspectDiscovery,
    onGuideDiscovery: guideToDiscovery,
    onResume: resumeLocation,
    onReset: resetView,
    onRestart: () => productRoot.querySelector?.('[data-eon-city-retry-3d]')?.click?.(),
    onOpenCapture: (trigger) => openSurfaceForStation('share-capture', trigger, 'creator-capture'),
    onOpenShare: (trigger) => openSurfaceForStation('share-capture', trigger, 'share'),
    onOpenNexus: (trigger) => openSurfaceForStation('eonbot-nexus', trigger, 'nexus'),
    getMissionView: () => missionsProgression.getView?.() || {},
    onClaimMission: (stationId) => claimMissionWithReaction(stationId, { explicitUserAction: true }),
    onOpenReveal: () => openRevealWithReaction({ explicitUserAction: true }),
    onInspectInteraction: inspectInteraction,
    getInteraction: (target = null) => target?.kind === 'station'
      ? interactionRegistry.getStation(target?.entity?.id, 'structure')
      : interactionRegistry.get(`discovery:${target?.entity?.id || ''}`)
  });
  nexusReactionController = createEonCityW762NexusReactionController({
    environment: globalThis,
    now: Date.now,
    onReaction: (reaction) => {
      latestNexusReaction = reaction;
      showVerifiedReaction(reaction);
    }
  });
  rewardReactionController = createEonCityW764RewardReactionController({
    environment: globalThis,
    now: Date.now,
    onReaction: (reaction) => { latestRewardReaction = reaction; }
  });
  nexusReactionController.observe(livingNexus.getView?.() || {}, 'initial');
  onW749ViewChanged = (event) => nexusReactionController?.observe?.(event?.detail?.view || {}, event?.detail?.reason || 'source-state');
  globalThis.addEventListener?.(EON_CITY_W749_VIEW_EVENT, onW749ViewChanged);

  semanticNavigationController = createEonCityW756SemanticNavigationController({
    root: productRoot,
    environment: globalThis,
    onGuideStation: guideToStation,
    onOpenStation: (stationId, trigger) => openSurfaceForStation(stationId, trigger, 'semantic-map'),
    onInspectStation: (stationId) => {
      const station = getEonCityW731Station(stationId);
      const interaction = interactionRegistry.getStation(stationId, 'structure');
      onStatus?.(interaction?.inspectText || station?.description || `${station?.label || 'Station'} is available through the maintained City Dock.`);
      return freeze({ ok: Boolean(station), stationId, automaticWork: false, privateDataRead: false });
    },
    onSetEnvironment: (next, options) => {
      const result = environmentController.setProfile(next, options);
      if (result.ok) applyW755EnvironmentPlan({ scene, hemisphere, direction, world, plan: environmentController.getPlan() });
      return result;
    },
    onActivateAudio: (options) => {
      environmentController.setAudioPreferences({ ambience: true, ui: true, voice: false, music: false, reducedSensory: Boolean(reducedMotion) }, options);
      return environmentController.activateAudio(options);
    },
    onOpenNexus: (trigger) => openSurfaceForStation('eonbot-nexus', trigger, 'w756-onboarding'),
    onMenuOpen: () => clearInput('city-menu-open'),
    onOpenMenu: (trigger) => ui?.openMenu?.(trigger || canvas),
    onStatus: (message) => onStatus?.(message)
  });

  const setContextualSelection = (target = null) => {
    const stationId = String(target?.station?.id || '');
    const discoveryId = String(target?.discovery?.id || '');
    for (const record of stationState.values()) record.selectionRing?.setEnabled?.(record.station.id === stationId);
    for (const record of discoveryState.values()) record.selectionRing?.setEnabled?.(record.discovery.id === discoveryId);
    productRoot.dataset.eonCitySelectedInteraction = stationId
      ? `station:${stationId}`
      : discoveryId ? `discovery:${discoveryId}` : '';
    return productRoot.dataset.eonCitySelectedInteraction;
  };

  const isEditableTarget = (node) => {
    if (!node) return false;
    const tag = String(node.tagName || '').toLowerCase();
    if (['input', 'textarea', 'select'].includes(tag) || node.isContentEditable) return true;
    try { return Boolean(node.closest?.('input, textarea, select, [contenteditable="true"], [role="textbox"]')); } catch { return false; }
  };
  const isTyping = (event = null) => isEditableTarget(event?.target) || isEditableTarget(globalThis.document?.activeElement);
  const workSurfaceHostVisible = () => {
    const host = globalThis.document?.querySelector?.('[data-eon-work-surface-host]');
    return Boolean(host && host.hidden !== true);
  };
  const reconcileWorkspacePause = () => {
    if (!workSurfaceOpen || now() - workSurfaceOpenedAt < 750 || workSurfaceHostVisible()) return false;
    const state = workspacePresenter.getState();
    if (state.active || state.pending) workspacePresenter.cancelPending('hidden-work-surface-reconcile');
    if (workSurfaceOpen && !workSurfaceHostVisible()) {
      workSurfaceOpen = false;
      workSurfaceOpenedAt = 0;
      ui?.setPaused?.(manualPaused);
    }
    return true;
  };
  const onKeyDown = (event) => {
    if (destroyed) return;
    keydownEvents += 1;
    reconcileWorkspacePause();
    const keyboardCode = resolveEonCityW719KeyboardCode(event);
    const directionName = KEY_TO_DIRECTION[keyboardCode];
    const rawEvent = () => freeze({ type: 'keydown', key: String(event?.key || ''), code: String(event?.code || ''), resolvedCode: keyboardCode, targetTag: String(event?.target?.tagName || '').toLowerCase(), targetEditable: isEditableTarget(event?.target), activeElementTag: String(globalThis.document?.activeElement?.tagName || '').toLowerCase(), accepted: false, reason: 'unresolved', at: Date.now() });
    if (directionName) {
      const blockedReason = isTyping(event) ? 'editable-target' : getMovementBlockReason();
      if (blockedReason) {
        lastInputEvent = freeze({ source: keyboardCode, direction: directionName, active: true, accepted: false, reason: blockedReason, at: Date.now() });
        lastRawKeyboardEvent = freeze({ ...rawEvent(), accepted: false, reason: blockedReason });
        return;
      }
      event.preventDefault();
      heldKeys.set(keyboardCode, directionName);
      setDirection(directionName, true, keyboardCode);
      lastRawKeyboardEvent = freeze({ ...rawEvent(), accepted: true, reason: 'direction-updated' });
      onInputModeChange?.({ mode: 'keyboard', source: keyboardCode });
      return;
    }
    lastRawKeyboardEvent = freeze({ ...rawEvent(), accepted: false, reason: 'unmapped-key' });
    if (workSurfaceOpen || ui?.isMenuOpen?.() || isTyping(event)) return;
    if (event.key === 'e' || event.key === 'E') {
      if (nearestStation?.station) {
        event.preventDefault();
        openSurfaceForStation(nearestStation.station.id, { interactionPart: 'proximity', interactionSource: 'keyboard' });
      } else if (nearestDiscovery?.discovery) {
        event.preventDefault();
        inspectDiscovery(nearestDiscovery.discovery.id, canvas);
      }
    }
  };
  const onKeyUp = (event) => {
    keyupEvents += 1;
    const keyboardCode = resolveEonCityW719KeyboardCode(event);
    const directionName = heldKeys.get(keyboardCode) || KEY_TO_DIRECTION[keyboardCode];
    heldKeys.delete(keyboardCode);
    if (directionName) setDirection(directionName, false, keyboardCode);
    const rawEvent = () => freeze({ type: 'keyup', key: String(event?.key || ''), code: String(event?.code || ''), resolvedCode: keyboardCode, targetTag: String(event?.target?.tagName || '').toLowerCase(), targetEditable: isEditableTarget(event?.target), activeElementTag: String(globalThis.document?.activeElement?.tagName || '').toLowerCase(), accepted: false, reason: 'unmapped-key', at: Date.now() });
    if (!directionName) { lastRawKeyboardEvent = rawEvent(); return; }
    event.preventDefault();
    lastRawKeyboardEvent = freeze({ ...rawEvent(), accepted: true, reason: 'direction-updated' });
  };
  globalThis.addEventListener?.('keydown', onKeyDown);
  globalThis.addEventListener?.('keyup', onKeyUp);
  const onWindowBlur = () => clearInput('window-blur');
  globalThis.addEventListener?.('blur', onWindowBlur);
  const restoreCanvasFocus = () => {
    reconcileWorkspacePause();
    canvas.focus?.({ preventScroll: true });
    if (cameraMode === 'arrival' || cameraMode === 'return') {
      cameraMode = 'follow';
      camera.setTarget(new Vector3(playerAnchor.position.x, EON_CITY_W747_CAMERA_POSES.follow.targetHeight, playerAnchor.position.z));
    }
  };
  canvas.addEventListener('pointerdown', restoreCanvasFocus);

  const pointerObserver = scene.onPointerObservable.add((pointerInfo) => {
    if (pointerInfo.type !== PointerEventTypes.POINTERPICK || workSurfaceOpen || ui?.isMenuOpen?.()) return;
    const metadata = pointerInfo.pickInfo?.pickedMesh?.metadata || {};
    if (metadata.transitCapsule) {
      const interaction = interactionRegistry.get('support:transit-capsule');
      onStatus?.(`${interaction?.label || 'EON Transit Capsule'}: ${interaction?.inspectText || 'Review a destination, then choose Board or Skip.'}`);
    } else if (metadata.commandWallId) {
      openSurfaceForStation('command-console', {
        interactionPart: `command-wall:${metadata.commandWallId}`,
        interactionSource: 'city-3d-command-wall',
        commandWallId: metadata.commandWallId
      }, 'command-centre');
    } else if (metadata.nexusRingId) {
      openSurfaceForStation('eonbot-nexus', {
        interactionPart: `nexus-ring:${metadata.nexusRingId}`,
        interactionSource: 'city-3d-nexus-ring',
        nexusRingId: metadata.nexusRingId
      }, 'nexus');
    } else if (metadata.stationId) {
      openSurfaceForStation(metadata.stationId, {
        interactionPart: metadata.interactionRole || metadata.part || 'structure',
        interactionSource: 'city-3d-pick'
      });
    } else if (metadata.discoveryId) inspectDiscovery(metadata.discoveryId, canvas);
  });

  const onResize = () => engine.resize();
  globalThis.addEventListener?.('resize', onResize);
  const onContextLost = (event) => {
    event?.preventDefault?.();
    contextLost = true;
    contextLossCount += 1;
    reliabilityController.noteContextLoss();
    clearInput();
    onStatus?.('City graphics paused safely. Use Restart 3D if the browser does not restore the scene.');
    onContextLoss?.({ code: 'CITY_WEBGL_CONTEXT_LOST', recoverable: true, recoveryAction: 'restart-3d', contextLossCount });
  };
  const handleContextRestored = () => {
    contextLost = false;
    movementRenderRecovery?.resetHeartbeats?.();
    contextRestoreCount += 1;
    reliabilityController.noteContextRestore();
    lastFrameAt = now();
    try { engine.resize(); } catch {}
    onStatus?.('City graphics restored. Your local position and work state were preserved.');
    onContextRestored?.({ code: 'CITY_WEBGL_CONTEXT_RESTORED', recovered: true, contextRestoreCount });
  };
  canvas.addEventListener('webglcontextlost', onContextLost, false);
  canvas.addEventListener('webglcontextrestored', handleContextRestored, false);
  const onVisibilityChange = () => {
    documentHidden = globalThis.document?.visibilityState === 'hidden';
    if (documentHidden) { clearInput(); environmentController.stopAudio('tab-hidden'); }
    else {
      lastFrameAt = now();
      movementRenderRecovery?.resetHeartbeats?.();
      try { engine.resize(); } catch {}
    }
  };
  globalThis.document?.addEventListener?.('visibilitychange', onVisibilityChange);
  const onPageHide = () => writeResume(playerAnchor.position, playerAnchor.rotation.y, activeStationId);
  globalThis.addEventListener?.('pagehide', onPageHide);

  const applyPerformanceProtection = (reason = 'manual') => {
    const previous = currentHardwareScalingLevel;
    const next = Math.min(maxHardwareScalingLevel, Number((previous + 0.2).toFixed(2)));
    if (next > previous + 0.001) {
      currentHardwareScalingLevel = next;
      performanceProtectionLevel += 1;
      engine.setHardwareScalingLevel?.(currentHardwareScalingLevel);
      try { engine.resize(); } catch {}
    }
    const changed = next > previous + 0.001;
    const result = freeze({
      ok: true,
      changed,
      reason: String(reason || 'manual'),
      level: performanceProtectionLevel,
      hardwareScalingLevel: currentHardwareScalingLevel,
      quality: resolvedQuality
    });
    if (changed) {
      reliabilityController.notePerformanceProtection();
      onPerformanceChange?.({ ...result, message: `Command Hub performance protection reduced render load (${reason}).` });
    }
    return result;
  };

  const startProgressiveAssets = async () => {
    reliabilityController.recordStage('deferred-stages-started');
    const enableLoadedInteraction = (loaded, metadata, collisions = true) => {
      if (!isEonCityW759PresentationReady(loaded)) return false;
      for (const mesh of loaded.container?.meshes || []) {
        if (!mesh || mesh === loaded.container?.rootNodes?.[0]) continue;
        mesh.isPickable = true;
        mesh.checkCollisions = Boolean(collisions);
        mesh.metadata = freeze({ ...(mesh.metadata || {}), ...metadata, interactive: true, explicitUserActionRequired: true });
      }
      return true;
    };
    const hideNodes = (nodes = []) => {
      for (const node of nodes || []) {
        try { node.setEnabled?.(false); } catch {}
      }
    };
    const hideProceduralStructure = (record) => hideNodes((record?.fallbackVisualNodes || []).filter((node) => node !== record?.base));
    try {
      const module = await import('./eon-city-w731-local-assets.js');
      if (destroyed) return;
      localAssetRuntime = module.createEonCityW731LocalAssetRuntime({
        scene,
        commandCoreConvergence: freeze({
      schema: EON_CITY_W760_W765_SCHEMA,
      validation: commandCoreConvergenceValidation,
      interactionCompleteness,
      menuOrder: EON_CITY_W763_MENU_ORDER,
      cameraPoses: EON_CITY_W760_CAMERA_POSES,
      nexusReaction: nexusReactionController?.getSnapshot?.() || null,
      rewardReaction: rewardReactionController?.getSnapshot?.() || null,
      oneNexusAuthority: EON_CITY_W749_LIVING_NEXUS_SCHEMA,
      oneMissionAuthority: EON_CITY_W752_SCHEMA,
      fakeLiveData: false,
      secondRuntime: false
    }),
    quality: resolvedQuality,
        qualityAuthority: resolvedQualityAuthority,
        onProgress: (event) => onAssetProgress?.(event),
        onStatus: (message) => onStatus?.(message)
      });

      stage('AUTHORED_VISIBLE_FRAME_LOADING', 'command-centre-core-and-hero-cast');
      const environmentLoads = EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame.coreAssetAliases.map(async (alias) => {
        const anchor = world.environmentAnchors.get(alias);
        if (!anchor) return freeze({ ok: false, alias, reason: 'environment-anchor-missing' });
        const loaded = await localAssetRuntime.loadEnvironment(alias, anchor);
        if (isEonCityW759PresentationReady(loaded)) {
          if (alias === 'living-nexus-core') {
            const nexusRecord = stationState.get('eonbot-nexus');
            if (nexusRecord) nexusRecord.loadedWorld = loaded;
            hideProceduralStructure(nexusRecord);
            enableLoadedInteraction(loaded, stationMetadata(getEonCityW731Station('eonbot-nexus'), { part: 'structure', interactionRole: 'structure', authored: true }), true);
            spatialDiagnostics.unregisterLoadedAsset('fallback:station:eonbot-nexus');
            registerLoadedSpatialAsset('authored:living-nexus-core', loaded, {
              primaryRole: 'living-nexus-core', groupId: 'eonbot-nexus', allowHeroZone: true, allowArrivalRay: true
            });
          } else if (alias === 'command-seat') {
            enableLoadedInteraction(loaded, stationMetadata(getEonCityW731Station('command-console'), {
              part: 'command-wall:work', interactionRole: 'structure', commandWallId: 'work', authored: true,
              accessibilityLabel: 'Open the live Work command monitor from the Command Seat'
            }), true);
            registerLoadedSpatialAsset('authored:command-seat', loaded, {
              primaryRole: 'command-seat', groupId: 'operations-crescent'
            });
          } else if (alias === 'district-hologram') {
            enableLoadedInteraction(loaded, stationMetadata(getEonCityW731Station('command-console'), {
              part: 'command-wall:atlas-transit', interactionRole: 'structure', commandWallId: 'atlas-transit', authored: true,
              accessibilityLabel: 'Open the live Atlas and Transit command monitor'
            }), false);
            registerLoadedSpatialAsset('authored:district-hologram', loaded, {
              primaryRole: 'district-hologram', groupId: 'operations-crescent'
            });
          } else if (alias === 'eonbot-dock') {
            enableLoadedInteraction(loaded, stationMetadata(getEonCityW731Station('eonbot-nexus'), {
              part: 'structure', interactionRole: 'structure', dock: true, authored: true,
              accessibilityLabel: 'Open the Living EONBOT Nexus from its authored dock'
            }), false);
            world.dock.setEnabled?.(false);
            spatialDiagnostics.unregisterLoadedAsset('procedural:eonbot-dock');
            registerLoadedSpatialAsset('authored:eonbot-dock', loaded, {
              primaryRole: 'eonbot-dock', groupId: 'living-nexus-support', allowHeroZone: true, allowArrivalRay: true
            });
          }
        }
        return freeze({ alias, ok: isEonCityW759PresentationReady(loaded), record: loaded });
      });
      const heroCharacterLoad = Promise.all([
        localAssetRuntime.loadCore('player-primary', playerAnchor),
        localAssetRuntime.loadCore('eonbot', eonbotAnchor)
      ]);
      const [environmentResults, heroCharacters] = await Promise.all([Promise.all(environmentLoads), heroCharacterLoad]);
      if (destroyed) return;
      const [loadedPlayer, loadedEonbot] = heroCharacters;
      playerAsset = loadedPlayer;
      eonbotAsset = loadedEonbot;
      if (isEonCityW759PresentationReady(playerAsset)) {
        fallbackPlayer.root.setEnabled(false);
        playerAsset.animations?.play?.('idle');
      }
      if (isEonCityW759PresentationReady(eonbotAsset)) {
        eonbotFallback.setEnabled(false);
        eonbotRing.setEnabled(false);
        enableLoadedInteraction(eonbotAsset, stationMetadata(getEonCityW731Station('eonbot-nexus'), {
          part: 'npc', interactionRole: 'npc', npcName: 'EONBOT', companion: true, authored: true
        }), false);
      }
      const authoredCoreReady = environmentResults.filter((entry) => entry.ok).length;
      const authoredHeroCharactersReady = heroCharacters.filter(isEonCityW759PresentationReady).length;
      const environmentDegraded = authoredCoreReady < EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame.requiredCoreAssetCount;
      const heroCastDegraded = authoredHeroCharactersReady < EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame.requiredCoreCharacterCount;
      const visibleFrameDegraded = environmentDegraded || heroCastDegraded;
      visibleFrameState.authoredEnvironmentReady = authoredCoreReady;
      visibleFrameState.authoredHeroCharactersReady = authoredHeroCharactersReady;
      visibleFrameState.gateComplete = true;
      visibleFrameState.degraded = visibleFrameDegraded;
      stage('AUTHORED_VISIBLE_FRAME_READY', `${authoredCoreReady}/${EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame.requiredCoreAssetCount};cast:${authoredHeroCharactersReady}/${EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame.requiredCoreCharacterCount}`);
      onInitialAssetsReady?.(freeze({
        ok: !visibleFrameDegraded,
        degraded: visibleFrameDegraded,
        authoredEnvironmentReady: authoredCoreReady,
        authoredEnvironmentRequired: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame.requiredCoreAssetCount,
        authoredHeroCharactersReady,
        authoredHeroCharactersRequired: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame.requiredCoreCharacterCount,
        brandedHeroFallbackReady: true,
        visibleFrameGateComplete: true,
        progressiveCharacterAssets: true,
        stationInteractionTriads: true
      }));
      onStatus?.(visibleFrameDegraded
        ? 'The authored Command Centre or hero cast is partly ready. Branded local fallbacks keep every route usable.'
        : 'The authored Command Centre, Pathfinder, EONBOT, 3D Nexus and arrival composition are ready.');

      const stationStructureLoads = [];
      const stationTerminalLoads = [];
      for (const station of EON_CITY_W731_STATIONS) {
        const record = stationState.get(station.id);
        if (!record) continue;
        if (station.id !== 'eonbot-nexus') {
          const alias = `${station.id}-world`;
          stationStructureLoads.push(localAssetRuntime.loadStation(alias, record.visualRoot, station.id).then((loaded) => {
            if (isEonCityW759PresentationReady(loaded)) {
              record.loadedWorld = loaded;
              hideProceduralStructure(record);
              enableLoadedInteraction(loaded, stationMetadata(station, { part: 'structure', interactionRole: 'structure', authored: true }), true);
              spatialDiagnostics.unregisterLoadedAsset(`fallback:station:${station.id}`);
              registerLoadedSpatialAsset(`authored:station:${station.id}`, loaded, {
                primaryRole: station.id, groupId: station.id
              });
            }
            return loaded;
          }));
        }
        const terminalAlias = `${station.id}-terminal`;
        stationTerminalLoads.push(localAssetRuntime.loadStationProp(terminalAlias, record.terminalAnchor, station.id).then((loaded) => {
          if (isEonCityW759PresentationReady(loaded)) {
            record.loadedTerminal = loaded;
            hideNodes(record.terminalFallbackNodes);
            enableLoadedInteraction(loaded, stationMetadata(station, { part: 'terminal', interactionRole: 'terminal', authored: true }), false);
            registerLoadedSpatialAsset(`authored:terminal:${station.id}`, loaded, { groupId: station.id });
          }
          return loaded;
        }));
      }

      const discoveryLoads = [];
      for (const discovery of EON_CITY_W737_DISCOVERIES) {
        const record = discoveryState.get(discovery.id);
        const alias = `${discovery.id}-world`;
        discoveryLoads.push(localAssetRuntime.loadDiscovery(alias, record?.visualRoot || record?.root, discovery.id).then((loaded) => {
          if (isEonCityW759PresentationReady(loaded) && record) {
            record.loadedWorld = loaded;
            hideNodes(record.fallbackVisualNodes);
            enableLoadedInteraction(loaded, discoveryMetadata(discovery, { part: 'authored-world' }), true);
            spatialDiagnostics.unregisterLoadedAsset(`fallback:discovery:${discovery.id}`);
            registerLoadedSpatialAsset(`authored:discovery:${discovery.id}`, loaded, {
              primaryRole: discovery.id, groupId: discovery.id
            });
          }
          return loaded;
        }));
      }

      const roleLoads = EON_CITY_W731_LAUNCH_ASSET_MANIFEST.roleCharacters.map(async (roleEntry) => {
        const record = stationState.get(roleEntry.stationId);
        if (!record) return freeze({ ok: false, reason: 'station-record-missing', stationId: roleEntry.stationId });
        const loaded = await localAssetRuntime.loadRole(roleEntry.stationId, record.npcAnchor);
        if (isEonCityW759PresentationReady(loaded)) {
          record.fallbackNpc.root.setEnabled(false);
          record.loadedNpc = loaded;
          enableLoadedInteraction(loaded, stationMetadata(record.station, {
            part: 'npc', interactionRole: 'npc', npcName: record.station.npc.name,
            npcAlias: roleEntry.alias, authored: true
          }), false);
          loaded.animations?.playStationary?.('idle');
          record.npcGestureState = 'idle';
          record.npcGestureUntil = 0;
          record.nextNpcGestureAt = now() + 4_000 + record.station.priority * 680;
          npcAssets.set(record.station.id, loaded);
        }
        return loaded;
      });

      const ambientLoads = [];
      const transitActor = world.ambientActors?.transit;
      const maintenanceActor = world.ambientActors?.maintenance;
      if (transitActor) {
        ambientLoads.push(localAssetRuntime.loadAmbient('transit-capsule-ambient', transitActor.anchor, 'transit-capsule').then((loaded) => {
        if (isEonCityW759PresentationReady(loaded)) {
          transitActor.loaded = loaded;
          hideNodes(transitActor.fallbackNodes);
          enableLoadedInteraction(loaded, transitActor.anchor.metadata, false);
        }
        return loaded;
        }));
      }
      if (maintenanceActor) {
        ambientLoads.push(localAssetRuntime.loadAmbient('maintenance-worker-ambient', maintenanceActor.anchor, 'maintenance-worker').then((loaded) => {
        if (isEonCityW759PresentationReady(loaded)) {
          maintenanceActor.loaded = loaded;
          maintenanceActor.fallbackPerson.root.setEnabled(false);
          loaded.animations?.play?.('walk');
        }
        return loaded;
        }));
      }
      for (const citizen of world.ambientCitizens || []) {
        ambientLoads.push(localAssetRuntime.loadAmbient(citizen.assetAlias, citizen.anchor, citizen.id).then((loaded) => {
          if (isEonCityW759PresentationReady(loaded)) {
            citizen.loaded = loaded;
            citizen.animationState = citizen.motion;
            loaded.animations?.play?.(citizen.motion, { restart: true });
          } else {
            // Empty anchor is intentional. A missing authored citizen must never
            // become a visible procedural stick figure.
            citizen.loaded = null;
          }
          return loaded;
        }));
      }
      const streetLightNetwork = world.exteriorMap;
      if (streetLightNetwork?.streetLampAnchors?.length && resolvedQuality !== 'lite') {
        const authoredAnchors = streetLightNetwork.streetLampAnchors.filter((_, index) => index % 2 === 0);
        ambientLoads.push(localAssetRuntime.loadAmbient('street-lamp-ambient', authoredAnchors[0], 'street-light-network').then((loaded) => {
          if (!isEonCityW759PresentationReady(loaded)) return loaded;
          streetLightNetwork.authoredStreetLamp = loaded;
          streetLightNetwork.proceduralLampPosts.forEach((node, index) => {
            if (index % 2 === 0) node.setEnabled?.(false);
          });
          const clones = [];
          for (let index = 1; index < authoredAnchors.length; index += 1) {
            const clone = loaded.wrapper?.clone?.(`w744-authored-street-lamp-instance-${index}`, authoredAnchors[index], false);
            if (!clone) continue;
            clone.parent = authoredAnchors[index];
            clone.position.copyFrom(loaded.wrapper.position);
            clone.rotation.copyFrom(loaded.wrapper.rotation);
            clone.scaling.copyFrom(loaded.wrapper.scaling);
            clone.metadata = freeze({ kind: 'w744-authored-street-lamp-instance', index, ambientOnly: true, interactive: false });
            for (const child of clone.getChildMeshes?.(false) || []) {
              child.isPickable = false;
              child.checkCollisions = false;
            }
            clones.push(clone);
          }
          streetLightNetwork.authoredStreetLampClones = clones;
          return loaded;
        }));
      }

      await Promise.allSettled([
        ...stationStructureLoads, ...stationTerminalLoads, ...discoveryLoads, ...roleLoads, ...ambientLoads
      ]);
      if (destroyed) return;
      reliabilityController.noteAssets(localAssetRuntime?.getSummary?.() || {});
      const spatialReport = spatialDiagnostics.getReport();
      if (!spatialReport.ok) {
        try { console.warn('[W747_SPATIAL_DIAGNOSTICS]', spatialReport); } catch {}
        onStatus?.('The City remains usable, but advanced spatial diagnostics found an authored-bound issue for local review.');
      } else onStatus?.('The Living Command Centre cast, station structures, usable terminals, transport and outside discoveries are ready on this device.');
    } catch (error) {
      visibleFrameState.authoredEnvironmentReady = 0;
      visibleFrameState.authoredHeroCharactersReady = 0;
      visibleFrameState.gateComplete = true;
      visibleFrameState.degraded = true;
      try { console.warn('[W744_AUTHORED_ASSETS_DEFERRED]', error); } catch {}
      onInitialAssetsReady?.(freeze({
        ok: false,
        degraded: true,
        authoredEnvironmentReady: 0,
        authoredHeroCharactersReady: 0,
        brandedHeroFallbackReady: true,
        visibleFrameGateComplete: true,
        stationInteractionTriads: true
      }));
      onStatus?.('The City remains usable with deliberate branded structures and terminals while authored character assets recover. Missing NPC assets remain hidden rather than becoming procedural figures.');
    }
  };

  const applyProceduralWalk = (person, seconds, phase = 0, speed = 1) => {
    const rig = person?.rig;
    if (!rig) return;
    const cadence = seconds * 5.1 * Math.max(0.5, speed) + phase;
    const stride = reducedMotion ? 0 : Math.sin(cadence);
    rig.leftLeg.rotation.x = stride * 0.46;
    rig.rightLeg.rotation.x = -stride * 0.46;
    rig.leftArm.rotation.x = -stride * 0.36;
    rig.rightArm.rotation.x = stride * 0.36;
    rig.leftArm.rotation.z = -0.08;
    rig.rightArm.rotation.z = 0.08;
    rig.head.rotation.y = reducedMotion ? 0 : Math.sin(cadence * 0.5) * 0.045;
    rig.body.rotation.x = 0.025;
  };

  const applyProceduralStationary = (record, person, seconds, phase = 0) => {
    const rig = person?.rig;
    if (!rig) return;
    const gesture = record?.npcGestureState || 'idle';
    const conversational = gesture === 'talk' || gesture === 'interact';
    const wave = gesture === 'wave';
    const inspect = gesture === 'inspect';
    const pose = gesture === 'pose';
    const idleAlt = gesture === 'idle-alt';
    const cadence = seconds * (conversational ? 3.1 : 1.15) + phase;
    rig.head.rotation.y = inspect
      ? -0.26 + Math.sin(seconds * 0.55 + phase) * 0.08
      : Math.sin(seconds * (idleAlt ? 0.46 : 0.72) + phase) * (conversational ? 0.16 : idleAlt ? 0.13 : 0.08);
    rig.head.rotation.x = inspect ? -0.075 : Math.sin(seconds * 0.9 + phase) * (idleAlt ? 0.04 : 0.025);
    rig.leftArm.rotation.x = pose ? -0.34 : inspect ? -0.18 : conversational ? -0.28 + Math.sin(cadence) * 0.18 : Math.sin(cadence) * (idleAlt ? 0.085 : 0.045);
    rig.rightArm.rotation.x = wave ? -0.2 : pose ? -0.72 : inspect ? -0.34 : conversational ? -0.3 - Math.sin(cadence) * 0.18 : -Math.sin(cadence) * (idleAlt ? 0.085 : 0.045);
    rig.leftArm.rotation.z = pose ? -0.62 : -0.08 - (conversational ? Math.sin(cadence * 0.7) * 0.08 : 0);
    rig.rightArm.rotation.z = wave ? -1.78 + Math.sin(seconds * 7 + phase) * 0.22 : pose ? 0.62 : inspect ? 0.28 : 0.08 + (conversational ? Math.sin(cadence * 0.7) * 0.08 : 0);
    rig.leftLeg.rotation.x = 0;
    rig.rightLeg.rotation.x = 0;
    rig.body.rotation.x = 0;
  };

  const setStationNpcAnimation = (record, state, { stationary = false, restart = false } = {}) => {
    if (!record?.npcRoute) return false;
    if (record.npcRoute.animationState === state && !restart) return true;
    const animations = record.loadedNpc?.animations;
    const accepted = animations
      ? (stationary ? animations.playStationary?.(state, { restart }) : animations.play?.(state, { restart }))
      : true;
    if (accepted !== false) record.npcRoute.animationState = state;
    return accepted !== false;
  };

  const updateStationNpcRoute = (record, timeMs) => {
    const route = record?.npcRoute;
    if (!route?.enabled) return false;
    const suspended = reducedMotion || route.suspendedUntil > timeMs || record.npcGestureUntil > timeMs;
    const snapshot = w754NpcScheduleController.update(record.station.id, timeMs, { suspended });
    if (!snapshot?.ok) return false;
    const previous = record.npcAnchor.position.clone();
    record.npcAnchor.position.set(snapshot.position.x, snapshot.position.y, snapshot.position.z);
    const dx = record.npcAnchor.position.x - previous.x;
    const dz = record.npcAnchor.position.z - previous.z;
    const step = Math.hypot(dx, dz);
    const moved = snapshot.moving && step > 0.0001;
    route.phase = snapshot.phase;
    route.moving = moved;
    route.actualDistanceTravelled += step;
    if (moved) {
      record.npcAnchor.rotation.y = snapshot.heading;
      if (route.moving) setStationNpcAnimation(record, 'walk');
      record.npcGestureState = 'idle';
      return true;
    }
    const stationaryState = snapshot.animation === 'interact' ? 'interact' : (record.npcGestureState || 'idle');
    setStationNpcAnimation(record, stationaryState, { stationary: true });
    return false;
  };

  const updateMaintenanceActor = (timeMs, seconds) => {
    const actor = world.ambientActors?.maintenance;
    if (!actor) return;
    const deltaSeconds = actor.lastAt > 0 ? Math.min(0.05, Math.max(0.001, (timeMs - actor.lastAt) / 1000)) : 0.016;
    actor.lastAt = timeMs;
    if (reducedMotion) {
      actor.moving = false;
      actor.loaded?.animations?.playStationary?.('idle');
      return;
    }
    if (actor.phase === 'dwell-terminal' || actor.phase === 'dwell-home') {
      actor.moving = false;
      const atTerminal = actor.phase === 'dwell-terminal';
      actor.loaded?.animations?.playStationary?.(atTerminal ? 'interact' : 'idle');
      if (timeMs < actor.phaseUntil) return;
      actor.phase = atTerminal ? 'walk-home' : 'walk-terminal';
      actor.loaded?.animations?.play?.('walk', { restart: true });
    }
    const target = actor.phase === 'walk-terminal' ? actor.terminal : actor.home;
    const delta = target.subtract(actor.anchor.position);
    const distance = delta.length();
    if (distance <= 0.035) {
      actor.anchor.position.copyFrom(target);
      const atTerminal = actor.phase === 'walk-terminal';
      actor.phase = atTerminal ? 'dwell-terminal' : 'dwell-home';
      actor.phaseUntil = timeMs + (atTerminal ? 4_200 : 3_600);
      actor.moving = false;
      actor.loaded?.animations?.playStationary?.(atTerminal ? 'interact' : 'idle', { restart: true });
      return;
    }
    const direction = delta.scale(1 / Math.max(0.001, distance));
    const step = Math.min(distance, actor.speed * deltaSeconds);
    actor.anchor.position.addInPlace(direction.scale(step));
    actor.anchor.rotation.y = Math.atan2(direction.x, direction.z);
    actor.moving = step > 0.0001;
    if (actor.animationState !== 'walk') {
      actor.animationState = 'walk';
      actor.loaded?.animations?.play?.('walk', { restart: true });
    }
    actor.loaded?.animations?.stabilize?.();
  };

  const updateAnimatedWorld = (timeMs) => {
    const seconds = timeMs * 0.001;
    const epochNow = Date.now();
    world.orientationRing.rotation.z += reducedMotion ? 0 : 0.0018;
    for (const entry of world.environment?.skylineWindowRows || []) {
      const pulse = reducedMotion ? 0.82 : 0.72 + (Math.sin(seconds * (entry.tier === 'near' ? 0.82 : 0.48) + entry.phase) + 1) * 0.12;
      entry.node.visibility = pulse;
      entry.node.scaling.x = reducedMotion ? 1 : 0.92 + Math.sin(seconds * 0.34 + entry.phase) * 0.08;
    }
    for (const transitEntry of world.environment?.skylineTransit || []) {
      const angle = transitEntry.phase + (reducedMotion ? 0 : seconds * transitEntry.speed);
      transitEntry.node.position.set(Math.sin(angle) * transitEntry.radius, transitEntry.height + (reducedMotion ? 0 : Math.sin(seconds * 0.55 + transitEntry.phase) * 0.25), Math.cos(angle) * transitEntry.radius);
      transitEntry.node.rotation.y = angle;
    }
    for (const [index, halo] of (world.environment?.stationSocketHalos || []).entries()) {
      if (!reducedMotion) halo.rotation.z += 0.0015 + (index % 3) * 0.00035;
      halo.visibility = reducedMotion ? 0.7 : 0.62 + (Math.sin(seconds * 0.9 + index * 0.7) + 1) * 0.12;
    }
    const nexusReaction = latestNexusReaction?.expiresAt > epochNow ? latestNexusReaction : null;
    for (const [index, ring] of (world.environment?.reactions?.nexusRings || []).entries()) {
      const active = Boolean(nexusReaction);
      ring.setEnabled(active);
      if (!active) continue;
      const intensity = Number(nexusReaction.intensity || 0.7);
      const phase = seconds * (1.7 + index * 0.33) + index * 1.2;
      ring.rotation.z = reducedMotion ? index * 0.2 : phase;
      ring.scaling.setAll(1 + (reducedMotion ? 0 : Math.sin(phase * 1.4) * 0.055 * intensity));
      ring.visibility = 0.42 + intensity * 0.45;
    }
    const rewardReaction = latestRewardReaction?.expiresAt > epochNow ? latestRewardReaction : null;
    const rewardNodes = world.environment?.reactions?.rewardBurstNodes || [];
    const rewardProgress = rewardReaction ? Math.max(0, Math.min(1, (epochNow - rewardReaction.at) / Math.max(1, rewardReaction.expiresAt - rewardReaction.at))) : 0;
    for (const [index, spark] of rewardNodes.entries()) {
      const active = Boolean(rewardReaction);
      spark.setEnabled(active);
      if (!active) continue;
      const angle = (index / Math.max(1, rewardNodes.length)) * TAU + (reducedMotion ? 0 : rewardProgress * TAU * 1.35);
      const radius = 0.35 + rewardProgress * (2.1 + (index % 4) * 0.18);
      spark.position.set(Math.sin(angle) * radius, 0.55 + Math.sin(angle * 2 + index) * 0.34 + rewardProgress * 1.35, Math.cos(angle) * radius);
      const scale = Math.max(0.18, 1 - rewardProgress * 0.82);
      spark.scaling.setAll(scale);
      spark.visibility = Math.max(0.08, 1 - rewardProgress);
    }
    for (const pulse of world.circuitPulses || []) {
      const progress = reducedMotion ? pulse.phase : (seconds * pulse.speed + pulse.phase) % 1;
      pulse.node.position.set(
        pulse.from.x + (pulse.to.x - pulse.from.x) * progress,
        pulse.from.y + (pulse.to.y - pulse.from.y) * progress,
        pulse.from.z + (pulse.to.z - pulse.from.z) * progress
      );
      const pulseScale = reducedMotion ? 0.72 : 0.72 + Math.sin((progress * TAU) + pulse.phase * TAU) * 0.18;
      pulse.node.scaling.setAll(Math.max(0.5, pulseScale));
    }
    for (const record of stationState.values()) {
      const stationDistance = Math.hypot(
        Number(record.root?.position?.x || 0) - Number(playerAnchor.position.x || 0),
        Number(record.root?.position?.z || 0) - Number(playerAnchor.position.z || 0)
      );
      const animateStation = reliabilityController.shouldUpdateAnimation({ id: `station:${record.station.id}`, distance: stationDistance, at: timeMs });
      const npcMoving = animateStation ? updateStationNpcRoute(record, timeMs) : Boolean(record.npcRoute?.moving);
      for (const entry of record.animated) {
        if (!entry.node || entry.node.isDisposed?.() || !animateStation) continue;
        if (entry.kind === 'float' && !reducedMotion) entry.node.position.y = entry.baseY + Math.sin(seconds * 1.25 + entry.phase) * 0.1;
        else if (entry.kind === 'ring-a' && !reducedMotion) entry.node.rotation.z += 0.0035;
        else if (entry.kind === 'ring-b' && !reducedMotion) entry.node.rotation.y -= 0.0026;
        else if (entry.kind === 'pulse' && !reducedMotion) entry.node.scaling.setAll(1 + Math.sin(seconds * 1.6 + entry.phase) * 0.035);
        else if (entry.kind === 'npc-idle') {
          if (npcMoving) {
            entry.node.position.y = Math.abs(Math.sin(seconds * 5.1 + entry.phase)) * 0.025;
            entry.node.rotation.z = 0;
            if (!isEonCityW759PresentationReady(record.loadedNpc)) applyProceduralWalk(entry.person, seconds, entry.phase, record.npcRoute.speed);
          } else if (!reducedMotion) {
            entry.node.position.y = entry.baseY + Math.sin(seconds * 1.05 + entry.phase) * 0.025;
            entry.node.rotation.z = Math.sin(seconds * 0.55 + entry.phase) * 0.012;
            if (!isEonCityW759PresentationReady(record.loadedNpc)) applyProceduralStationary(record, entry.person, seconds, entry.phase);
          } else if (!isEonCityW759PresentationReady(record.loadedNpc)) applyProceduralStationary(record, entry.person, seconds, entry.phase);
        }
      }

      const routeAtTerminal = record.npcRoute?.phase === 'dwell-terminal';
      if (animateStation && !npcMoving && !routeAtTerminal) {
        const npcAnimations = record.loadedNpc?.animations;
        if (record.npcGestureUntil > 0 && timeMs >= record.npcGestureUntil) {
          npcAnimations?.playStationary?.('idle');
          record.npcGestureState = 'idle';
          record.npcGestureUntil = 0;
          record.npcRoute.animationState = 'idle';
        } else if (record.npcGestureUntil <= 0 && timeMs >= record.nextNpcGestureAt) {
          const gesture = STATIONARY_NPC_GESTURES[(record.station.priority - 1) % STATIONARY_NPC_GESTURES.length];
          const gestureAccepted = npcAnimations ? npcAnimations.playStationary?.(gesture, { restart: true }) : true;
          if (gestureAccepted) {
            record.npcGestureState = gesture;
            record.npcGestureUntil = timeMs + 1_850 + (record.station.priority % 3) * 260;
            record.npcRoute.animationState = gesture;
          }
          record.nextNpcGestureAt = timeMs + 7_500 + record.station.priority * 610;
        }
      }
      if (animateStation) record.loadedNpc?.animations?.stabilize?.();
      const active = activationPulse?.stationId === record.station.id && activationPulse.until > timeMs;
      const scale = active && !reducedMotion ? 1.08 + Math.sin(seconds * 24) * 0.04 : 1;
      record.root.scaling.setAll(scale);
    }

    for (const citizen of world.ambientCitizens || []) {
      if (!isEonCityW759PresentationReady(citizen.loaded)) continue;
      const citizenDistance = Math.hypot(
        Number(citizen.anchor?.position?.x || 0) - Number(playerAnchor.position.x || 0),
        Number(citizen.anchor?.position?.z || 0) - Number(playerAnchor.position.z || 0)
      );
      if (!reliabilityController.shouldUpdateAnimation({ id: `ambient-citizen:${citizen.id}`, distance: citizenDistance, at: timeMs })) continue;
      const angle = citizen.startAngle + (reducedMotion ? 0 : citizen.direction * ((seconds * citizen.speed) / citizen.radius));
      citizen.anchor.position.set(Math.sin(angle) * citizen.radius, 0, Math.cos(angle) * citizen.radius);
      citizen.anchor.rotation.y = Math.atan2(citizen.direction * Math.cos(angle), citizen.direction * -Math.sin(angle));
      const desiredAnimation = reducedMotion ? 'idle' : citizen.motion;
      if (desiredAnimation !== citizen.animationState) {
        citizen.animationState = desiredAnimation;
        if (desiredAnimation === 'idle') citizen.loaded.animations?.playStationary?.('idle', { restart: true });
        else citizen.loaded.animations?.play?.(desiredAnimation, { restart: true });
      }
      citizen.loaded.animations?.stabilize?.();
    }

    const transit = world.ambientActors?.transit;
    if (transit) {
      const transitState = w754TransitController.update(timeMs);
      if (transitState?.pose && ['active', 'complete'].includes(transitState.status)) {
        transit.anchor.position.set(transitState.pose.position.x, transitState.pose.position.y, transitState.pose.position.z);
        transit.anchor.rotation.y = transitState.pose.rotationY;
      } else {
        const angle = transit.startAngle + (reducedMotion ? 0 : seconds * transit.speed);
        transit.anchor.position.set(Math.sin(angle) * transit.radius, reducedMotion ? 2.5 : 2.5 + Math.sin(seconds * 0.8) * 0.22, Math.cos(angle) * transit.radius);
        // The capsule's authored long axis is local +X; this yaw aligns it to
        // the circular route tangent instead of presenting it backwards.
        transit.anchor.rotation.y = angle;
      }
      transit.loaded?.animations?.stabilize?.();
      if (transit.fallbackNodes?.[1]) transit.fallbackNodes[1].rotation.z += reducedMotion ? 0 : 0.018;
    }
    const maintenance = world.ambientActors?.maintenance;
    const maintenanceDistance = maintenance ? Math.hypot(
      Number(maintenance.anchor?.position?.x || 0) - Number(playerAnchor.position.x || 0),
      Number(maintenance.anchor?.position?.z || 0) - Number(playerAnchor.position.z || 0)
    ) : 0;
    if (reliabilityController.shouldUpdateAnimation({ id: 'ambient:maintenance', distance: maintenanceDistance, at: timeMs })) updateMaintenanceActor(timeMs, seconds);
    eonbotRing.rotation.z += reducedMotion ? 0 : 0.006;
  };

  const updateMovement = (deltaSeconds) => {
    movementUpdateCalls += 1;
    lastMovementUpdateAt = Date.now();
    movementRenderRecovery?.noteMovementUpdate(lastMovementUpdateAt);
    const input = axis();
    const blockedReason = getMovementBlockReason();
    const canMove = input.active && !blockedReason;
    lastMovementBlockReason = input.active ? (blockedReason || '') : 'no-input';
    let desiredDirection = null;
    let runRequested = false;
    const beforeX = Number(playerAnchor.position.x || 0);
    const beforeZ = Number(playerAnchor.position.z || 0);
    lastBeforePosition = freeze({ x: beforeX, z: beforeZ });
    if (input.active) activeAxisFrameCount += 1;
    if (canMove) {
      if (cameraMode !== 'follow') {
        cameraMode = 'follow';
        camera.radius = EON_CITY_W747_CAMERA_POSES.follow.radius;
      }
      const forward = camera.getForwardRay(1).direction;
      forward.y = 0;
      if (forward.lengthSquared() < 0.0001) forward.set(0, 0, 1);
      forward.normalize();
      // Babylon's follow-camera forward vector requires the opposite
      // perpendicular for screen-right. The old basis inverted ArrowLeft and
      // ArrowRight (and A/D) in the live City.
      const right = new Vector3(-forward.z, 0, forward.x);
      const directionVector = forward.scale(input.forward).add(right.scale(input.right));
      if (directionVector.lengthSquared() > 0.0001) {
        directionVector.normalize();
        runRequested = Math.abs(input.forward) + Math.abs(input.right) > 1.15;
        const speed = runRequested ? 5.7 : 4.1;
        const requested = playerAnchor.position.add(directionVector.scale(speed * deltaSeconds));
        lastRequestedPosition = freeze({ x: Number(requested.x), z: Number(requested.z) });
        const next = clampEonCityW731Position(requested);
        lastClampedPosition = freeze({ x: Number(next.x), z: Number(next.z) });
        playerAnchor.position.set(next.x, 0, next.z);
        desiredDirection = { x: directionVector.x, z: directionVector.z };
        const travelled = Math.hypot(Number(next.x) - beforeX, Number(next.z) - beforeZ);
        lastTravelledDistance = travelled;
        if (travelled > 0.000001) {
          movementFrameCount += 1;
          movementDistance += travelled;
          lastMovementAt = Date.now();
        }
      }
    }
    const activeAssetId = playerAsset?.entry?.id || 'eoncity-pathfinder-prime-11clips';
    const activeVariant = playerAsset?.variantName || 'primary';
    lastCharacterMotionSnapshot = locomotionTruth.update({
      position: playerAnchor.position,
      desiredDirection,
      deltaSeconds,
      activeAssetId,
      activeVariant,
      runRequested,
      panelOpen: manualPaused || workSurfaceOpen || Boolean(ui?.isMenuOpen?.())
    });
    const nextMotion = lastCharacterMotionSnapshot.blocked ? 'idle' : lastCharacterMotionSnapshot.animationState;
    const locomotionAnimationSpeed = nextMotion === 'run'
      ? Math.max(EON_CITY_W761_CHARACTER_PROFILE.locomotion.runSpeedRange[0], Math.min(EON_CITY_W761_CHARACTER_PROFILE.locomotion.runSpeedRange[1], Number(lastCharacterMotionSnapshot.actualSpeed || 0) / 5.2))
      : nextMotion === 'walk'
        ? Math.max(EON_CITY_W761_CHARACTER_PROFILE.locomotion.walkSpeedRange[0], Math.min(EON_CITY_W761_CHARACTER_PROFILE.locomotion.walkSpeedRange[1], Number(lastCharacterMotionSnapshot.actualSpeed || 0) / 3.25))
        : 1;
    if (lastCharacterMotionSnapshot.moving || desiredDirection) playerAnchor.rotation.y = lastCharacterMotionSnapshot.visualHeading;
    if (nextMotion !== playerMotion) playerMotion = nextMotion;
    playerAsset?.animations?.play?.(nextMotion, { speedRatio: locomotionAnimationSpeed });
    playerAsset?.animations?.stabilize?.();
    if (cameraMode === 'follow') camera.setTarget(new Vector3(playerAnchor.position.x, EON_CITY_W747_CAMERA_POSES.follow.targetHeight, playerAnchor.position.z));
  };

  // Rendering remains Babylon-owned. This shared fixed-step clock is only for
  // player simulation, so accepted input remains responsive if a browser
  // delays a visual callback. Render frames and the fallback consume the same
  // accumulator and cannot apply the elapsed time twice.
  const advanceMovementSimulation = (at = Date.now(), source = 'render') => {
    const clockAt = Number(at) || Date.now();
    const input = axis();
    if (!input.active || getMovementBlockReason()) {
      simulationAccumulatorSeconds = 0;
      lastSimulationClockAt = clockAt;
      return 0;
    }
    const elapsed = Math.min(0.12, Math.max(0, (clockAt - lastSimulationClockAt) / 1000));
    lastSimulationClockAt = clockAt;
    simulationAccumulatorSeconds = Math.min(0.12, simulationAccumulatorSeconds + elapsed);
    const stepSeconds = 1 / 60;
    let steps = 0;
    while (simulationAccumulatorSeconds >= stepSeconds && steps < 7) {
      updateMovement(stepSeconds);
      simulationAccumulatorSeconds -= stepSeconds;
      steps += 1;
    }
    if (!steps) { duplicateStepPreventedCount += 1; return 0; }
    simulationStepCount += steps;
    lastSimulationStepAt = clockAt;
    simulationSource = source;
    lastSimulationDeltaSeconds = stepSeconds;
    if (source === 'fallback') fallbackSimulationStepCount += steps;
    else if (source === 'release-settlement') releaseSettlementStepCount += steps;
    else renderSimulationStepCount += steps;
    return steps;
  };
  settleMovementBeforeSourceRelease = ({ source = 'external', reason = 'input-release', allowSettlement = true } = {}) => {
    const at = Date.now();
    const blockedReason = getMovementBlockReason();
    const input = axis();
    const unprocessedElapsedMs = Math.max(0, at - lastSimulationClockAt);
    const boundedElapsedMs = Math.min(180, unprocessedElapsedMs);
    if (!allowSettlement || !input.active || blockedReason || !boundedElapsedMs) {
      lastReleaseSettlement = freeze({ attempted: true, allowed: false, source: String(source), reason: String(reason), unprocessedElapsedMs, boundedElapsedMs: 0, fixedStepsApplied: 0, distanceApplied: 0, skippedReason: !allowSettlement ? 'forced-cleanup' : (blockedReason || (!input.active ? 'inactive-axis' : 'no-unprocessed-time')), at });
      return lastReleaseSettlement;
    }
    const before = freeze({ x: Number(playerAnchor.position.x || 0), z: Number(playerAnchor.position.z || 0) });
    // advanceMovementSimulation clamps real elapsed time to the same 120 ms
    // anti-teleport bound used by the fallback; no synthetic time is added.
    const steps = advanceMovementSimulation(at, 'release-settlement');
    const distanceApplied = Math.hypot(Number(playerAnchor.position.x || 0) - before.x, Number(playerAnchor.position.z || 0) - before.z);
    releaseSettlementDistance += distanceApplied;
    lastReleaseSettlement = freeze({ attempted: true, allowed: true, source: String(source), reason: String(reason), unprocessedElapsedMs, boundedElapsedMs: Math.min(120, boundedElapsedMs), fixedStepsApplied: steps, distanceApplied, skippedReason: '', at });
    return lastReleaseSettlement;
  };
  stopMovementSimulationFallback = () => {
    if (fallbackClockHandle !== null && fallbackClockHandle !== 'microtask') globalThis.clearTimeout?.(fallbackClockHandle);
    fallbackClockHandle = null;
    fallbackClockGeneration += 1;
  };
  const runMovementSimulationFallback = () => {
    fallbackClockHandle = null;
    if (destroyed || !axis().active || getMovementBlockReason()) return;
    fallbackClockTickCount += 1;
    if (Date.now() - lastMovementUpdateAt > 24) advanceMovementSimulation(Date.now(), 'fallback');
    if (!destroyed && axis().active && !getMovementBlockReason()) fallbackClockHandle = globalThis.setTimeout?.(runMovementSimulationFallback, 24) ?? null;
  };
  startMovementSimulationFallback = () => {
    if (fallbackClockHandle !== null || destroyed || !axis().active || getMovementBlockReason()) return;
    const generation = ++fallbackClockGeneration;
    // This runs after the accepted browser input event returns, never from the
    // event handler itself. It covers browsers that defer both RAF and timers
    // while a heavy import is monopolising visual scheduling.
    fallbackClockHandle = 'microtask';
    const firstTick = () => {
      if (generation !== fallbackClockGeneration || destroyed || !axis().active || getMovementBlockReason()) return;
      runMovementSimulationFallback();
    };
    if (typeof globalThis.queueMicrotask === 'function') globalThis.queueMicrotask(firstTick);
    else fallbackClockHandle = globalThis.setTimeout?.(firstTick, 0) ?? null;
  };

  const updateEonbot = (timeMs, deltaSeconds) => {
    const seconds = timeMs * 0.001;
    const moving = Boolean(lastCharacterMotionSnapshot?.moving || axis().active);
    heroPresentationSnapshot = heroPresentationDirector.update({
      deltaMs: deltaSeconds * 1000,
      moving,
      playerPosition: playerAnchor.position,
      companionPosition: eonbotAnchor.position,
      nearestStationId: nearestStation?.station?.id || activeStationId || '',
      reducedMotion
    });

    const heading = Number(playerAnchor.rotation.y || 0);
    const forward = new Vector3(Math.sin(heading), 0, Math.cos(heading));
    const right = new Vector3(Math.cos(heading), 0, -Math.sin(heading));
    const formationTarget = playerAnchor.position
      .add(right.scale(1.35))
      .subtract(forward.scale(0.48))
      .add(new Vector3(0, 1.08 + (reducedMotion ? 0 : Math.sin(seconds * 1.45) * 0.08), 0));
    let target = formationTarget.clone();
    let state = heroPresentationSnapshot.companionState;
    const publicTarget = heroPresentationSnapshot.target?.position || null;
    const epochNow = Date.now();
    const activeReaction = latestRewardReaction?.expiresAt > epochNow ? latestRewardReaction : latestNexusReaction?.expiresAt > epochNow ? latestNexusReaction : null;

    if (activeReaction?.kind === 'mission-complete' || activeReaction?.kind === 'vault-reveal') {
      state = 'celebrate-mission';
      const celebrationAngle = seconds * 2.6;
      target = playerAnchor.position.add(new Vector3(Math.sin(celebrationAngle) * 1.55, 1.45 + Math.sin(seconds * 4.2) * 0.32, Math.cos(celebrationAngle) * 1.55));
    } else if (activeReaction?.kind === 'approval-waiting') {
      state = 'signal-approval';
      target = new Vector3(1.7 + Math.sin(seconds * 1.6) * 0.25, 1.55 + Math.sin(seconds * 3.2) * 0.18, 0.8);
    } else if (activeReaction?.kind === 'result-created') {
      state = 'result-arrival';
      target = new Vector3(-1.5 + Math.sin(seconds * 1.9) * 0.3, 1.62 + Math.cos(seconds * 3.1) * 0.18, 0.55);
    } else if (activeReaction?.kind === 'system-warning' || activeReaction?.kind === 'freshness-warning') {
      state = 'system-warning';
      target = new Vector3(0.1, 1.35 + Math.sin(seconds * 4.5) * 0.16, 1.7);
    } else if (state === 'curious-hover') {
      target = playerAnchor.position.add(new Vector3(
        right.x * 1.05 + Math.sin(seconds * 0.82) * 0.55,
        1.18 + Math.sin(seconds * 1.7) * 0.16,
        right.z * 1.05 + Math.sin(seconds * 1.64) * 0.28
      ));
    } else if (publicTarget && ['scout-structure', 'inspect-terminal', 'greet-host', 'circuit-scan', 'dock-check'].includes(state)) {
      target = new Vector3(Number(publicTarget.x || 0), Number(publicTarget.y || 1.05), Number(publicTarget.z || 0));
      if (state === 'scout-structure') target.y += 0.35 + Math.sin(seconds * 1.2) * 0.12;
      if (state === 'inspect-terminal') target.y += 0.28 + Math.sin(seconds * 2.1) * 0.06;
      if (state === 'greet-host') {
        target.x += Math.sin(seconds * 0.9) * 0.24;
        target.y += 0.38 + Math.sin(seconds * 2.4) * 0.09;
        target.z += Math.cos(seconds * 0.9) * 0.24;
      }
      if (state === 'circuit-scan') target.y = 0.72 + Math.sin(seconds * 1.8) * 0.08;
      if (state === 'dock-check') target.y += 0.16 + Math.sin(seconds * 2.2) * 0.06;
    } else if (state === 'nexus-spiral' && publicTarget) {
      const orbitRadius = 1.55 + Math.sin(seconds * 0.55) * 0.22;
      const orbitAngle = seconds * 0.95;
      target = new Vector3(
        Number(publicTarget.x || 0) + Math.sin(orbitAngle) * orbitRadius,
        1.12 + Math.sin(seconds * 1.35) * 0.38,
        Number(publicTarget.z || 0) + Math.cos(orbitAngle) * orbitRadius
      );
    } else if (state === 'playful-loop') {
      const loopAngle = seconds * 2.15;
      const loopRadius = 1.05 + Math.sin(seconds * 0.72) * 0.18;
      target = playerAnchor.position
        .add(right.scale(0.85))
        .subtract(forward.scale(0.35))
        .add(new Vector3(
          Math.sin(loopAngle) * loopRadius,
          1.18 + Math.sin(loopAngle * 1.55) * 0.42,
          Math.cos(loopAngle) * loopRadius
        ));
    }

    if (!moving && nearestStation?.station?.id === 'eonbot-nexus' && livingNexus.ok) {
      const orbit = livingNexus.getCompanionOrbitTarget?.(seconds);
      if (orbit) target = new Vector3(Number(orbit.x), Number(orbit.y), Number(orbit.z));
    }

    const fromPlayer = target.subtract(playerAnchor.position);
    const horizontalDistance = Math.hypot(fromPlayer.x, fromPlayer.z);
    const maxScoutDistance = Number(heroPresentationSnapshot.maxScoutDistanceFromPlayer || EON_CITY_W761_CHARACTER_PROFILE.eonbot.maximumScoutDistance);
    if (horizontalDistance > maxScoutDistance) {
      const scale = maxScoutDistance / Math.max(0.001, horizontalDistance);
      target.x = playerAnchor.position.x + fromPlayer.x * scale;
      target.z = playerAnchor.position.z + fromPlayer.z * scale;
    }
    target.y = Math.max(0.68, Math.min(2.35, target.y));

    const safeTarget = resolveEonCityW754EonbotSafeTarget({
      playerPosition: playerAnchor.position,
      requestedTarget: target,
      cameraPosition: camera.position,
      maxDistance: Number(heroPresentationSnapshot.maxScoutDistanceFromPlayer || EON_CITY_W761_CHARACTER_PROFILE.eonbot.maximumScoutDistance)
    });
    target.set(safeTarget.target.x, safeTarget.target.y, safeTarget.target.z);

    const previous = eonbotAnchor.position.clone();
    const speed = state === 'formation-follow' ? 4.4
      : state === 'return-formation' ? 3.7
        : state === 'celebrate-mission' ? 4.1
          : ['signal-approval', 'result-arrival', 'system-warning'].includes(state) ? 3.25
            : state === 'inspect-terminal' || state === 'dock-check' ? 2.05
              : state === 'greet-host' ? 2.35
                : state === 'playful-loop' ? 3.15
                  : 2.65;
    eonbotAnchor.position.copyFrom(Vector3.Lerp(previous, target, Math.min(1, deltaSeconds * speed)));
    const travel = eonbotAnchor.position.subtract(previous);
    if (Math.hypot(travel.x, travel.z) > 0.0005) {
      const desiredHeading = Math.atan2(travel.x, travel.z);
      const headingDelta = Math.atan2(Math.sin(desiredHeading - eonbotAnchor.rotation.y), Math.cos(desiredHeading - eonbotAnchor.rotation.y));
      eonbotAnchor.rotation.y += headingDelta * Math.min(1, deltaSeconds * 5.5);
    } else if (!reducedMotion) eonbotAnchor.rotation.y += 0.0035;
    const playfulTilt = heroPresentationSnapshot.playfulTilt && !reducedMotion;
    eonbotAnchor.rotation.x = playfulTilt ? Math.sin(seconds * 1.9) * 0.09 : 0;
    eonbotAnchor.rotation.z = playfulTilt ? Math.sin(seconds * 1.15 + 0.8) * 0.12 : 0;

    const scanActive = Boolean(heroPresentationSnapshot.scanEffect) || ['signal-approval', 'result-arrival', 'system-warning'].includes(state);
    const greetingActive = Boolean(heroPresentationSnapshot.greetingEffect) || state === 'celebrate-mission';
    eonbotScanHalo.setEnabled(scanActive || greetingActive);
    eonbotScanBeam.setEnabled(scanActive && ['inspect-terminal', 'dock-check'].includes(state));
    if (scanActive || greetingActive) {
      eonbotScanHalo.rotation.z += reducedMotion ? 0 : greetingActive ? 0.025 : 0.045;
      eonbotScanHalo.scaling.setAll(greetingActive
        ? 0.72 + Math.sin(seconds * 3.1) * 0.08
        : 0.88 + Math.sin(seconds * 4.2) * 0.12);
      eonbotScanBeam.scaling.y = 0.82 + Math.sin(seconds * 3.6) * 0.12;
    }
    const sparkAngle = seconds * (state === 'nexus-spiral' ? 3.1 : state === 'playful-loop' ? 4.4 : 2.15);
    eonbotSparkA.position.set(Math.sin(sparkAngle) * 0.72, Math.sin(seconds * 1.7) * 0.14, Math.cos(sparkAngle) * 0.72);
    eonbotSparkB.position.set(Math.sin(-sparkAngle * 0.78) * 0.54, Math.cos(seconds * 1.35) * 0.18, Math.cos(-sparkAngle * 0.78) * 0.54);

    if (playerMotion === 'idle') {
      const nextPresentation = heroPresentationSnapshot.playerIdleState || 'idle';
      if (nextPresentation !== playerPresentationState) {
        const accepted = playerAsset?.animations?.playStationary?.(nextPresentation, { restart: true });
        playerPresentationState = accepted === false ? 'idle' : nextPresentation;
        if (accepted === false) playerAsset?.animations?.playStationary?.('idle', { restart: true });
      }
      if (!isEonCityW759PresentationReady(playerAsset)) applyProceduralStationary({ npcGestureState: playerPresentationState }, fallbackPlayer, seconds, 5.2);
      playerAsset?.animations?.stabilize?.();
    } else playerPresentationState = '';
  };

  const getRuntimeSummary = () => freeze({
    schema: EON_CITY_CORE_RUNTIME_SCHEMA,
    owner: EON_CITY_W731_RUNTIME_OWNER_SCHEMA,
    launchModel: 'living-command-centre-exterior-map',
    player: freeze({
      x: Number(playerAnchor.position.x), y: 0, z: Number(playerAnchor.position.z), heading: Number(playerAnchor.rotation.y),
      motion: playerMotion, idlePresentation: playerPresentationState || 'locomotion', motionTruth: lastCharacterMotionSnapshot
    }),
    eonbot: freeze({
      x: Number(eonbotAnchor.position.x), y: Number(eonbotAnchor.position.y), z: Number(eonbotAnchor.position.z),
      docked: Math.hypot(eonbotAnchor.position.x - EON_CITY_W731_EONBOT_DOCK.x, eonbotAnchor.position.z - EON_CITY_W731_EONBOT_DOCK.z) < 0.8,
      presentation: heroPresentationSnapshot,
      reactionMode: latestRewardReaction?.expiresAt > Date.now() ? latestRewardReaction.kind : latestNexusReaction?.expiresAt > Date.now() ? latestNexusReaction.kind : null,
      schema: EON_CITY_W745_HERO_PRESENTATION_SCHEMA
    }),
    nearestStation: nearestStation ? freeze({ id: nearestStation.station.id, label: nearestStation.station.label, distance: nearestStation.distance }) : null,
    nearestDiscovery: nearestDiscovery ? freeze({ id: nearestDiscovery.discovery.id, label: nearestDiscovery.discovery.label, distance: nearestDiscovery.distance }) : null,
    activeStationId: activeStationId || null,
    stations: freeze(EON_CITY_W731_STATIONS.map((station) => freeze({ id: station.id, label: station.label }))),
    stationCount: EON_CITY_W731_STATIONS.length,
    discoveryCount: EON_CITY_W737_DISCOVERIES.length,
    missionCount: missionsProgression.getView?.()?.missionCount || 0,
    missions: missionsProgression.getView?.()?.missions || [],
    explorationMissionCount: EON_CITY_W737_MISSIONS.length,
    explorationMissions: buildEonCityW737MissionView(),
    outsideMapActive: true,
    visibleFrameGate: freeze({
      authoredEnvironmentRequired: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame.requiredCoreAssetCount,
      authoredEnvironmentReady: visibleFrameState.authoredEnvironmentReady,
      authoredHeroCharactersRequired: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame.requiredCoreCharacterCount,
      authoredHeroCharactersReady: visibleFrameState.authoredHeroCharactersReady,
      heroFallbacksReady: true,
      gateComplete: visibleFrameState.gateComplete,
      degraded: visibleFrameState.degraded,
      hardTimeoutMs: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.visibleFrame.hardTimeoutMs
    }),
    stationCompletion: freeze({
      schema: EON_CITY_W744_STATION_COMPLETION_SCHEMA,
      blueprintCount: EON_CITY_W744_STATION_BLUEPRINTS.length,
      interactionTriads: EON_CITY_W744_STATION_BLUEPRINTS.every((entry) => ['structure', 'terminal', 'npc'].every((part) => entry.interactions.includes(part))),
      authoredStructuresReady: [...stationState.values()].filter((record) => isEonCityW759PresentationReady(record.loadedWorld)).length,
      authoredTerminalsReady: [...stationState.values()].filter((record) => isEonCityW759PresentationReady(record.loadedTerminal)).length,
      authoredNpcReady: [...stationState.values()].filter((record) => isEonCityW759PresentationReady(record.loadedNpc)).length,
      commandStatusCharacter: stationState.get('command-console')?.blueprint?.npcAlias || null,
      rejectedArchitectActive: false
    }),
    characterMotion: freeze({
      playerLocomotion: true,
      playerNonStaticIdle: heroPresentationTruth.nonStaticPlayerIdle,
      playerIdleModes: heroPresentationTruth.playerIdleModes,
      eonbotCuriousFollow: true,
      eonbotPublicScouting: heroPresentationTruth.boundedPublicScouting,
      eonbotStationHostGreetings: true,
      eonbotPlayfulLoops: true,
      eonbotVisualDockVisits: heroPresentationTruth.visualDockVisitOnly,
      eonbotCompanionModes: heroPresentationTruth.companionModes,
      eonbotAutomaticStationActivation: false,
      eonbotAutonomousAgent: false,
      stationNpcLocomotionAllowed: true,
      stationNpcBoundedMicroRoutes: true,
      stationNpcWalkingInPlace: false,
      stationNpcGestureAnimation: true,
      stationNpcMovingNow: [...stationState.values()].filter((record) => record.npcRoute?.moving).length,
      exteriorAmbientLocomotion: true,
      exteriorAmbientCitizenSlots: world.ambientCitizens?.length || 0,
      exteriorAmbientCitizenCount: (world.ambientCitizens || []).filter((citizen) => isEonCityW759PresentationReady(citizen.loaded)).length,
      proceduralExteriorAmbientCitizenVisible: false,
      maintenanceWorkerBoundedRoute: true,
      maintenanceWorkerVisible: isEonCityW759PresentationReady(world.ambientActors?.maintenance?.loaded)
    }),
    commandCentreDesign: freeze({
      microchipCircuitFloor: true,
      circuitNodeCount: world.circuitNodeCount || 0,
      animatedCircuitPulseCount: world.circuitPulses?.length || 0,
      boundedPointLights: world.commandLights?.length || 0,
      stationBeacons: EON_CITY_W744_STATION_BLUEPRINTS.reduce((total, entry) => total + Number(entry.lighting.beacons || 0), 0),
      transportCapsuleAmbient: Boolean(world.ambientActors?.transit),
      maintenanceWorkerAmbient: Boolean(world.ambientActors?.maintenance),
      authoredStreetLampInstances: isEonCityW759PresentationReady(world.exteriorMap?.authoredStreetLamp)
        ? 1 + Number(world.exteriorMap?.authoredStreetLampClones?.length || 0)
        : 0,
      allReadyWorldAssetsAssigned: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.truth.allReadyWorldAssetsAssigned === true,
      atmosphericDepth: scene.fogMode === Scene.FOGMODE_EXP2,
      themeAwareExposure: Number(scene.imageProcessingConfiguration?.exposure || 1)
    }),
    nexus3d: freeze({
      schema: EON_CITY_W749_LIVING_NEXUS_SCHEMA,
      livingHero: Boolean(livingNexus.ok),
      centralGenesisCore: true,
      authoredCoreReady: isEonCityW759PresentationReady(stationState.get('eonbot-nexus')?.loadedWorld),
      state: livingNexus.getView?.()?.state || 'unavailable',
      freshness: livingNexus.getView?.()?.freshness || null,
      ringCount: livingNexus.getView?.()?.rings?.length || 0,
      selectedRingId: livingNexus.getSelectedRing?.() || livingNexus.getView?.()?.selectedRingId || '',
      workObject: livingNexus.getView?.()?.workObject || freeze({ present: false }),
      privacy: livingNexus.getView?.()?.privacy || null,
      ownsProductState: false,
      oneProjectionEvent: true,
      dockSurface: 'nexus',
      terminal: true,
      commandSeat: true,
      eonbotDock: true,
      interactionParts: freeze(['structure', 'terminal', 'npc', 'nexus-ring', 'command-wall'])
    }),
    stationMonitors: freeze({
      schema: EON_CITY_W765R5_STATION_MONITOR_SCHEMA,
      validation: stationMonitorValidation,
      count: stationMonitors.size + (commandCentre.ok ? 1 : 0),
      individualCount: stationMonitors.size,
      commandStatusWallCount: commandCentre.getView?.()?.walls?.length || 0,
      stations: freeze([...stationMonitors.values()].map((monitor) => monitor.getSummary?.()).filter(Boolean))
    }),
    commandCentre: freeze({
      schema: EON_CITY_W750_COMMAND_CENTRE_SCHEMA,
      liveWalls: Boolean(commandCentre.ok),
      wallCount: commandCentre.getView?.()?.walls?.length || 0,
      selectedWallId: commandCentre.getSelectedWall?.() || commandCentre.getView?.()?.selectedWallId || '',
      agentTheatreReceipts: commandCentre.getView?.()?.walls?.find?.((entry) => entry.id === 'agent-theatre')?.jobs?.length || 0,
      truthfulStatusValidation: validateEonCityTruthfulCommandCenterSnapshot(commandStatusController.getSnapshot()),
      genuineTheatreValidation: validateEonCityGenuineAgentTheatreSnapshot(agentTheatreController.getSnapshot()),
      commandCentreValidation: validateEonCityW750CommandCentreContract(),
      presentation: commandCentre.getPresentationSummary?.() || null,
      fakeWorkers: false,
      inventedProgress: false,
      automaticExecution: false,
      dockSurface: 'command-centre'
    }),
    productiveStations: freeze({
      schema: EON_CITY_W751_PRODUCTIVE_STATIONS_SCHEMA,
      stationCount: productiveStations.getView?.()?.stationCount || 0,
      reviewedCount: productiveStations.getView?.()?.reviewedCount || 0,
      verifiedCount: productiveStations.getView?.()?.verifiedCount || 0,
      validation: validateEonCityW751ProductiveStations(productiveStations.getView?.()),
      ownsProductState: false,
      ownsReceiptAuthority: false,
      automaticExecution: false,
      rewardIssued: false
    }),
    missionsProgression: freeze({
      schema: EON_CITY_W752_SCHEMA,
      missionCount: missionsProgression.getView?.()?.missionCount || 0,
      claimedCount: missionsProgression.getView?.()?.claimedCount || 0,
      claimableCount: missionsProgression.getView?.()?.claimableCount || 0,
      xp: missionsProgression.getView?.()?.xp || 0,
      pendingReveals: missionsProgression.getView?.()?.pendingReveals || 0,
      validation: validateEonCityW752MissionsProgression(missionsProgression.getView?.()),
      deterministicCosmeticsOnly: true,
      lootBox: false,
      paidRandomReward: false,
      streakPunishment: false,
      publicPostingRequired: false
    }),
    castNpcTransit: freeze({
      schema: EON_CITY_W754_SCHEMA,
      validation: castTransitValidation,
      cast: w754CastPlan,
      schedules: w754NpcSchedulePlan,
      transit: w754TransitController.getSnapshot(),
      capsuleId: EON_CITY_W754_CAPSULE_ID,
      capsuleForwardAxis: EON_CITY_W754_CAPSULE_FORWARD_AXIS,
      uniqueCapsuleCount: 1,
      boardSkipExplicit: true,
      automaticTravel: false,
      sourcePresenceIsNotVisualCertification: true
    }),
    spatialFoundation: freeze({
      schema: EON_CITY_W747_SPATIAL_SCHEMA,
      validation: validateEonCityW747SpatialFoundation(),
      heroZone: EON_CITY_W747_HERO_ZONE,
      wingCount: EON_CITY_W747_FIVE_WING_ANCHORS.length,
      camera: captureCameraPose(),
      diagnosticsVisible: spatialDiagnosticsVisible,
      loadedBounds: spatialDiagnostics.getReport(),
      centralOrientationShellRetired: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.truth.centralOrientationShellRetired === true
    }),
    accessibleEmptyAreas: 0,
    futureGatewaysClosed: EON_CITY_W731_FUTURE_GATEWAYS.length,
    oneEngine: true,
    oneScene: true,
    oneRenderLoop: true,
    oldDistrictBeltsActive: false,
    retiredLivingNexusBridgeActive: false,
    expanseVisibleFromOverlook: true,
    expanseActive: false,
    workSurfaceOpen,
    movementPaused: manualPaused || workSurfaceOpen || Boolean(ui?.isMenuOpen?.()),
    movementBlockReason: getMovementBlockReason() || null,
    workspace: freeze({
      schema: workspacePresenter.schema,
      defaultPresentation: 'dock',
      presentationMode: workspacePresentationMode,
      state: workspacePresenter.getState(),
      exactWorldRestore: true,
      routeChangeOnOpen: false,
      interactionRegistry: interactionRegistry.getSummary(),
      interactionValidation: validateEonCityW748InteractionRegistry(),
      presenterValidation: validateEonCityW748WorkspacePresenterContract(),
      livingNexusValidation: validateEonCityW749LivingNexusContract()
    }),
    quality: resolvedQuality,
    reducedMotion: Boolean(reducedMotion),
    fps: measuredFps,
    runtimeProvenance: EON_CITY_W757_RUNTIME_PROVENANCE,
    arrivalCamera: arrivalCameraValidation,
    lifecycle: freeze({
      documentHidden,
      contextLost,
      contextLossCount,
      contextRestoreCount,
      performanceProtectionLevel,
      hardwareScalingLevel: currentHardwareScalingLevel,
      maxHardwareScalingLevel
    }),
    assets: localAssetRuntime?.getSummary?.() || freeze({ resident: 0, inflight: 0, proceduralFallback: true }),
    environment: freeze({ schema: EON_CITY_W755_SCHEMA, plan: environmentController.getPlan(), validation: environmentValidation, audio: environmentController.getSnapshot().audio }),
    experience: freeze({ schema: EON_CITY_W756_SCHEMA, plan: w756ExperiencePlan, validation: w756ExperienceValidation, semanticNavigation: semanticNavigationController?.getSummary?.() || null }),
    reliability: freeze({ schema: EON_CITY_W757_SCHEMA, plan: w757ReliabilityPlan, validation: w757ReliabilityValidation, snapshot: reliabilityController.getSnapshot() }),
    destroyed
  });

  const renderFrame = () => {
    if (destroyed) return;
    const frameAt = now();
    renderLoopFrames += 1;
    lastRenderAt = Date.now();
    movementRenderRecovery?.noteRenderCallback(lastRenderAt);
    const backgroundPresentation = workSurfaceOpen || Boolean(ui?.isMenuOpen?.());
    if (!reliabilityController.shouldRenderFrame({ at: frameAt, background: backgroundPresentation, hidden: documentHidden, contextLost })) {
      lastReliabilityRenderDecision = 'skipped-reliability';
      return;
    }
    lastReliabilityRenderDecision = 'rendered';
    movementRenderRecovery?.noteReliabilityRenderAccepted(Date.now());
    const frameDurationMs = Math.max(0, frameAt - lastFrameAt);
    const deltaSeconds = Math.min(0.05, Math.max(0.001, frameDurationMs / 1000));
    lastFrameAt = frameAt;
    if (!backgroundPresentation) reliabilityController.recordFrame(frameDurationMs);
    if (!manualPaused && !workSurfaceOpen && !ui?.isMenuOpen?.()) {
      advanceMovementSimulation(Date.now(), 'render');
      updateEonbot(frameAt, deltaSeconds);
      updateAnimatedWorld(frameAt);
      const weather = world.environment?.weather;
      if (weather?.rainRoot?.isEnabled?.() && !reducedMotion) {
        for (let index = 0; index < weather.rainDrops.length; index += 1) {
          const drop = weather.rainDrops[index];
          drop.position.y -= deltaSeconds * (7 + index % 5);
          if (drop.position.y < 0.6) drop.position.y = 8 + (index % 7);
        }
      }
      livingNexus.update?.(frameAt);
      commandCentre.update?.(frameAt);
      for (const monitor of stationMonitors.values()) monitor.update?.(frameAt, camera.position);
    }
    nearestStation = resolveEonCityW731NearestStation(playerAnchor.position, 5.2);
    nearestDiscovery = resolveEonCityW737NearestDiscovery(playerAnchor.position, 5.2);
    const stationDistance = Number(nearestStation?.distance ?? Number.POSITIVE_INFINITY);
    const discoveryDistance = Number(nearestDiscovery?.distance ?? Number.POSITIVE_INFINITY);
    const nearestTarget = stationDistance <= discoveryDistance ? nearestStation : nearestDiscovery;
    const nearestId = nearestTarget?.station?.id || nearestTarget?.discovery?.id || '';
    if (nearestId !== lastNearestId) {
      lastNearestId = nearestId;
      ui.setPrompt(nearestTarget);
      setContextualSelection(nearestTarget);
      if (nearestTarget?.station) {
        activeStationId = nearestTarget.station.id;
        onStatus?.(`Near ${nearestTarget.station.label}. Press E or choose ${nearestTarget.station.npc.action}.`);
        onLandmarkChange?.(freeze({ id: nearestTarget.station.id, label: nearestTarget.station.label, districtId: nearestTarget.station.zone || 'command-centre' }));
      } else if (nearestTarget?.discovery) {
        onStatus?.(`Near ${nearestTarget.discovery.label}. Press E or choose ${nearestTarget.discovery.npc.action}.`);
        onLandmarkChange?.(freeze({ id: nearestTarget.discovery.id, label: nearestTarget.discovery.label, districtId: 'command-horizon', discovery: true }));
      } else onStatus?.('Living Command Centre ready. Explore a destination, outside landmark or open City Menu.');
    }
    ui.update(projector, playerAnchor.position, nearestId, frameAt);
    sceneRenderCalls += 1;
    try { scene.render(); } catch (error) {
      lastSceneRenderError = String(error?.message || error || 'scene-render-failed').slice(0, 160);
      throw error;
    }
    movementRenderRecovery?.noteSceneRender(Date.now());
    fpsFrames += 1;
    if (frameAt - fpsSampleAt >= 1000) {
      measuredFps = Math.round((fpsFrames * 1000) / Math.max(1, frameAt - fpsSampleAt));
      fpsFrames = 0;
      fpsSampleAt = frameAt;
      const lowFpsFloor = resolvedQuality === 'cinematic' ? 38 : resolvedQuality === 'balanced' ? 40 : 25;
      lowFpsSamples = measuredFps > 0 && measuredFps < lowFpsFloor ? lowFpsSamples + 1 : 0;
      if (lowFpsSamples >= 3 && frameAt - lastPerformanceProtectionAt >= 8_000) {
        lastPerformanceProtectionAt = frameAt;
        lowFpsSamples = 0;
        applyPerformanceProtection(`sustained-${measuredFps}-fps`);
      }
    }
    if (!firstFrame) {
      firstFrame = true;
      reliabilityController.recordFirstFrame();
      stage('CITY_FIRST_PLAYABLE_FRAME', 'hidden-safety-frame');
      onFirstFrame?.();
      onDetailStage?.({ id: 'nearby-district', summary: { activeDistrictId: 'command-centre', activeExperience: { displayName: 'Living Command Centre' }, residents: [] } });
      onStatus?.('Preparing the authored Living Command Centre, Pathfinder and EONBOT.');
      void startProgressiveAssets();
    }
    if (frameAt - lastResumeWrite > 2000 && axis().active) {
      lastResumeWrite = frameAt;
      writeResume(playerAnchor.position, playerAnchor.rotation.y, activeStationId);
    }
    if (frameAt - lastTelemetry > 3000) {
      lastTelemetry = frameAt;
      onTelemetry?.(getRuntimeSummary());
    }
  };
  const launchRenderLoop = () => engine.runRenderLoop(renderFrame);
  launchRenderLoop();
  movementRenderRecovery = createEonCityW731MovementRenderRecovery({
    now: () => Date.now(),
    staleThresholdMs: 80,
    cooldownMs: 260,
    wakeImmediately: true,
    getState: () => freeze({
      destroyed,
      engine,
      scene,
      documentHidden,
      documentVisible: globalThis.document?.visibilityState !== 'hidden',
      contextLost,
      manualPaused,
      workSurfaceOpen,
      cityMenuOpen: Boolean(ui?.isMenuOpen?.()),
      axisActive: axis().active
    }),
    restartRenderLoop: () => {
      try {
        engine.stopRenderLoop(renderFrame);
        launchRenderLoop();
        return true;
      } catch {
        return false;
      }
    }
  });
  stage('FIRST_RENDER_REQUESTED');

  const getW759PresentationDiagnostics = () => {
    const roleStations = new Set(EON_CITY_W731_LAUNCH_ASSET_MANIFEST.roleCharacters.map((entry) => entry.stationId));
    const stations = EON_CITY_W731_STATIONS.map((station) => {
      const record = stationState.get(station.id);
      const fallbackStructureVisualsEnabled = (record?.fallbackVisualNodes || [])
        .filter((node) => node !== record?.base && isEonCityW759NodeEnabled(node)).length;
      const fallbackTerminalVisualsEnabled = (record?.terminalFallbackNodes || [])
        .filter(isEonCityW759NodeEnabled).length;
      return freeze({
        id: station.id,
        label: station.label,
        roleNpcRequired: roleStations.has(station.id),
        structure: summarizeEonCityW759LoadedPresentation(record?.loadedWorld),
        terminal: summarizeEonCityW759LoadedPresentation(record?.loadedTerminal),
        npc: summarizeEonCityW759LoadedPresentation(record?.loadedNpc),
        fallbackStructureVisualsEnabled,
        fallbackTerminalVisualsEnabled,
        fallbackNpcEnabled: isEonCityW759NodeEnabled(record?.fallbackNpc?.root),
        npcRepresentation: isEonCityW759PresentationReady(record?.loadedNpc) ? 'authored' : 'absent',
        proceduralNpcVisible: false
      });
    });
    const discoveries = EON_CITY_W737_DISCOVERIES.map((discovery) => {
      const record = discoveryState.get(discovery.id);
      return freeze({
        id: discovery.id,
        label: discovery.label,
        world: summarizeEonCityW759LoadedPresentation(record?.loadedWorld),
        fallbackVisualsEnabled: (record?.fallbackVisualNodes || []).filter(isEonCityW759NodeEnabled).length
      });
    });
    const assets = localAssetRuntime?.getSummary?.() || null;
    const assetLoader = assets
      ? freeze({
        received: assets.qualityAuthority?.received || null,
        effective: assets.quality || null,
        source: assets.qualityAuthority?.source || null,
        budgetName: assets.budget?.name || null
      })
      : null;
    const entryAuthority = qualityAuthority && typeof qualityAuthority === 'object'
      ? freeze({ ...qualityAuthority })
      : freeze({ detected: resolvedQuality, requested: null, effective: resolvedQuality, source: 'automatic', overrideAllowed: false, overrideAccepted: false, rejectionReason: 'entry-authority-unavailable', renderer: '' });
    const handshakeReady = Boolean(assetLoader?.effective);
    const entryToRuntimePass = entryAuthority.effective === resolvedQualityAuthority.effective;
    const runtimeToLoaderPass = handshakeReady && resolvedQualityAuthority.effective === assetLoader.effective;
    return freeze({
      schema: 'eon.city.w759r1.presentation-diagnostics.v1',
      quality: resolvedQuality,
      qualityAuthority: freeze({ entry: entryAuthority, runtime: resolvedQualityAuthority, assetLoader }),
      qualityHandshake: freeze({
        state: handshakeReady ? 'ready' : 'pending',
        entryToRuntimePass,
        runtimeToLoaderPass,
        pass: handshakeReady && entryToRuntimePass && runtimeToLoaderPass
      }),
      player: freeze({
        authored: summarizeEonCityW759LoadedPresentation(playerAsset),
        fallbackEnabled: isEonCityW759NodeEnabled(fallbackPlayer?.root)
      }),
      eonbot: freeze({
        authored: summarizeEonCityW759LoadedPresentation(eonbotAsset),
        fallbackEnabled: isEonCityW759NodeEnabled(eonbotFallback),
        fallbackRingEnabled: isEonCityW759NodeEnabled(eonbotRing)
      }),
      stations: freeze(stations),
      discoveries: freeze(discoveries),
      assets: assets || freeze({ resident: 0, inflight: 0, queued: 0, presentationReadinessPass: false, attachments: freeze([]) }),
      counts: freeze({
        stationWorldReady: stations.filter((entry) => entry.id !== 'eonbot-nexus' && entry.structure.ready).length,
        stationWorldRequired: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.stationWorld.length,
        stationTerminalsReady: stations.filter((entry) => entry.terminal.ready).length,
        stationTerminalsRequired: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.stationProps.length,
        roleNpcsReady: stations.filter((entry) => entry.roleNpcRequired && entry.npc.ready).length,
        roleNpcsRequired: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.roleCharacters.length,
        discoveriesReady: discoveries.filter((entry) => entry.world.ready).length,
        discoveriesRequired: EON_CITY_W731_LAUNCH_ASSET_MANIFEST.discoveryWorld.length
      }),
      privacySafeVisualDiagnosticsOnly: true
    });
  };

  const runtime = freeze({
    schema: EON_CITY_CORE_RUNTIME_SCHEMA,
    setMove(directionName = '', active = false, options = {}) {
      reconcileWorkspacePause();
      return setDirection(String(directionName), Boolean(active), options?.source || 'external', { settleBeforeRelease: options?.settleBeforeRelease !== false, releaseReason: options?.releaseReason || 'runtime-setMove-release' });
    },
    setAnalogMove(vector = {}, options = {}) {
      reconcileWorkspacePause();
      const source = String(options?.source || 'analog').slice(0, 64);
      const previousAxis = axis();
      const value = freeze({ x: Math.max(-1, Math.min(1, Number(vector.x || 0))), z: Math.max(-1, Math.min(1, Number(vector.z || 0))) });
      if (Math.hypot(value.x, value.z) <= 0.001 && options?.settleBeforeRelease !== false) settleMovementBeforeSourceRelease?.({ source, reason: 'analog-release', allowSettlement: true });
      if (Math.hypot(value.x, value.z) <= 0.001) analog.delete(source); else analog.set(source, value);
      const nextAxis = axis();
      if (!previousAxis.active && nextAxis.active) {
        movementRenderRecovery?.activate({ source, reason: 'movement-activated' });
        startMovementSimulationFallback?.(source);
      }
      if (previousAxis.active && !nextAxis.active) {
        movementRenderRecovery?.deactivate('movement-inactive');
        stopMovementSimulationFallback?.('movement-inactive');
      }
      return freeze({ ...value, source });
    },
    clearInput() { clearInput(); return freeze({ ok: true, released: true }); },
    getW759PresentationDiagnostics() { return getW759PresentationDiagnostics(); },
    getInputDiagnostics() {
      reconcileWorkspacePause();
      const value = axis();
      return freeze({
        mode: 'manual-camera-relative',
        right: value.right,
        forward: value.forward,
        active: value.active,
        keyboardKeys: heldKeys.size,
        analogSources: analog.size,
        blockedReason: value.active ? (getMovementBlockReason() || lastMovementBlockReason || null) : null,
        lastInputEvent,
        movementFrameCount,
        movementDistance: Number(movementDistance.toFixed(4)),
        lastMovementAt,
        player: freeze({ x: Number(playerAnchor.position.x), y: Number(playerAnchor.position.y), z: Number(playerAnchor.position.z), heading: Number(playerAnchor.rotation.y) }),
        workSurfaceOpen,
        workSurfaceHostVisible: workSurfaceHostVisible(),
        manualPaused,
        menuOpen: Boolean(ui?.isMenuOpen?.())
        ,inputDiagnostics: freeze({ listenersAttached: !destroyed, keydownEvents, keyupEvents, lastRawKeyboardEvent })
        ,renderDiagnostics: freeze({ renderLoopFrames, movementUpdateCalls, lastRenderAt, lastMovementUpdateAt, lastReliabilityRenderDecision, sceneRenderCalls, lastSceneRenderError, engineDisposed: engine.isDisposed === true, sceneDisposed: scene.isDisposed === true, documentHidden, visibilityState: String(globalThis.document?.visibilityState || 'unknown'), contextLost })
        ,renderRecovery: movementRenderRecovery?.getSnapshot?.() || null
        ,movementDiagnostics: freeze({ axisReadCount, activeAxisFrameCount, lastAxis, lastBlockReason: lastMovementBlockReason, lastBeforePosition, lastRequestedPosition, lastClampedPosition, lastTravelledDistance })
        ,movementSimulation: freeze({ active: axis().active, source: simulationSource, lastClockAt: lastSimulationClockAt, lastStepAt: lastSimulationStepAt, stepCount: simulationStepCount, accumulatorSeconds: simulationAccumulatorSeconds, fallbackClockScheduled: fallbackClockHandle !== null, fallbackClockTickCount, fallbackSimulationStepCount, renderSimulationStepCount, releaseSettlementStepCount, releaseSettlementDistance, duplicateStepPreventedCount, lastStepDeltaSeconds: lastSimulationDeltaSeconds, lastTravelledDistance })
        ,releaseSettlement: lastReleaseSettlement
      });
    },
    openStation(stationId = '', { explicitUserAction = false, surface = '' } = {}) {
      if (!explicitUserAction) return freeze({ ok: false, reason: 'explicit-user-action-required' });
      return openSurfaceForStation(stationId, canvas, surface);
    },
    guideToStation(stationId = '', { explicitUserAction = true } = {}) {
      if (!explicitUserAction) return freeze({ ok: false, reason: 'explicit-user-action-required' });
      return guideToStation(stationId);
    },
    focusLandmark(id = '') {
      const stationId = LEGACY_LANDMARK_TO_STATION[String(id || '').toLowerCase()] || String(id || '').toLowerCase();
      return guideToStation(stationId).ok;
    },
    guideToLandmark(id = '') {
      const stationId = LEGACY_LANDMARK_TO_STATION[String(id || '').toLowerCase()] || String(id || '').toLowerCase();
      return guideToStation(stationId);
    },
    getW649DistrictActions() { return freeze([]); },
    focusCommandDeck() { return guideToStation('command-console'); },
    focusCreatorAtrium() { return guideToStation('create-forge'); },
    focusMetropolisDistrict(id = '') { return this.guideToLandmark(id); },
    focusAuthoredVerticalSliceRegion(id = '') { return this.guideToLandmark(id); },
    guideToLivingNexusPhysicalGateway() { return freeze({ ok: false, reason: 'retired-launch-layer', replacement: 'command-hub-stations' }); },
    guideToLivingNexusCell() { return freeze({ ok: false, reason: 'retired-launch-layer', replacement: 'command-hub-stations' }); },
    enterLivingNexusRealm() { return freeze({ ok: false, reason: 'retired-launch-layer', replacement: 'my-realm' }); },
    getSpatialDiagnostics() { return freeze({ visible: spatialDiagnosticsVisible, report: spatialDiagnostics.getReport(), bounds: spatialDiagnostics.listLoadedBounds() }); },
    setSpatialDiagnosticsVisible,
    getCameraPose: captureCameraPose,
    getRuntimeSummary,
    refreshLivingNexus(reason = 'manual') { return livingNexus.refresh?.(reason) || null; },
    inspectLivingNexusRing(id = '', { explicitUserAction = false, openDock = false } = {}) {
      if (!explicitUserAction) return freeze({ ok: false, reason: 'explicit-user-action-required' });
      if (openDock) {
        return openSurfaceForStation('eonbot-nexus', {
          interactionPart: `nexus-ring:${id}`,
          interactionSource: 'runtime-api',
          nexusRingId: id
        }, 'nexus');
      }
      return livingNexus.inspectRing?.(id) || freeze({ ok: false, reason: 'living-nexus-unavailable' });
    },
    async refreshCommandCentre({ explicitUserAction = false, includeServerBilling = false, reason = 'manual' } = {}) {
      if (!explicitUserAction) return freeze({ ok: false, reason: 'explicit-user-action-required' });
      if (includeServerBilling) await commandStatusController.refresh({ explicitUserAction: true });
      else commandStatusController.refreshLocal();
      const view = commandCentre.refresh?.(reason) || commandCentre.getView?.();
      return freeze({ ok: true, view, serverBillingRequested: Boolean(includeServerBilling), automaticExecution: false });
    },
    inspectCommandCentreWall(id = '', { explicitUserAction = false, openDock = false } = {}) {
      if (!explicitUserAction) return freeze({ ok: false, reason: 'explicit-user-action-required' });
      if (openDock) {
        return openSurfaceForStation('command-console', {
          interactionPart: `command-wall:${id}`,
          interactionSource: 'runtime-api',
          commandWallId: id
        }, 'command-centre');
      }
      return commandCentre.inspectWall?.(id) || freeze({ ok: false, reason: 'command-centre-unavailable' });
    },
    reviewAgentTheatreJob(jobId = '', { explicitUserAction = false } = {}) {
      const result = agentTheatreController.review(jobId, { explicitUserAction });
      commandCentre.refresh?.('agent-theatre-review');
      return result;
    },
    getProductiveStationLoops() { return productiveStations.getView?.() || null; },
    getProductiveStationLoop(stationId = '') { return productiveStations.getStation?.(stationId) || null; },
    reviewProductiveStation(stationId = '', { explicitUserAction = false } = {}) {
      const result = productiveStations.reviewStation?.(stationId, { explicitUserAction }) || freeze({ ok: false, reason: 'productive-stations-unavailable' });
      if (result.ok) livingNexus.refresh?.('productive-station-reviewed');
      return result;
    },
    refreshProductiveStations(reason = 'manual', { explicitUserAction = false } = {}) {
      if (!explicitUserAction) return freeze({ ok: false, reason: 'explicit-user-action-required' });
      const view = productiveStations.refresh?.(reason) || productiveStations.getView?.();
      livingNexus.refresh?.('productive-stations-refreshed');
      return freeze({ ok: true, view, automaticExecution: false, rewardIssued: false });
    },
    getMissionsProgression() { return missionsProgression.getView?.() || null; },
    getProductiveMission(stationId = '') { return missionsProgression.getMission?.(stationId) || null; },
    claimProductiveMission(stationId = '', { explicitUserAction = false } = {}) {
      return claimMissionWithReaction(stationId, { explicitUserAction });
    },
    openDeterministicVaultReveal({ explicitUserAction = false } = {}) {
      return openRevealWithReaction({ explicitUserAction });
    },
    selectCityCosmetic(rewardId = '', { explicitUserAction = false } = {}) {
      return missionsProgression.selectCosmetic?.(rewardId, { explicitUserAction }) || freeze({ ok: false, reason: 'missions-progression-unavailable' });
    },
    refreshMissionsProgression(reason = 'manual', { explicitUserAction = false } = {}) {
      if (!explicitUserAction) return freeze({ ok: false, reason: 'explicit-user-action-required' });
      const view = missionsProgression.refresh?.(reason) || missionsProgression.getView?.();
      ui?.updateMissions?.();
      return freeze({ ok: true, view, automaticExecution: false, automaticPublishing: false });
    },
    getCastNpcTransitPlan() { return freeze({ schema: EON_CITY_W754_SCHEMA, cast: w754CastPlan, schedules: w754NpcSchedulePlan, validation: castTransitValidation }); },
    getEnvironmentArtAudioPlan() { return freeze({ schema: EON_CITY_W755_SCHEMA, plan: environmentController.getPlan(), validation: validateEonCityW755EnvironmentPlan(environmentController.getPlan()), audio: environmentController.getSnapshot().audio }); },
    getOnboardingNavigationAccessibilityPlan() { return freeze({ schema: EON_CITY_W756_SCHEMA, plan: w756ExperiencePlan, validation: w756ExperienceValidation, semanticNavigation: semanticNavigationController?.getSummary?.() || null }); },
    getPerformanceReliabilityPlan() { return freeze({ schema: EON_CITY_W757_SCHEMA, plan: w757ReliabilityPlan, validation: w757ReliabilityValidation, snapshot: reliabilityController.getSnapshot() }); },
    capturePerformanceMemory({ explicitUserAction = false } = {}) {
      if (!explicitUserAction) return freeze({ ok: false, reason: 'explicit-user-action-required' });
      return freeze({ ok: true, snapshot: reliabilityController.captureMemory(), localOnly: true, automaticallyCertified: false });
    },
    notePerformanceRestart({ explicitUserAction = false } = {}) {
      if (!explicitUserAction) return freeze({ ok: false, reason: 'explicit-user-action-required' });
      return freeze({ ok: true, snapshot: reliabilityController.noteRestart(), automaticallyCertified: false });
    },
    openAccessibleCityMap({ explicitUserAction = false, trigger = null } = {}) {
      if (!explicitUserAction) return freeze({ ok: false, reason: 'explicit-user-action-required' });
      return freeze({ ok: semanticNavigationController?.show?.(trigger || canvas) === true, semanticAlternative: true, automaticNavigation: false });
    },
    setEnvironmentProfile(next = {}, { explicitUserAction = false } = {}) {
      const result = environmentController.setProfile(next, { explicitUserAction });
      if (result.ok) applyW755EnvironmentPlan({ scene, hemisphere, direction, world, plan: environmentController.getPlan() });
      return result;
    },
    activateCityAudio({ explicitUserAction = false } = {}) { return environmentController.activateAudio({ explicitUserAction }); },
    setCityAudioPreferences(next = {}, { explicitUserAction = false } = {}) { return environmentController.setAudioPreferences(next, { explicitUserAction }); },
    listTransitDestinations() { return w754TransitController.listDestinations(); },
    requestTransit(destinationId = '', { explicitUserAction = false, fromDistrictId = 'orientation-hall' } = {}) {
      return w754TransitController.request(destinationId, { explicitUserAction, fromDistrictId });
    },
    confirmTransit(reviewToken = '', { explicitUserAction = false, choice = 'board' } = {}) {
      return w754TransitController.confirm(reviewToken, { explicitUserAction, choice });
    },
    cancelTransit({ explicitUserAction = false } = {}) { return w754TransitController.cancel({ explicitUserAction }); },
    getTransitState() { return w754TransitController.getSnapshot(); },
    getExplorationPose() { return freeze({ x: playerAnchor.position.x, y: 0, z: playerAnchor.position.z, heading: playerAnchor.rotation.y }); },
    restoreExplorationPose(pose = {}) { applyPlayerPose(pose, { stationId: activeStationId }); return true; },
    resumeLocation,
    resetView,
    openCityMenu(trigger = null) { ui?.openMenu?.(trigger || canvas); return freeze({ ok: true, explicitUserAction: true }); },
    closeCityMenu() { ui?.closeMenu?.(); return freeze({ ok: true }); },
    cycleWayfinderCamera() { cameraMode = 'follow'; camera.alpha += Math.PI / 4; camera.setTarget(new Vector3(playerAnchor.position.x, EON_CITY_W747_CAMERA_POSES.follow.targetHeight, playerAnchor.position.z)); return freeze({ id: 'orbit', alpha: camera.alpha }); },
    getWayfinderSummary() { return freeze({ id: 'orbit', alpha: camera.alpha, beta: camera.beta, radius: camera.radius }); },
    resetWayfinderCamera() {
      applyCameraPose(EON_CITY_W747_CAMERA_POSES.return, 'return');
      applyCameraPose(EON_CITY_W760_CAMERA_POSES.return, 'return');
      return freeze({ ok: true, obstructionClearance: arrivalCameraValidation.minimumClearance });
    },
    requestWayfinderState() { return freeze({ ok: true, camera: this.getWayfinderSummary() }); },
    setCinematicShot() { return freeze({ ok: false, reason: 'manual-camera-only' }); },
    setOpenSkyProfile(profile = 'dusk', { explicitUserAction = false } = {}) { return this.setEnvironmentProfile({ timeProfile: profile }, { explicitUserAction }); },
    setAgentPresence() { return freeze({ ok: false, reason: 'real-task-state-only' }); },
    setCompanionIntent() {
      return freeze({
        ok: true,
        companion: 'eonbot',
        presentation: 'w745-curiosity-director',
        current: heroPresentationSnapshot,
        localVisualOnly: true,
        automaticStationActivation: false,
        autonomousAgent: false
      });
    },
    setEonbotOrbitPresentation() {
      return freeze({
        ok: true,
        companion: 'eonbot',
        presentation: 'w745-curiosity-director',
        simpleOrbitRetired: true,
        current: heroPresentationSnapshot,
        localVisualOnly: true
      });
    },
    applyWorkloadProtection(reason = 'manual') { return applyPerformanceProtection(reason); },
    unstuck() { return resetView(); },
    pause() { manualPaused = true; clearInput('manual-pause'); ui?.setPaused?.(true); },
    resume() { manualPaused = false; ui?.setPaused?.(workSurfaceOpen); },
    isPaused() { return manualPaused || workSurfaceOpen; },
    destroy() {
      if (destroyed) return;
      destroyed = true;
      writeResume(playerAnchor.position, playerAnchor.rotation.y, activeStationId);
      clearInput();
      workspacePresenter.dispose?.();
      globalThis.removeEventListener?.('keydown', onKeyDown);
      if (onW749ViewChanged) globalThis.removeEventListener?.(EON_CITY_W749_VIEW_EVENT, onW749ViewChanged);
      globalThis.removeEventListener?.('keyup', onKeyUp);
      canvas.removeEventListener('pointerdown', restoreCanvasFocus);
      globalThis.removeEventListener?.('blur', onWindowBlur);
      globalThis.removeEventListener?.('resize', onResize);
      globalThis.removeEventListener?.('pagehide', onPageHide);
      canvas.removeEventListener('webglcontextlost', onContextLost, false);
      canvas.removeEventListener('webglcontextrestored', handleContextRestored, false);
      globalThis.document?.removeEventListener?.('visibilitychange', onVisibilityChange);
      scene.onPointerObservable.remove(pointerObserver);
      setContextualSelection(null);
      ui.dispose();
      semanticNavigationController?.dispose?.();
      spatialOverlay.dispose?.();
      missionsProgression.dispose?.();
      productiveStations.dispose?.();
      for (const monitor of stationMonitors.values()) monitor.dispose?.();
      stationMonitors.clear();
      commandCentre.dispose?.();
      commandStatusController.dispose?.();
      agentTheatreController.dispose?.();
      livingNexus.dispose?.();
      environmentController.dispose?.();
      reliabilityController.noteAssets(localAssetRuntime?.getSummary?.() || {});
      reliabilityController.dispose?.();
      localAssetRuntime?.dispose?.();
      movementRenderRecovery?.destroy?.();
      try { engine.stopRenderLoop(); } catch {}
      try { scene.dispose(); } catch {}
      try { engine.dispose(); } catch {}
      if (productRoot.__eonCityCommandHubRuntime === runtime) delete productRoot.__eonCityCommandHubRuntime;
      if (globalThis.EON_CITY_COMMAND_HUB_RUNTIME === runtime) delete globalThis.EON_CITY_COMMAND_HUB_RUNTIME;
    }
  });

  productRoot.__eonCityCommandHubRuntime = runtime;
  globalThis.EON_CITY_COMMAND_HUB_RUNTIME = runtime;
  return runtime;
}
