/* EONAPP.ch — Service Worker v757.0 — Performance, loading, memory, disposal + cache */
/* W476 owned-cache/update-safety boundary remains in force. */
/* Explicit-update bounded cache policy remains in force. */
// W765R3: this token is materialized by the production build. A release must
// never share a Cache Storage namespace with an earlier shell.
const RELEASE_ID = 'w765-2026-07-31-release-identity-source-template';
const RELEASE_SOURCE_REVISION = '__EONAPP_RELEASE_SOURCE_REVISION__';
const CITY_RUNTIME_PROVENANCE = 'eon-city-living-nexus-command-core-w757-1';
const EONAPP_CACHE_PREFIXES = Object.freeze(['eonapp-shell-', 'eonapp-assets-', 'eonapp-pages-', 'eonapp-city-assets-']);
const SHELL_CACHE = `eonapp-shell-${RELEASE_ID}`;
const ASSET_CACHE = `eonapp-assets-${RELEASE_ID}`;
const PAGE_CACHE = `eonapp-pages-${RELEASE_ID}`;
const PERSISTENT_CITY_ASSET_CACHE = `eonapp-city-assets-${RELEASE_ID}`;
const CURRENT_EONAPP_CACHES = Object.freeze(new Set([SHELL_CACHE, ASSET_CACHE, PAGE_CACHE, PERSISTENT_CITY_ASSET_CACHE]));
const OFFLINE_FALLBACK = '/offline.html';
const MAX_ASSET_ENTRIES = 160;
const MAX_PERSISTENT_CITY_ASSET_ENTRIES = 192;
const MAX_PAGE_ENTRIES = 32;
const NAVIGATION_NETWORK_TIMEOUT_MS = 4500;
const sw = /** @type {any} */ (self);

// Canonical public documents only. Redirect aliases, .html duplicates, retired
// City paths, sensitive surfaces and dynamic routes must not be precached.
const /** @type {any} */ PRECACHE = Object.freeze([
  '/', '/projects', '/library', '/workspace', '/automations', '/local-ai',
  '/market', '/insights', '/profile', '/realm-studio',
  '/offline.html', '/404.html', '/manifest.webmanifest', '/favicon.svg',
  '/assets/img/icons/icon-192.png', '/assets/img/icons/icon-512.png'
]);
const CRITICAL_PRECACHE = Object.freeze([OFFLINE_FALLBACK, '/manifest.webmanifest', '/favicon.svg']);

const LEGACY_CITY_NAVIGATION_PATHS = Object.freeze(new Set([
  '/realm', '/realm/', '/realm.html', '/realmworld', '/realmworld.html', '/realm-world', '/team-realm', '/team-realm.html', '/world', '/game', '/games.html',
  '/eoncity.html', '/eoncity/', '/eoncity/lite', '/eoncity/lite/', '/eoncity/lite.html', '/eoncity/tour', '/eoncity/tour/',
  '/eoncity/3d', '/eoncity/3d/', '/eoncity/play', '/eoncity/play/',
  '/eoncity-lite.html', '/eoncity-3d', '/eoncity-3d.html', '/eoncity-play', '/eoncity-play.html'
]));

const NO_STORE_NAVIGATION_PREFIXES = Object.freeze([
  '/admin', '/campaign-admin', '/billing', '/subscription', '/payment', '/api/', '/functions/', '/reward-access', '/rewards', '/telegram',
  '/vault', '/capsule', '/vault-backup', '/eoncity'
]);

// City access is session-sensitive and City modules change together with the access contract.
// Keep these network-only so a newly deployed gate never combines with an older cached runtime.
const CITY_RUNTIME_NETWORK_ONLY_PREFIXES = Object.freeze([
  '/assets/css/eon-city-play.css',
  '/assets/js/eon-city-play-station.js',
  '/assets/js/city/'
]);
const NETWORK_ONLY_STATIC_PATHS = Object.freeze(new Set(['/sw.js']));
const SENSITIVE_QUERY_KEY = /^(?:access_token|auth|authorization|code|credential|key|password|secret|session|signature|state|token)$/i;

function isEonAppOwnedCacheName(cacheName = '') {
  const value = String(cacheName || '');
  return EONAPP_CACHE_PREFIXES.some((prefix) => value.startsWith(prefix));
}

function isStaticAsset(pathname = '') {
  return /\.(?:js|css|png|jpg|jpeg|webp|avif|svg|ico|woff2|woff|ttf|glb|gltf|bin|wasm)$/i.test(pathname);
}

function isPersistentW649CityAsset(pathname = '') {
  const clean = String(pathname || '');
  return clean.startsWith('/assets/city/w649/')
    && /\.[a-f0-9]{12}\.(?:glb|gltf|bin|webp|ktx2)$/i.test(clean);
}


function isNoStoreNavigationPath(pathname = '') {
  const clean = String(pathname || '/').toLowerCase();
  return NO_STORE_NAVIGATION_PREFIXES.some((prefix) => clean === prefix || clean.startsWith(`${prefix}/`) || clean.startsWith(`${prefix}.html`));
}

function isCityRuntimeNetworkOnlyPath(pathname = '') {
  const clean = String(pathname || '').toLowerCase();
  return CITY_RUNTIME_NETWORK_ONLY_PREFIXES.some((prefix) => clean === prefix || clean.startsWith(prefix));
}

function hasSensitiveQuery(url) {
  for (const key of url.searchParams.keys()) if (SENSITIVE_QUERY_KEY.test(key)) return true;
  return false;
}

function isCacheSafeRequest(request, url) {
  if (request.method !== 'GET' || url.origin !== sw.location.origin) return false;
  if (request.headers.has('authorization') || request.headers.has('range')) return false;
  if (/no-store/i.test(String(request.headers.get('cache-control') || ''))) return false;
  return !hasSensitiveQuery(url);
}

function isCacheSafeResponse(response, requestUrl, { navigation = false } = {}) {
  if (!response?.ok || response.redirected) return false;
  if (!['basic', 'default'].includes(String(response.type || 'default'))) return false;
  const cacheControl = String(response.headers.get('cache-control') || '');
  if (/(?:^|,)\s*(?:no-store|private|no-cache)(?:\s|,|=|$)/i.test(cacheControl)) return false;
  if (String(response.headers.get('vary') || '').trim() === '*') return false;
  let responseUrl = null;
  try { responseUrl = new URL(response.url || requestUrl.toString(), sw.location.origin); } catch { return false; }
  if (responseUrl.origin !== sw.location.origin) return false;
  if (navigation && responseUrl.pathname.replace(/\/+$/, '') !== requestUrl.pathname.replace(/\/+$/, '')) return false;
  return true;
}

async function matchCurrentCache(cacheName, request) {
  const cache = await caches.open(cacheName);
  return cache.match(request, { ignoreSearch: false, ignoreMethod: false, ignoreVary: false });
}

async function matchOfflineFallback() {
  const shell = await caches.open(SHELL_CACHE);
  return shell.match(OFFLINE_FALLBACK);
}

async function trimCache(cacheName, maxEntries = 50) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  await Promise.all(keys.slice(0, Math.max(0, keys.length - maxEntries)).map((key) => cache.delete(key)));
}

async function putInCache(cacheName, request, response, maxEntries, options = {}) {
  let requestUrl = null;
  try { requestUrl = new URL(request.url || request, sw.location.origin); } catch { return response; }
  if (!isCacheSafeRequest(request, requestUrl) || !isCacheSafeResponse(response, requestUrl, options)) return response;
  const cache = await caches.open(cacheName);
  try { await cache.put(request, response.clone()); } catch { return response; }
  void trimCache(cacheName, maxEntries).catch(() => {});
  return response;
}

async function fetchWithTimeout(request, timeoutMs) {
  const controller = typeof AbortController === 'function' ? new AbortController() : null;
  const timeout = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  try { return await fetch(request, { cache: 'no-cache', ...(controller ? { signal: controller.signal } : {}) }); }
  finally { if (timeout) clearTimeout(timeout); }
}

async function navigationNetworkOnly(event) {
  try { return await fetch(event.request, { cache: 'no-store' }); }
  catch { return (await matchOfflineFallback()) || Response.error(); }
}

async function cityRuntimeNetworkOnly(event) {
  try {
    const response = await fetch(event.request, { cache: 'no-store' });
    if (!response?.ok || response.type === 'opaque') return response;
    const headers = new Headers(response.headers);
    headers.set('cache-control', 'no-store');
    headers.set('x-eon-city-runtime-provenance', CITY_RUNTIME_PROVENANCE);
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  }
  catch { return Response.error(); }
}

async function navigationNetworkFirst(event) {
  try {
    const response = await fetchWithTimeout(event.request, NAVIGATION_NETWORK_TIMEOUT_MS);
    event.waitUntil(putInCache(PAGE_CACHE, event.request, response, MAX_PAGE_ENTRIES, { navigation: true }));
    return response;
  } catch {
    return (await matchCurrentCache(PAGE_CACHE, event.request)) || (await matchOfflineFallback()) || Response.error();
  }
}

async function staticNetworkOnly(event) {
  try { return await fetch(event.request, { cache: 'no-store' }); }
  catch { return Response.error(); }
}

async function persistentCityAssetCacheFirst(event) {
  const cached = await matchCurrentCache(PERSISTENT_CITY_ASSET_CACHE, event.request);
  if (cached) return cached;
  try {
    const response = await fetch(event.request, { cache: 'force-cache' });
    return await putInCache(PERSISTENT_CITY_ASSET_CACHE, event.request, response, MAX_PERSISTENT_CITY_ASSET_ENTRIES);
  } catch {
    return Response.error();
  }
}

async function staticCacheFirst(event) {
  const url = new URL(event.request.url);
  // Query-bearing assets stay out of runtime caches. Release/version query
  // strings remain effective in the browser HTTP cache without multiplying
  // Cache API entries or retaining accidental token-bearing URLs.
  if (url.search) return staticNetworkOnly(event);
  const cached = await matchCurrentCache(ASSET_CACHE, event.request);
  if (cached) {
    event.waitUntil(fetch(event.request).then((response) => putInCache(ASSET_CACHE, event.request, response, MAX_ASSET_ENTRIES)).catch(() => {}));
    return cached;
  }
  try { return await putInCache(ASSET_CACHE, event.request, await fetch(event.request), MAX_ASSET_ENTRIES); }
  catch { return Response.error(); }
}

async function notifyClients(message) {
  const clients = await sw.clients.matchAll({ type: 'window', includeUncontrolled: true });
  for (const client of clients) {
    try { client.postMessage(message); } catch {}
  }
}

async function refreshEligibleCityClientsOnce() {
  const clients = await sw.clients.matchAll({ type: 'window', includeUncontrolled: true });
  await Promise.all(clients.map(async (client) => {
    try {
      const target = new URL(client.url);
      if (target.origin !== sw.location.origin || target.pathname.replace(/\/+$/, '') !== '/eoncity') return;
      if (target.searchParams.get('eon-release-refresh') === RELEASE_ID) return;
      target.searchParams.set('eon-release-refresh', RELEASE_ID);
      await client.navigate(target.toString());
    } catch {}
  }));
}

async function precacheReleaseShell() {
  const cache = await caches.open(SHELL_CACHE);
  // The offline document is a real install prerequisite; optional warm routes
  // must not block installation when one route is temporarily unavailable.
  await cache.addAll(CRITICAL_PRECACHE.map((url) => new Request(url, { cache: 'reload' })));
  const optional = PRECACHE.filter((url) => !CRITICAL_PRECACHE.includes(url));
  await Promise.allSettled(optional.map((url) => cache.add(new Request(url, { cache: 'reload' }))));
}

sw.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    await precacheReleaseShell();
    // The release is ready but remains waiting until the user explicitly
    // accepts this exact release identity through the PWA manager.
    await notifyClients({ type: 'EONAPP_SW_UPDATE_WAITING', releaseId: RELEASE_ID, sourceRevision: RELEASE_SOURCE_REVISION, cityRuntimeProvenance: CITY_RUNTIME_PROVENANCE, requiresUserReloadChoice: true });
  })());
});

sw.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    const obsoleteOwnedKeys = keys.filter((key) => isEonAppOwnedCacheName(key) && !CURRENT_EONAPP_CACHES.has(key));
    await Promise.all(obsoleteOwnedKeys.map((key) => caches.delete(key)));
    await sw.clients.claim();
    await notifyClients({ type: 'EONAPP_SW_ACTIVATED', releaseId: RELEASE_ID, sourceRevision: RELEASE_SOURCE_REVISION, cityRuntimeProvenance: CITY_RUNTIME_PROVENANCE, deletedOwnedCaches: obsoleteOwnedKeys.length, unknownCachesPreserved: true, reloadRequired: true });
    // Activation is reached immediately on first install, or after the user
    // explicitly approves this exact waiting release. Refresh only City clients
    // once so an old shell cannot continue driving a new Babylon runtime.
    await refreshEligibleCityClientsOnce();
  })());
});

sw.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== sw.location.origin || url.pathname.startsWith('/api/')) return;
  if (event.request.mode === 'navigate') {
    const pathname = url.pathname.toLowerCase();
    if (LEGACY_CITY_NAVIGATION_PATHS.has(pathname)) {
      event.respondWith(Promise.resolve(Response.redirect(new URL('/eoncity', sw.location.origin).toString(), 302)));
      return;
    }
    event.respondWith(isNoStoreNavigationPath(pathname) ? navigationNetworkOnly(event) : navigationNetworkFirst(event));
    return;
  }
  if (isCityRuntimeNetworkOnlyPath(url.pathname)) {
    event.respondWith(cityRuntimeNetworkOnly(event));
    return;
  }
  if (isPersistentW649CityAsset(url.pathname) && !url.search && !hasSensitiveQuery(url)) {
    event.respondWith(persistentCityAssetCacheFirst(event));
    return;
  }
  if (NETWORK_ONLY_STATIC_PATHS.has(url.pathname) || hasSensitiveQuery(url)) {
    event.respondWith(staticNetworkOnly(event));
    return;
  }
  if (isStaticAsset(url.pathname)) event.respondWith(staticCacheFirst(event));
});

sw.addEventListener('message', (event) => {
  const type = String(event.data?.type || '');
  if (type === 'EONAPP_RELEASE_ID_REQUEST') {
    const response = { type: 'EONAPP_SW_RELEASE_ID', releaseId: RELEASE_ID, sourceRevision: RELEASE_SOURCE_REVISION, cityRuntimeProvenance: CITY_RUNTIME_PROVENANCE };
    try { (event.ports?.[0] || event.source)?.postMessage?.(response); } catch {}
    return;
  }
  if (type === 'EONAPP_APPLY_UPDATE' && event.data?.releaseId === RELEASE_ID && event.data?.explicitUserAction === true) {
    event.waitUntil((async () => { await sw.skipWaiting(); })());
    return;
  }
  // Compatibility with older UI shells is safe only when the waiting worker
  // release identity is explicitly supplied and matches this worker.
  if (type === 'SKIP_WAITING' && event.data?.releaseId === RELEASE_ID && event.data?.explicitUserAction === true) {
    event.waitUntil((async () => { await sw.skipWaiting(); })());
  }
});

sw.addEventListener('push', (event) => {
  const fallback = { title: 'EONAPP', body: 'You have a new notification.', icon: '/assets/img/icons/icon-192.png', url: '/' };
  let payload = fallback;
  try { payload = { ...fallback, ...(event.data?.json?.() || {}) }; } catch { payload.body = event.data?.text?.() || fallback.body; }
  event.waitUntil(sw.registration.showNotification(payload.title, { body: payload.body, icon: payload.icon, badge: '/assets/img/icons/icon-192.png', data: { url: payload.url || '/' } }));
});

sw.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || '/';
  event.waitUntil(sw.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
    const match = clients.find((client) => client.url.includes(targetUrl));
    return match?.focus?.() || sw.clients.openWindow?.(targetUrl);
  }));
});
